$ProgressPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.IO.Compression.FileSystem

$src = 'C:\Users\mukun\.gemini\antigravity\scratch\codetales'
$dst1 = 'C:\Users\mukun\.gemini\antigravity\scratch\CODETALES_SOURCE_CODE.zip'
$dst2 = 'C:\Users\mukun\.gemini\antigravity\scratch\codetales\CODETALES_SOURCE_CODE.zip'

if (Test-Path $dst1) { Remove-Item $dst1 -Force }
if (Test-Path $dst2) { Remove-Item $dst2 -Force }

$tmpDir = 'C:\Users\mukun\.gemini\antigravity\scratch\codetales_zip_tmp'
if (Test-Path $tmpDir) { Remove-Item $tmpDir -Recurse -Force }
New-Item -ItemType Directory -Path $tmpDir -Force | Out-Null

Get-ChildItem -Path $src -Exclude 'node_modules', '.next', '.git', '*.zip', 'server.log', 'server_err.log', 'tunnel.log' | ForEach-Object {
    Copy-Item -Path $_.FullName -Destination $tmpDir -Recurse -Force
}

[System.IO.Compression.ZipFile]::CreateFromDirectory($tmpDir, $dst1)
Copy-Item -Path $dst1 -Destination $dst2 -Force
Remove-Item $tmpDir -Recurse -Force

Write-Output "Zip archive size: $((Get-Item $dst1).Length) bytes"
