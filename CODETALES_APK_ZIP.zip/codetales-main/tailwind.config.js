/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        cyber: {
          dark: '#050508',
          card: '#0a0a14',
          cardBorder: '#1e1b4b',
          surface: '#111122',
          neonPurple: '#a855f7',
          neonBlue: '#00f0ff',
          neonCyan: '#06b6d4',
          neonPink: '#ec4899',
          electric: '#38bdf8',
          textMuted: '#94a3b8',
        }
      },
      boxShadow: {
        'neon-purple': '0 0 15px rgba(168, 85, 247, 0.4), 0 0 30px rgba(168, 85, 247, 0.2)',
        'neon-blue': '0 0 15px rgba(0, 240, 255, 0.4), 0 0 30px rgba(0, 240, 255, 0.2)',
        'neon-pink': '0 0 15px rgba(236, 72, 153, 0.4), 0 0 30px rgba(236, 72, 153, 0.2)',
        'neon-cyan': '0 0 20px rgba(6, 182, 212, 0.45)',
        'cyber-card': '0 8px 32px 0 rgba(0, 0, 0, 0.37)',
      },
      backgroundImage: {
        'cyber-gradient': 'linear-gradient(135deg, rgba(168, 85, 247, 0.15) 0%, rgba(6, 182, 212, 0.15) 100%)',
        'cyber-grid': 'radial-gradient(circle, rgba(168,85,247,0.08) 1px, transparent 1px)',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
      },
      keyframes: {
        glow: {
          '0%': { boxShadow: '0 0 10px rgba(168,85,247,0.4)' },
          '100%': { boxShadow: '0 0 25px rgba(0,240,255,0.7)' },
        }
      }
    },
  },
  plugins: [],
};
