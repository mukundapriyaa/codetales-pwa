export type Genre = 'Adventure' | 'Mystery' | 'Fantasy' | 'Science Fiction' | 'Comedy';
export type Difficulty = 'Beginner' | 'Intermediate' | 'Advanced';
export type StoryLength = 'Short' | 'Medium' | 'Long';

export interface Concept {
  id: string;
  name: string;
  description: string;
  difficulty: Difficulty;
  keyTerms: string[];
}

export interface Topic {
  id: string;
  name: string;
  icon: string;
  badge: string;
  description: string;
  color: string;
  gradient: string;
  concepts: Concept[];
}

export interface StoryCustomization {
  topicId: string;
  conceptId: string;
  genre: Genre;
  difficulty: Difficulty;
  length: StoryLength;
  characterName?: string;
  setting?: string;
}

export interface ConceptMapping {
  storyElement: string;
  technicalConcept: string;
  explanation: string;
}

export interface GeneratedStory {
  id: string;
  title: string;
  topicId: string;
  topicName: string;
  conceptId: string;
  conceptName: string;
  genre: Genre;
  difficulty: Difficulty;
  length: StoryLength;
  characterName?: string;
  setting?: string;
  paragraphs: string[];
  keyTerms: string[];
  readingTimeMinutes: number;
  conceptMappings: ConceptMapping[];
  createdAt: string;
}

export interface QuizOption {
  id: string;
  text: string;
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: QuizOption[];
  correctAnswerId: string;
  explanation: string;
}

export interface QuizResult {
  score: number;
  totalQuestions: number;
  percentage: number;
  userAnswers: Record<number, string>;
  questions: QuizQuestion[];
  completedAt: string;
  topicName: string;
  conceptName: string;
}

export interface UserProgress {
  storiesRead: number;
  quizzesTaken: number;
  averageScore: number;
  completedTopics: string[];
  recentStories: GeneratedStory[];
  recentQuizResults: QuizResult[];
}
