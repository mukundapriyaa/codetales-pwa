import { Topic } from '@/types';

export const TOPICS: Topic[] = [
  {
    id: 'c-programming',
    name: 'C Programming',
    icon: 'Terminal',
    badge: 'Low-Level Mastery',
    description: 'The foundation of modern computing, operating systems, and high-performance embedded systems.',
    color: '#00f0ff',
    gradient: 'from-cyan-500/20 via-blue-500/20 to-purple-600/20',
    concepts: [
      {
        id: 'variables-data-types',
        name: 'Variables & Data Types',
        description: 'Memory allocation, integers, floats, and characters in low-level memory.',
        difficulty: 'Beginner',
        keyTerms: ['memory address', 'int', 'float', 'char', 'sizeof', 'type casting']
      },
      {
        id: 'operators-expressions',
        name: 'Operators & Expressions',
        description: 'Arithmetic, logical, relational, and bitwise operations on raw data.',
        difficulty: 'Beginner',
        keyTerms: ['arithmetic', 'bitwise AND', 'bitwise OR', 'precedence', 'modulo']
      },
      {
        id: 'control-flow',
        name: 'Conditional Statements & Loops',
        description: 'Decision trees and repetitive execution using if-else, switch, and for/while loops.',
        difficulty: 'Beginner',
        keyTerms: ['if-else', 'switch-case', 'while loop', 'for loop', 'break', 'continue']
      },
      {
        id: 'arrays-strings',
        name: 'Arrays & Null-Terminated Strings',
        description: 'Contiguous blocks of memory and string manipulation with null terminators.',
        difficulty: 'Intermediate',
        keyTerms: ['contiguous memory', 'indexing', 'null terminator', 'strlen', 'buffer']
      },
      {
        id: 'functions-scope',
        name: 'Functions & Variable Scope',
        description: 'Modular code blocks, pass-by-value, stack frames, and static variables.',
        difficulty: 'Intermediate',
        keyTerms: ['call stack', 'stack frame', 'parameters', 'return value', 'local scope', 'static']
      },
      {
        id: 'pointers-memory',
        name: 'Pointers & Direct Memory Access',
        description: 'Address-of operator, dereferencing, and pointer arithmetic traversing memory cells.',
        difficulty: 'Advanced',
        keyTerms: ['pointer', 'dereference', 'memory address', 'null pointer', 'pointer arithmetic']
      },
      {
        id: 'dynamic-memory',
        name: 'Dynamic Memory Allocation',
        description: 'Managing the heap at runtime with malloc, calloc, realloc, and avoiding memory leaks with free.',
        difficulty: 'Advanced',
        keyTerms: ['heap', 'malloc', 'free', 'memory leak', 'dangling pointer', 'segmentation fault']
      },
      {
        id: 'structures-unions',
        name: 'Structures & Unions',
        description: 'Composite user-defined data structures and shared memory layouts.',
        difficulty: 'Intermediate',
        keyTerms: ['struct', 'union', 'member access', 'memory alignment', 'typedef']
      }
    ]
  },
  {
    id: 'cpp-programming',
    name: 'C++ Programming',
    icon: 'Cpu',
    badge: 'High-Performance OOP',
    description: 'System programming, game engines, and zero-overhead abstractions.',
    color: '#38bdf8',
    gradient: 'from-blue-500/20 via-indigo-500/20 to-purple-600/20',
    concepts: [
      {
        id: 'classes-objects',
        name: 'Classes & Objects',
        description: 'Blueprints, constructors, member variables, and object state encapsulation.',
        difficulty: 'Beginner',
        keyTerms: ['class blueprint', 'object instance', 'constructor', 'destructor', 'access specifiers']
      },
      {
        id: 'raii-smart-pointers',
        name: 'RAII & Smart Pointers',
        description: 'Resource Acquisition Is Initialization, unique_ptr, and shared_ptr automatic cleanup.',
        difficulty: 'Advanced',
        keyTerms: ['RAII', 'unique_ptr', 'shared_ptr', 'reference counting', 'resource management']
      },
      {
        id: 'operator-overloading',
        name: 'Operator Overloading',
        description: 'Giving custom intuitive behavior to operators like +, -, and << for custom classes.',
        difficulty: 'Intermediate',
        keyTerms: ['operator overload', 'friend function', 'stream insertion', 'copy assignment']
      },
      {
        id: 'inheritance-polymorphism',
        name: 'Inheritance & Virtual Functions',
        description: 'Base and derived classes, dynamic dispatch, and the virtual method table (vtable).',
        difficulty: 'Intermediate',
        keyTerms: ['base class', 'derived class', 'virtual function', 'vtable', 'dynamic dispatch', 'override']
      },
      {
        id: 'templates-generic',
        name: 'Templates & Generic Programming',
        description: 'Compile-time polymorphism and writing algorithms that adapt to any data type.',
        difficulty: 'Advanced',
        keyTerms: ['template class', 'template function', 'type deduction', 'specialization', 'metaprogramming']
      },
      {
        id: 'stl-containers',
        name: 'Standard Template Library (STL)',
        description: 'Vectors, maps, sets, iterators, and high-performance pre-built algorithms.',
        difficulty: 'Intermediate',
        keyTerms: ['vector', 'unordered_map', 'iterators', 'std::sort', 'complexity guarantees']
      },
      {
        id: 'exception-handling',
        name: 'Exception Handling',
        description: 'Resilient error recovery with try, catch, throw, and stack unwinding.',
        difficulty: 'Beginner',
        keyTerms: ['try-catch', 'throw exception', 'stack unwinding', 'std::runtime_error', 'noexcept']
      }
    ]
  },
  {
    id: 'java',
    name: 'Java',
    icon: 'Coffee',
    badge: 'Enterprise Platform',
    description: 'Platform-independent enterprise engineering, robust JVM architecture, and design patterns.',
    color: '#f97316',
    gradient: 'from-amber-500/20 via-orange-500/20 to-purple-600/20',
    concepts: [
      {
        id: 'jvm-bytecode',
        name: 'JVM & Bytecode Architecture',
        description: 'Write once, run anywhere: Java Virtual Machine, class loading, and JIT compilation.',
        difficulty: 'Intermediate',
        keyTerms: ['JVM', 'bytecode', 'class loader', 'Just-In-Time compiler', 'garbage collection']
      },
      {
        id: 'encapsulation-access',
        name: 'Encapsulation & Access Control',
        description: 'Hiding internal state using private fields, getters, setters, and package boundaries.',
        difficulty: 'Beginner',
        keyTerms: ['encapsulation', 'private', 'public', 'protected', 'getters and setters', 'data hiding']
      },
      {
        id: 'inheritance-super',
        name: 'Inheritance & Method Overriding',
        description: 'Extending parent classes, reusing logic, and invoking super constructors.',
        difficulty: 'Beginner',
        keyTerms: ['inheritance', 'extends', 'super keyword', 'method overriding', 'polymorphism']
      },
      {
        id: 'interfaces-abstraction',
        name: 'Interfaces & Abstract Classes',
        description: 'Defining architectural contracts and default methods without tying to implementation.',
        difficulty: 'Intermediate',
        keyTerms: ['interface', 'abstract class', 'implements', 'contract', 'multiple inheritance of type']
      },
      {
        id: 'exception-hierarchy',
        name: 'Checked vs Unchecked Exceptions',
        description: 'Guaranteed error handling contracts, Throwable hierarchy, and try-with-resources.',
        difficulty: 'Intermediate',
        keyTerms: ['checked exception', 'unchecked exception', 'try-with-resources', 'AutoCloseable', 'finally']
      },
      {
        id: 'collections-framework',
        name: 'Java Collections Framework',
        description: 'ArrayList, LinkedList, HashMap, ConcurrentHashMap, and iterator patterns.',
        difficulty: 'Intermediate',
        keyTerms: ['ArrayList', 'HashMap', 'HashSet', 'Generics', 'Iterator', 'Comparable vs Comparator']
      },
      {
        id: 'multithreading-concurrency',
        name: 'Multithreading & Concurrency',
        description: 'Spawning threads, synchronizing critical sections, and utilizing ExecutorService.',
        difficulty: 'Advanced',
        keyTerms: ['Thread', 'Runnable', 'synchronized block', 'deadlock', 'ExecutorService', 'race condition']
      }
    ]
  },
  {
    id: 'python',
    name: 'Python',
    icon: 'FileCode2',
    badge: 'Elegance & AI Powerhouse',
    description: 'Clean readable syntax, powerful scientific packages, automation, and AI workflows.',
    color: '#a855f7',
    gradient: 'from-purple-500/20 via-pink-500/20 to-cyan-500/20',
    concepts: [
      {
        id: 'variables-dynamic-typing',
        name: 'Variables & Dynamic Typing',
        description: 'Names bound to objects, reference counting, and Python mutability vs immutability.',
        difficulty: 'Beginner',
        keyTerms: ['dynamic typing', 'name binding', 'immutable types', 'mutable objects', 'id()']
      },
      {
        id: 'data-structures-builtins',
        name: 'Lists, Tuples, Dictionaries & Sets',
        description: 'Key-value maps, ordered collections, set operations, and hashable keys.',
        difficulty: 'Beginner',
        keyTerms: ['list slicing', 'tuple immutability', 'dictionary hash lookup', 'set intersection']
      },
      {
        id: 'loops-comprehensions',
        name: 'Loops & List Comprehensions',
        description: 'Iterating with for and while loops, enumerate, zip, and concise list comprehensions.',
        difficulty: 'Beginner',
        keyTerms: ['for loop', 'while loop', 'list comprehension', 'enumerate', 'zip iterator']
      },
      {
        id: 'functions-recursion',
        name: 'Functions & Recursion',
        description: 'First-class functions, recursion with base cases, and arbitrary arguments (*args, **kwargs).',
        difficulty: 'Intermediate',
        keyTerms: ['recursion', 'base case', 'call stack', '*args and **kwargs', 'lambda function']
      },
      {
        id: 'generators-iterators',
        name: 'Generators & Yield',
        description: 'Memory-efficient lazy streaming using generator functions and the iterator protocol.',
        difficulty: 'Advanced',
        keyTerms: ['generator function', 'yield keyword', 'lazy evaluation', 'iterator protocol', 'next()']
      },
      {
        id: 'decorators',
        name: 'Decorators & Closures',
        description: 'Higher-order functions that wrap and supercharge other functions dynamically.',
        difficulty: 'Advanced',
        keyTerms: ['decorator', 'wrapper function', 'closure', 'first-class citizen', '@functools.wraps']
      },
      {
        id: 'classes-dunder-methods',
        name: 'Classes & Dunder Methods',
        description: 'Object-oriented Python, __init__, __str__, operator overloading, and dunder magic.',
        difficulty: 'Intermediate',
        keyTerms: ['self parameter', '__init__ constructor', 'dunder methods', 'inheritance', 'property']
      }
    ]
  },
  {
    id: 'data-structures',
    name: 'Data Structures',
    icon: 'Layers',
    badge: 'Foundations of Organization',
    description: 'Systematic arrangements of memory for ultra-fast storage, retrieval, and manipulation.',
    color: '#06b6d4',
    gradient: 'from-cyan-500/20 via-purple-500/20 to-blue-500/20',
    concepts: [
      {
        id: 'arrays-dynamic-arrays',
        name: 'Arrays & Dynamic Arrays',
        description: 'Continuous memory chunks, O(1) random index access, and geometric resizing.',
        difficulty: 'Beginner',
        keyTerms: ['contiguous memory', 'index lookup O(1)', 'amortized O(1)', 'array capacity', 'resizing']
      },
      {
        id: 'linked-lists',
        name: 'Singly & Doubly Linked Lists',
        description: 'Nodes chained by pointers, O(1) insertions at head, and pointer manipulation.',
        difficulty: 'Beginner',
        keyTerms: ['node', 'next pointer', 'prev pointer', 'head and tail', 'null pointer traversal']
      },
      {
        id: 'stacks-queues',
        name: 'Stacks (LIFO) & Queues (FIFO)',
        description: 'Last-In-First-Out call stacks and First-In-First-Out buffers with push, pop, and peek.',
        difficulty: 'Beginner',
        keyTerms: ['stack LIFO', 'queue FIFO', 'push and pop', 'enqueue and dequeue', 'circular buffer']
      },
      {
        id: 'hash-tables',
        name: 'Hash Tables & Hash Maps',
        description: 'Hash functions, collision handling via chaining or open addressing, and average O(1) lookups.',
        difficulty: 'Intermediate',
        keyTerms: ['hash function', 'hash bucket', 'collision chaining', 'load factor', 'amortized O(1)']
      },
      {
        id: 'binary-trees-bst',
        name: 'Trees & Binary Search Trees (BST)',
        description: 'Hierarchical node relationships, tree traversals (in-order, pre-order), and O(log n) lookups.',
        difficulty: 'Intermediate',
        keyTerms: ['root node', 'leaf node', 'binary search tree property', 'in-order traversal', 'balanced tree']
      },
      {
        id: 'graphs',
        name: 'Graphs & Adjacency Representations',
        description: 'Vertices and edges, directed vs undirected graphs, adjacency matrices, and adjacency lists.',
        difficulty: 'Advanced',
        keyTerms: ['vertex', 'edge', 'adjacency list', 'directed graph', 'cycle detection', 'weighted edge']
      },
      {
        id: 'heaps-priority-queues',
        name: 'Heaps & Priority Queues',
        description: 'Complete binary tree representation in an array, min-heaps, max-heaps, and sift operations.',
        difficulty: 'Advanced',
        keyTerms: ['min-heap', 'max-heap', 'heapify', 'sift down', 'priority queue', 'O(log n) extraction']
      }
    ]
  },
  {
    id: 'algorithms',
    name: 'Algorithms',
    icon: 'Network',
    badge: 'Computational Logic',
    description: 'Step-by-step procedures, asymptotic time complexity, and optimization paradigms.',
    color: '#8b5cf6',
    gradient: 'from-purple-500/20 via-pink-500/20 to-blue-500/20',
    concepts: [
      {
        id: 'big-o-notation',
        name: 'Big-O Notation & Complexity Analysis',
        description: 'Measuring algorithm performance: O(1), O(log n), O(n), O(n log n), and O(n^2).',
        difficulty: 'Beginner',
        keyTerms: ['asymptotic notation', 'time complexity', 'space complexity', 'worst case', 'upper bound']
      },
      {
        id: 'binary-search',
        name: 'Binary Search & Divide-and-Conquer',
        description: 'Halving the search space repeatedly to find elements in sorted datasets in O(log n) time.',
        difficulty: 'Beginner',
        keyTerms: ['divide and conquer', 'search space halving', 'sorted array', 'midpoint', 'O(log n)']
      },
      {
        id: 'sorting-algorithms',
        name: 'Quick Sort & Merge Sort',
        description: 'Pivot partitioning, recursive subarrays, stable merges, and guaranteed O(n log n) sorting.',
        difficulty: 'Intermediate',
        keyTerms: ['pivot element', 'partitioning', 'merge step', 'stable sort', 'divide and conquer']
      },
      {
        id: 'bfs-dfs',
        name: 'Breadth-First (BFS) & Depth-First (DFS) Search',
        description: 'Level-order queue exploration vs deep recursive stack pathfinding in graphs and mazes.',
        difficulty: 'Intermediate',
        keyTerms: ['BFS queue', 'DFS stack', 'visited set', 'shortest unweighted path', 'backtracking']
      },
      {
        id: 'dijkstra-algorithm',
        name: "Dijkstra's Shortest Path Algorithm",
        description: 'Greedy shortest path calculation on weighted non-negative graphs using priority queues.',
        difficulty: 'Advanced',
        keyTerms: ['weighted graph', 'distance array', 'priority queue relaxation', 'shortest path', 'greedy strategy']
      },
      {
        id: 'dynamic-programming',
        name: 'Dynamic Programming & Memoization',
        description: 'Breaking problems into overlapping subproblems, optimal substructure, and caching results.',
        difficulty: 'Advanced',
        keyTerms: ['overlapping subproblems', 'optimal substructure', 'memoization top-down', 'tabulation bottom-up']
      }
    ]
  },
  {
    id: 'nlp',
    name: 'Natural Language Processing',
    icon: 'Sparkles',
    badge: 'Human-Machine Linguistics',
    description: 'Empowering computational systems to parse, comprehend, and generate natural human language.',
    color: '#ec4899',
    gradient: 'from-pink-500/20 via-purple-500/20 to-cyan-500/20',
    concepts: [
      {
        id: 'tokenization-text-preprocessing',
        name: 'Tokenization & Normalization',
        description: 'Breaking continuous text into words/subwords, lowercase normalization, and punctuation removal.',
        difficulty: 'Beginner',
        keyTerms: ['tokens', 'subword tokenization (BPE)', 'normalization', 'vocabulary', 'whitespace splitting']
      },
      {
        id: 'stemming-lemmatization',
        name: 'Stemming & Lemmatization',
        description: 'Reducing words to root stems through heuristic chopping vs dictionary lemma lookup.',
        difficulty: 'Beginner',
        keyTerms: ['stemming heuristic', 'lemma dictionary', 'morphological analysis', 'Porter stemmer', 'POS tagging']
      },
      {
        id: 'tfidf-bow',
        name: 'Bag of Words & TF-IDF',
        description: 'Converting text to statistical frequency vectors: Term Frequency-Inverse Document Frequency.',
        difficulty: 'Intermediate',
        keyTerms: ['Bag of Words', 'TF-IDF weight', 'document frequency', 'sparse vector', 'cosine similarity']
      },
      {
        id: 'word-embeddings',
        name: 'Word Embeddings & Vector Space',
        description: 'Capturing semantic relationships in continuous multidimensional vector spaces (Word2Vec).',
        difficulty: 'Intermediate',
        keyTerms: ['vector space', 'Word2Vec', 'semantic proximity', 'dimensions', 'king - man + woman = queen']
      },
      {
        id: 'sentiment-analysis',
        name: 'Sentiment Analysis & Text Classification',
        description: 'Determining emotional polarity, intent, and classification in user reviews and texts.',
        difficulty: 'Beginner',
        keyTerms: ['sentiment polarity', 'classification', 'positive/negative scores', 'supervised learning']
      },
      {
        id: 'transformer-attention',
        name: 'Transformers & Self-Attention',
        description: 'The breakthrough architecture behind modern LLMs: attention matrices, query-key-value vectors.',
        difficulty: 'Advanced',
        keyTerms: ['self-attention', 'Query Key Value', 'Transformer encoder/decoder', 'multi-head attention', 'LLM']
      }
    ]
  },
  {
    id: 'oop',
    name: 'Object-Oriented Programming',
    icon: 'Boxes',
    badge: 'Software Architecture Paradigm',
    description: 'Structuring software as cooperating autonomous entities modeling real-world domains.',
    color: '#3b82f6',
    gradient: 'from-blue-600/20 via-purple-600/20 to-pink-500/20',
    concepts: [
      {
        id: 'classes-instances',
        name: 'Classes & Objects',
        description: 'The conceptual blueprint vs live memory instance with distinct state and behaviors.',
        difficulty: 'Beginner',
        keyTerms: ['blueprint', 'instantiation', 'state (attributes)', 'behavior (methods)', 'identity']
      },
      {
        id: 'encapsulation',
        name: 'Encapsulation & Data Hiding',
        description: 'Bundling data with operations that manipulate it and shielding internal state from outside interference.',
        difficulty: 'Beginner',
        keyTerms: ['data protection', 'public interface', 'private implementation', 'invariants', 'getters/setters']
      },
      {
        id: 'inheritance',
        name: 'Inheritance & Subtyping',
        description: 'Creating specialized child types that inherit and extend the attributes and methods of parent types.',
        difficulty: 'Beginner',
        keyTerms: ['is-a relationship', 'parent superclass', 'child subclass', 'code reuse', 'method extension']
      },
      {
        id: 'polymorphism',
        name: 'Polymorphism (Static & Dynamic)',
        description: 'One interface, multiple implementations: runtime method overriding and compile-time overloading.',
        difficulty: 'Intermediate',
        keyTerms: ['dynamic dispatch', 'method overriding', 'method overloading', 'substitutability', 'duck typing']
      },
      {
        id: 'abstraction',
        name: 'Abstraction & Design Contracts',
        description: 'Distilling complex real-world entities down to essential characteristics through interfaces.',
        difficulty: 'Intermediate',
        keyTerms: ['abstract contract', 'information hiding', 'interface', 'essential complexity']
      },
      {
        id: 'solid-principles',
        name: 'SOLID Design Principles',
        description: 'Five design principles for maintainable, decoupled, and extensible object-oriented architectures.',
        difficulty: 'Advanced',
        keyTerms: ['Single Responsibility', 'Open/Closed', 'Liskov Substitution', 'Interface Segregation', 'Dependency Inversion']
      }
    ]
  },
  {
    id: 'html',
    name: 'HTML',
    icon: 'Globe',
    badge: 'Web Skeleton',
    description: 'The semantic scaffolding of the global World Wide Web and modern document trees.',
    color: '#f43f5e',
    gradient: 'from-rose-500/20 via-orange-500/20 to-purple-500/20',
    concepts: [
      {
        id: 'dom-tree-structure',
        name: 'Document Object Model (DOM) Tree',
        description: 'How browsers parse HTML markup into a living parent-child tree hierarchy of nodes.',
        difficulty: 'Beginner',
        keyTerms: ['DOM tree', 'HTML element', 'attributes', 'parent-child nodes', 'DOCTYPE declaration']
      },
      {
        id: 'semantic-elements',
        name: 'Semantic HTML & Accessibility',
        description: 'Meaningful elements (<article>, <nav>, <section>, <header>) for screen readers and SEO.',
        difficulty: 'Beginner',
        keyTerms: ['semantic markup', 'accessibility ARIA', 'screen reader', '<main>', '<header>', '<article>']
      },
      {
        id: 'forms-input-validation',
        name: 'Forms, Inputs & Native Validation',
        description: 'Collecting user input safely with type attributes, patterns, form submissions, and CSRF protection.',
        difficulty: 'Beginner',
        keyTerms: ['<form>', 'input types', 'action and method', 'native validation (required)', 'POST vs GET']
      },
      {
        id: 'tables-structured-data',
        name: 'Tables & Tabular Data',
        description: 'Representing two-dimensional datasets with rows, headers, colspans, and accessible captions.',
        difficulty: 'Beginner',
        keyTerms: ['<table>', '<tr> table row', '<th> table header', '<td> table data', 'colspan and rowspan']
      },
      {
        id: 'multimedia-canvas',
        name: 'Multimedia, Audio/Video & Canvas',
        description: 'Embedding rich media, audio streams, responsive video, and immediate-mode pixel drawing.',
        difficulty: 'Intermediate',
        keyTerms: ['<audio>', '<video> codecs', '<canvas> 2D context', 'SVG vector graphics', 'responsive iframe']
      },
      {
        id: 'meta-tags-seo',
        name: 'Meta Tags, OpenGraph & Web Security',
        description: 'Instructing search engine crawlers, defining social share cards, and configuring Content Security Policy.',
        difficulty: 'Intermediate',
        keyTerms: ['<meta charset>', 'viewport meta tag', 'OpenGraph og:image', 'Content Security Policy (CSP)']
      }
    ]
  },
  {
    id: 'css',
    name: 'CSS',
    icon: 'Palette',
    badge: 'Visual Styling Engine',
    description: 'Cascading stylesheets, layout algorithms, responsive viewports, and kinetic animations.',
    color: '#06b6d4',
    gradient: 'from-cyan-500/20 via-blue-500/20 to-indigo-500/20',
    concepts: [
      {
        id: 'box-model',
        name: 'The CSS Box Model',
        description: 'Content, padding, border, and margin dimensions, plus the box-sizing property.',
        difficulty: 'Beginner',
        keyTerms: ['content box', 'padding', 'border', 'margin collapsing', 'box-sizing: border-box']
      },
      {
        id: 'selectors-specificity',
        name: 'Selectors, Specificity & The Cascade',
        description: 'How the browser calculates which style rule wins based on importance, specificity, and source order.',
        difficulty: 'Beginner',
        keyTerms: ['element selector', 'class selector', 'ID specificity', 'cascade order', '!important override']
      },
      {
        id: 'flexbox',
        name: 'Flexbox (One-Dimensional Layout)',
        description: 'Main axis, cross axis, justify-content, align-items, flex-grow, and flexible components.',
        difficulty: 'Beginner',
        keyTerms: ['flex container', 'main axis', 'cross axis', 'justify-content', 'align-items', 'flex-wrap']
      },
      {
        id: 'css-grid',
        name: 'CSS Grid (Two-Dimensional Layout)',
        description: 'Grid tracks, template areas, fr units, auto-fit/fill, and building responsive dashboards.',
        difficulty: 'Intermediate',
        keyTerms: ['grid-template-columns', 'fractional fr unit', 'grid-area', 'gap property', 'repeat(auto-fit)']
      },
      {
        id: 'responsive-media-queries',
        name: 'Responsive Design & Media Queries',
        description: 'Adapting layouts fluidly across smartphones, tablets, and 4K displays using min-width breakpoints.',
        difficulty: 'Intermediate',
        keyTerms: ['media query', 'breakpoint min-width', 'fluid typography', 'mobile-first design', 'viewport units']
      },
      {
        id: 'transitions-animations',
        name: 'Keyframe Animations & Transitions',
        description: 'Kinetic GPU-accelerated styling with cubic-bezier timing functions and @keyframes choreography.',
        difficulty: 'Intermediate',
        keyTerms: ['@keyframes', 'animation duration', 'transition-timing-function', 'transform translate', 'opacity']
      }
    ]
  },
  {
    id: 'javascript',
    name: 'JavaScript',
    icon: 'Code',
    badge: 'The Engine of the Interactive Web',
    description: 'Dynamic scripting, asynchronous event loops, closure scopes, and modern ECMAScript standards.',
    color: '#eab308',
    gradient: 'from-yellow-500/20 via-amber-500/20 to-purple-600/20',
    concepts: [
      {
        id: 'variables-hoisting',
        name: 'Scope, let, const & Hoisting',
        description: 'Block scoping vs function scoping, the temporal dead zone, and variable declarations.',
        difficulty: 'Beginner',
        keyTerms: ['let and const', 'block scope', 'temporal dead zone', 'hoisting mechanism', 'mutation vs reassignment']
      },
      {
        id: 'closures-lexical-scope',
        name: 'Closures & Lexical Environment',
        description: 'Inner functions retaining persistent access to parent scope variables even after execution returns.',
        difficulty: 'Intermediate',
        keyTerms: ['closure', 'lexical scope', 'persistent state', 'currying', 'data privacy']
      },
      {
        id: 'event-loop-async',
        name: 'The Event Loop & Call Stack',
        description: 'Non-blocking I/O, single-threaded execution, microtask queue (Promises), and macrotask queue.',
        difficulty: 'Advanced',
        keyTerms: ['call stack', 'event loop', 'microtask queue', 'macrotask (setTimeout)', 'non-blocking I/O']
      },
      {
        id: 'promises-async-await',
        name: 'Promises & Async/Await',
        description: 'Managing asynchronous operations cleanly without callback hell using Promise states and await.',
        difficulty: 'Intermediate',
        keyTerms: ['Promise pending/fulfilled/rejected', 'async function', 'await operator', 'try/catch', 'Promise.all']
      },
      {
        id: 'dom-event-delegation',
        name: 'DOM Manipulation & Event Bubbling',
        description: 'Selecting elements, modifying attributes, event propagation (capture/bubble), and event delegation.',
        difficulty: 'Beginner',
        keyTerms: ['querySelector', 'event bubbling', 'event capturing', 'event delegation', 'stopPropagation']
      },
      {
        id: 'prototypal-inheritance',
        name: 'Prototypes & Prototype Chain',
        description: 'How JavaScript implements object inheritance via prototype links rather than classical classes.',
        difficulty: 'Advanced',
        keyTerms: ['prototype chain', '__proto__ link', 'Object.prototype', 'class syntactic sugar', 'method delegation']
      }
    ]
  },
  {
    id: 'sql',
    name: 'SQL',
    icon: 'Database',
    badge: 'Declarative Query Power',
    description: 'Structured Query Language for querying, aggregating, and joining relational records.',
    color: '#06b6d4',
    gradient: 'from-cyan-600/20 via-teal-500/20 to-purple-500/20',
    concepts: [
      {
        id: 'select-filtering',
        name: 'SELECT, WHERE & Filtering',
        description: 'Declarative queries: projecting columns, filtering with WHERE predicates, and ordering results.',
        difficulty: 'Beginner',
        keyTerms: ['SELECT projection', 'WHERE predicate', 'ORDER BY', 'LIMIT/OFFSET', 'NULL handling']
      },
      {
        id: 'joins-relational',
        name: 'Relational JOINs (INNER, LEFT, RIGHT, FULL)',
        description: 'Combining records from multiple tables based on matching foreign key relationships.',
        difficulty: 'Intermediate',
        keyTerms: ['INNER JOIN', 'LEFT OUTER JOIN', 'FULL JOIN', 'ON condition', 'cartesian product']
      },
      {
        id: 'aggregations-groupby',
        name: 'Aggregations & GROUP BY',
        description: 'Computing metrics across groups: COUNT, SUM, AVG, and filtering groups using HAVING.',
        difficulty: 'Intermediate',
        keyTerms: ['GROUP BY', 'HAVING clause', 'COUNT aggregation', 'SUM/AVG', 'grouped result sets']
      },
      {
        id: 'indexes-query-planner',
        name: 'Indexes & Query Optimization',
        description: 'B-tree index lookups vs full table scans, index selectivity, and EXPLAIN plans.',
        difficulty: 'Advanced',
        keyTerms: ['B-Tree index', 'full table scan', 'EXPLAIN query plan', 'composite index', 'selectivity']
      },
      {
        id: 'transactions-acid',
        name: 'Transactions & ACID Guarantees',
        description: 'Atomic operations: BEGIN, COMMIT, ROLLBACK, and isolation levels preventing dirty reads.',
        difficulty: 'Advanced',
        keyTerms: ['Atomicity', 'Consistency', 'Isolation', 'Durability', 'COMMIT', 'ROLLBACK']
      },
      {
        id: 'subqueries-ctes',
        name: 'Subqueries & Common Table Expressions (CTEs)',
        description: 'Nesting queries, WITH clauses, and recursive CTEs for hierarchical tree queries.',
        difficulty: 'Intermediate',
        keyTerms: ['correlated subquery', 'WITH CTE clause', 'derived table', 'EXISTS clause', 'recursive CTE']
      }
    ]
  },
  {
    id: 'dbms',
    name: 'Database Management Systems',
    icon: 'HardDrive',
    badge: 'Data Integrity & Scale',
    description: 'The architectural software engines governing data consistency, concurrency, storage, and recovery.',
    color: '#8b5cf6',
    gradient: 'from-purple-600/20 via-indigo-500/20 to-blue-500/20',
    concepts: [
      {
        id: 'relational-model-keys',
        name: 'Relational Model, Primary & Foreign Keys',
        description: 'Tuples, relations, schema constraints, candidate keys, and referential integrity.',
        difficulty: 'Beginner',
        keyTerms: ['relation schema', 'primary key constraint', 'foreign key constraint', 'referential integrity', 'tuple']
      },
      {
        id: 'normalization-forms',
        name: 'Database Normalization (1NF, 2NF, 3NF, BCNF)',
        description: 'Eliminating data redundancy and update anomalies through functional dependencies.',
        difficulty: 'Intermediate',
        keyTerms: ['functional dependency', '1NF atomic values', '2NF partial dependency', '3NF transitive dependency', 'BCNF']
      },
      {
        id: 'er-modeling',
        name: 'Entity-Relationship (ER) Modeling',
        description: 'Visualizing enterprise requirements as entities, attributes, cardinalities (1:1, 1:N, M:N).',
        difficulty: 'Beginner',
        keyTerms: ['entity set', 'cardinality ratio', 'weak entity', 'ER diagram', 'relationship mapping']
      },
      {
        id: 'concurrency-control-locks',
        name: 'Concurrency Control & Locking Protocols',
        description: 'Two-Phase Locking (2PL), shared vs exclusive locks, and optimistic concurrency control (MVCC).',
        difficulty: 'Advanced',
        keyTerms: ['Two-Phase Locking (2PL)', 'shared lock (S)', 'exclusive lock (X)', 'MVCC', 'phantom reads']
      },
      {
        id: 'deadlocks-recovery',
        name: 'Deadlocks & Write-Ahead Logging (WAL)',
        description: 'Wait-for graphs, deadlock detection, transaction rollback, and crash recovery with ARIES.',
        difficulty: 'Advanced',
        keyTerms: ['wait-for graph', 'deadlock cycle', 'Write-Ahead Log (WAL)', 'ARIES recovery', 'checkpoint']
      },
      {
        id: 'sharding-replication',
        name: 'Sharding, Replication & CAP Theorem',
        description: 'Horizontal partitioning across database clusters, master-slave replication, and the CAP tradeoff.',
        difficulty: 'Advanced',
        keyTerms: ['horizontal sharding', 'read replica', 'CAP theorem', 'eventual consistency', 'split-brain']
      }
    ]
  },
  {
    id: 'operating-systems',
    name: 'Operating Systems',
    icon: 'Cpu',
    badge: 'Hardware-Software Conductor',
    description: 'Kernel architectures, multitasking, virtual memory, process scheduling, and security rings.',
    color: '#00f0ff',
    gradient: 'from-cyan-500/20 via-blue-600/20 to-purple-600/20',
    concepts: [
      {
        id: 'processes-threads',
        name: 'Processes, Threads & Context Switching',
        description: 'Process Control Blocks (PCB), user vs kernel threads, thread stacks, and context switch costs.',
        difficulty: 'Beginner',
        keyTerms: ['Process Control Block (PCB)', 'thread stack', 'context switch', 'fork()', 'address space']
      },
      {
        id: 'cpu-scheduling',
        name: 'CPU Scheduling Algorithms',
        description: 'First-Come-First-Served, Shortest Job Next, Round Robin time slices, and multi-level feedback queues.',
        difficulty: 'Intermediate',
        keyTerms: ['time slice quantum', 'Round Robin', 'preemption', 'starvation', 'multilevel feedback queue']
      },
      {
        id: 'synchronization-semaphores',
        name: 'Process Synchronization & Mutexes',
        description: 'Critical sections, race conditions, atomic test-and-set, semaphores, and condition variables.',
        difficulty: 'Intermediate',
        keyTerms: ['critical section', 'race condition', 'mutex', 'counting semaphore', 'atomic operation']
      },
      {
        id: 'deadlock-bankers',
        name: "Deadlocks & Banker's Algorithm",
        description: "Four Coffman conditions (mutual exclusion, hold & wait, no preemption, circular wait) and avoidance.",
        difficulty: 'Advanced',
        keyTerms: ['Coffman conditions', 'circular wait', "Banker's algorithm", 'safe state', 'resource allocation graph']
      },
      {
        id: 'virtual-memory-paging',
        name: 'Virtual Memory & Paging',
        description: 'Translating virtual addresses to physical RAM using page tables, TLB cache, and page faults.',
        difficulty: 'Advanced',
        keyTerms: ['page table', 'Translation Lookaside Buffer (TLB)', 'page fault', 'frame', 'swap space']
      },
      {
        id: 'file-systems-inodes',
        name: 'File Systems & Inodes',
        description: 'How files are tracked on disk: inode tables, data blocks, hard links, and directory trees.',
        difficulty: 'Intermediate',
        keyTerms: ['inode metadata', 'data blocks', 'hard link vs symlink', 'directory structure', 'superblock']
      }
    ]
  },
  {
    id: 'computer-networks',
    name: 'Computer Networks',
    icon: 'Wifi',
    badge: 'Global Packet Highways',
    description: 'Protocol stacks, packet switching, routing algorithms, transport handshakes, and cyber security.',
    color: '#a855f7',
    gradient: 'from-purple-500/20 via-cyan-500/20 to-blue-500/20',
    concepts: [
      {
        id: 'osi-tcpip-models',
        name: 'OSI 7-Layer & TCP/IP Models',
        description: 'Layered encapsulation from Physical and Data Link to Network, Transport, and Application layers.',
        difficulty: 'Beginner',
        keyTerms: ['OSI 7 layers', 'packet encapsulation', 'Transport layer', 'Network IP layer', 'headers and payload']
      },
      {
        id: 'tcp-handshake-udp',
        name: 'TCP 3-Way Handshake vs UDP',
        description: 'Reliable connection-oriented transmission with SYN-ACK, flow control, vs low-latency UDP datagrams.',
        difficulty: 'Beginner',
        keyTerms: ['3-way handshake (SYN, SYN-ACK, ACK)', 'TCP reliability', 'flow control (window)', 'UDP datagrams']
      },
      {
        id: 'ip-addressing-subnetting',
        name: 'IP Addressing & Subnet Masks (CIDR)',
        description: 'IPv4 vs IPv6, network prefixes, host masks, CIDR notation (/24), and NAT address translation.',
        difficulty: 'Intermediate',
        keyTerms: ['IPv4 address', 'subnet mask', 'CIDR notation', 'Network Address Translation (NAT)', 'private IP']
      },
      {
        id: 'dns-dhcp',
        name: 'DNS Resolution & DHCP Lease',
        description: 'Hierarchical domain name lookup (Root, TLD, Authoritative) and automatic dynamic host IP assignment.',
        difficulty: 'Intermediate',
        keyTerms: ['DNS root server', 'TLD nameserver', 'A and CNAME records', 'recursive resolver', 'DHCP lease DORA']
      },
      {
        id: 'routing-bgp-ospf',
        name: 'Routing Protocols & Packet Forwarding',
        description: 'Autonomous systems, link-state routing (OSPF), path-vector border routing (BGP), and hop counts.',
        difficulty: 'Advanced',
        keyTerms: ['router routing table', 'OSPF link-state', 'BGP autonomous systems', 'hop count', 'Time to Live (TTL)']
      },
      {
        id: 'http-https-tls',
        name: 'HTTP/HTTPS, WebSockets & TLS Security',
        description: 'Stateless request-response cycles, full-duplex persistent sockets, and symmetric/asymmetric TLS encryption.',
        difficulty: 'Intermediate',
        keyTerms: ['HTTP request/response', 'TLS handshake', 'symmetric encryption', 'certificate authority', 'WebSockets']
      }
    ]
  }
];
