'use client';

import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, Pause, Square, ArrowLeft, Volume2, VolumeX, 
  FastForward, Rewind, Settings2, Sparkles, AlertCircle 
} from 'lucide-react';

interface AudioPlayerProps {
  isOpen: boolean;
  onClose: () => void;
  storyTitle: string;
  topicName: string;
  conceptName: string;
  paragraphs: string[];
}

export default function AudioPlayer({
  isOpen,
  onClose,
  storyTitle,
  topicName,
  conceptName,
  paragraphs,
}: AudioPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentParagraphIndex, setCurrentParagraphIndex] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1.0);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoiceIndex, setSelectedVoiceIndex] = useState<number>(0);
  const [isMuted, setIsMuted] = useState(false);
  const [unsupported, setUnsupported] = useState(false);
  const [showVoiceSettings, setShowVoiceSettings] = useState(false);

  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Initialize Speech Synthesis and Voices
  useEffect(() => {
    if (typeof window === 'undefined') return;

    if (!('speechSynthesis' in window)) {
      setUnsupported(true);
      return;
    }

    const loadVoices = () => {
      const availableVoices = window.speechSynthesis.getVoices();
      if (availableVoices && availableVoices.length > 0) {
        setVoices(availableVoices);
        // Find preferred English voice
        const preferred = availableVoices.findIndex(v => 
          (v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Enhanced') || v.name.includes('Samantha') || v.name.includes('David')))
        );
        setSelectedVoiceIndex(preferred !== -1 ? preferred : 0);
      }
    };

    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;

    return () => {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Speak specific paragraph
  const speakParagraph = (index: number) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    window.speechSynthesis.cancel();

    if (index >= paragraphs.length) {
      setIsPlaying(false);
      setCurrentParagraphIndex(0);
      return;
    }

    // Clean markdown asterisks for natural reading
    const rawText = paragraphs[index] || '';
    const cleanText = rawText.replace(/\*\*/g, '').replace(/<[^>]*>/g, '');

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utteranceRef.current = utterance;

    if (voices[selectedVoiceIndex]) {
      utterance.voice = voices[selectedVoiceIndex];
    }

    utterance.rate = playbackRate;
    utterance.volume = isMuted ? 0 : 1;
    utterance.pitch = 1.0;

    utterance.onend = () => {
      if (index + 1 < paragraphs.length) {
        setCurrentParagraphIndex(index + 1);
        speakParagraph(index + 1);
      } else {
        setIsPlaying(false);
        setCurrentParagraphIndex(0);
      }
    };

    utterance.onerror = (e) => {
      console.warn('Speech synthesis error or interrupt:', e);
      setIsPlaying(false);
    };

    window.speechSynthesis.speak(utterance);
    setIsPlaying(true);
  };

  const handlePlayPause = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    if (isPlaying) {
      window.speechSynthesis.pause();
      setIsPlaying(false);
    } else {
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
        setIsPlaying(true);
      } else {
        speakParagraph(currentParagraphIndex);
      }
    }
  };

  const handleStop = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    setIsPlaying(false);
    setCurrentParagraphIndex(0);
  };

  const handleNext = () => {
    if (currentParagraphIndex < paragraphs.length - 1) {
      const nextIdx = currentParagraphIndex + 1;
      setCurrentParagraphIndex(nextIdx);
      if (isPlaying) {
        speakParagraph(nextIdx);
      }
    }
  };

  const handlePrev = () => {
    if (currentParagraphIndex > 0) {
      const prevIdx = currentParagraphIndex - 1;
      setCurrentParagraphIndex(prevIdx);
      if (isPlaying) {
        speakParagraph(prevIdx);
      }
    }
  };

  const handleSeek = (index: number) => {
    setCurrentParagraphIndex(index);
    if (isPlaying) {
      speakParagraph(index);
    }
  };

  const handleRateChange = (newRate: number) => {
    setPlaybackRate(newRate);
    if (isPlaying) {
      speakParagraph(currentParagraphIndex);
    }
  };

  const handleClose = () => {
    handleStop();
    onClose();
  };

  if (!isOpen) return null;

  const progressPercent = ((currentParagraphIndex + 1) / Math.max(paragraphs.length, 1)) * 100;

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-between bg-[#04040a]/95 backdrop-blur-2xl text-white p-4 sm:p-8 animate-in fade-in duration-300 overflow-y-auto">
      
      {/* Top Header */}
      <div className="flex items-center justify-between max-w-4xl w-full mx-auto pb-4 border-b border-purple-900/40">
        <button
          onClick={handleClose}
          className="flex items-center gap-2 px-3 py-2 rounded-xl bg-purple-950/40 border border-purple-800/40 hover:border-cyan-400 text-sm font-medium text-cyan-300 transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Story</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 rounded-full text-xs font-mono bg-purple-900/40 border border-purple-700/40 text-purple-300">
            {topicName}
          </span>
          <span className="px-2.5 py-1 rounded-full text-xs font-mono bg-cyan-950/50 border border-cyan-500/40 text-cyan-300">
            {conceptName}
          </span>
        </div>
      </div>

      {/* Main Visualizer & Content */}
      <div className="max-w-3xl w-full mx-auto my-auto py-8 flex flex-col items-center text-center">
        
        {unsupported && (
          <div className="w-full mb-6 p-4 rounded-2xl bg-amber-950/30 border border-amber-500/40 text-amber-300 text-xs flex items-center gap-3 text-left">
            <AlertCircle className="w-5 h-5 flex-shrink-0 text-amber-400" />
            <span>
              Your browser does not currently provide text-to-speech synthesis. You can continue reading the story directly on the previous page.
            </span>
          </div>
        )}

        {/* Cyber Holographic Orb / Visualizer */}
        <div className="relative w-48 h-48 sm:w-56 sm:h-56 rounded-full flex items-center justify-center p-3 mb-8">
          {/* Animated Glowing Ring */}
          <div className={`absolute inset-0 rounded-full bg-gradient-to-tr from-purple-600 via-cyan-400 to-blue-500 blur-xl opacity-30 transition-all duration-500 ${isPlaying ? 'scale-110 opacity-60' : 'scale-95 opacity-20'}`} />
          
          <div className="relative w-full h-full rounded-full bg-cyber-dark border-2 border-purple-500/40 flex flex-col items-center justify-center p-6 shadow-neon-purple">
            
            {/* Animated Audio Equalizer Bars */}
            <div className="flex items-end justify-center gap-1.5 h-14 mb-2">
              <span className={`w-1.5 bg-cyan-400 rounded-full transition-all ${isPlaying ? 'animate-wave-1' : 'h-2'}`} />
              <span className={`w-1.5 bg-purple-400 rounded-full transition-all ${isPlaying ? 'animate-wave-2' : 'h-3'}`} />
              <span className={`w-1.5 bg-blue-400 rounded-full transition-all ${isPlaying ? 'animate-wave-3' : 'h-2'}`} />
              <span className={`w-1.5 bg-cyan-300 rounded-full transition-all ${isPlaying ? 'animate-wave-4' : 'h-4'}`} />
              <span className={`w-1.5 bg-purple-500 rounded-full transition-all ${isPlaying ? 'animate-wave-5' : 'h-2'}`} />
            </div>

            <span className="text-[11px] font-mono tracking-widest uppercase text-cyan-400">
              {isPlaying ? 'Synthesizing Audio' : 'Audio Ready'}
            </span>
          </div>
        </div>

        {/* Story Title */}
        <h2 className="text-xl sm:text-2xl font-black tracking-wide text-white mb-3 max-w-xl">
          {storyTitle}
        </h2>

        {/* Paragraph Reader Subtitle / Text Card */}
        <div className="w-full max-w-2xl bg-cyber-card/80 border border-purple-900/40 rounded-2xl p-5 mb-6 text-left shadow-cyber-card">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono text-purple-400">
              Section {currentParagraphIndex + 1} of {paragraphs.length}
            </span>
            <span className="text-xs text-gray-400 font-mono">
              {Math.round(progressPercent)}%
            </span>
          </div>
          <p className="text-sm sm:text-base text-gray-200 leading-relaxed max-h-36 overflow-y-auto pr-2">
            {paragraphs[currentParagraphIndex]?.replace(/\*\*/g, '')}
          </p>
        </div>

        {/* Progress Timeline Scrubber */}
        <div className="w-full max-w-2xl flex items-center gap-2 mb-8">
          {paragraphs.map((_, idx) => (
            <button
              key={idx}
              onClick={() => handleSeek(idx)}
              className={`flex-1 h-2 rounded-full transition-all duration-300 ${
                idx === currentParagraphIndex
                  ? 'bg-gradient-to-r from-purple-500 to-cyan-400 shadow-neon-cyan h-3'
                  : idx < currentParagraphIndex
                  ? 'bg-purple-600'
                  : 'bg-gray-800 hover:bg-gray-700'
              }`}
              title={`Jump to paragraph ${idx + 1}`}
            />
          ))}
        </div>

        {/* Main Playback Control Bar */}
        <div className="flex items-center justify-center gap-4 sm:gap-6">
          
          {/* Previous */}
          <button
            onClick={handlePrev}
            disabled={currentParagraphIndex === 0}
            className="p-3 rounded-full bg-purple-950/40 border border-purple-800/40 text-gray-300 hover:text-cyan-400 disabled:opacity-30 disabled:hover:text-gray-300 transition-all"
            title="Previous Paragraph"
          >
            <Rewind className="w-5 h-5" />
          </button>

          {/* Stop */}
          <button
            onClick={handleStop}
            className="p-3 rounded-full bg-rose-950/40 border border-rose-800/40 text-rose-400 hover:bg-rose-900/50 transition-all"
            title="Stop Playback"
          >
            <Square className="w-5 h-5" />
          </button>

          {/* Play / Pause Primary Button */}
          <button
            onClick={handlePlayPause}
            className="w-16 h-16 rounded-full bg-gradient-to-r from-purple-600 to-cyan-500 flex items-center justify-center text-white shadow-neon-purple hover:scale-105 active:scale-95 transition-all"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <Pause className="w-7 h-7" />
            ) : (
              <Play className="w-7 h-7 ml-1" />
            )}
          </button>

          {/* Next */}
          <button
            onClick={handleNext}
            disabled={currentParagraphIndex >= paragraphs.length - 1}
            className="p-3 rounded-full bg-purple-950/40 border border-purple-800/40 text-gray-300 hover:text-cyan-400 disabled:opacity-30 disabled:hover:text-gray-300 transition-all"
            title="Next Paragraph"
          >
            <FastForward className="w-5 h-5" />
          </button>

          {/* Mute Toggle */}
          <button
            onClick={() => setIsMuted(!isMuted)}
            className="p-3 rounded-full bg-purple-950/40 border border-purple-800/40 text-gray-300 hover:text-cyan-400 transition-all"
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeX className="w-5 h-5 text-rose-400" /> : <Volume2 className="w-5 h-5" />}
          </button>

        </div>

      </div>

      {/* Bottom Bar: Speed & Voice Selector */}
      <div className="max-w-4xl w-full mx-auto pt-4 border-t border-purple-900/40 flex flex-wrap items-center justify-between gap-4">
        
        {/* Playback Speed selector */}
        <div className="flex items-center gap-1.5 bg-cyber-card border border-purple-900/40 p-1 rounded-xl">
          <span className="text-[11px] font-mono text-gray-400 px-2">Speed:</span>
          {[0.75, 1.0, 1.25, 1.5].map((rate) => (
            <button
              key={rate}
              onClick={() => handleRateChange(rate)}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono font-medium transition-all ${
                playbackRate === rate
                  ? 'bg-cyan-500 text-black font-bold shadow-neon-blue'
                  : 'text-gray-300 hover:text-white'
              }`}
            >
              {rate}x
            </button>
          ))}
        </div>

        {/* Voice Selector */}
        {voices.length > 0 && (
          <div className="flex items-center gap-2">
            <Settings2 className="w-4 h-4 text-purple-400" />
            <select
              value={selectedVoiceIndex}
              onChange={(e) => setSelectedVoiceIndex(Number(e.target.value))}
              className="bg-cyber-card border border-purple-800/40 text-xs text-gray-200 rounded-xl px-2.5 py-1.5 focus:outline-none focus:border-cyan-400 max-w-[220px] truncate"
            >
              {voices.map((v, i) => (
                <option key={i} value={i} className="bg-cyber-dark text-gray-200">
                  {v.name} ({v.lang})
                </option>
              ))}
            </select>
          </div>
        )}

      </div>

    </div>
  );
}
