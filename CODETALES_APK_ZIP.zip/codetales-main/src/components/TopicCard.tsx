'use client';

import React from 'react';
import Link from 'next/link';
import { 
  Terminal, Cpu, Coffee, FileCode2, Layers, Network, 
  Sparkles, Boxes, Globe, Palette, Code, Database, 
  HardDrive, Wifi, ChevronRight, BookOpen
} from 'lucide-react';
import { Topic } from '@/types';

// Map icon string to Lucide component
const iconMap: Record<string, React.ElementType> = {
  Terminal,
  Cpu,
  Coffee,
  FileCode2,
  Layers,
  Network,
  Sparkles,
  Boxes,
  Globe,
  Palette,
  Code,
  Database,
  HardDrive,
  Wifi,
};

interface TopicCardProps {
  topic: Topic;
  index: number;
}

export default function TopicCard({ topic, index }: TopicCardProps) {
  const IconComponent = iconMap[topic.icon] || BookOpen;

  return (
    <Link
      href={`/topic/${topic.id}`}
      className="group relative flex flex-col justify-between p-4 sm:p-5 rounded-2xl bg-cyber-card/90 border border-purple-900/40 hover:border-cyan-400/80 transition-all duration-300 hover:shadow-neon-cyan hover:-translate-y-1 overflow-hidden"
    >
      {/* Background ambient radial glow on hover */}
      <div 
        className="absolute -right-8 -top-8 w-28 h-28 rounded-full blur-2xl opacity-10 group-hover:opacity-30 transition-opacity pointer-events-none"
        style={{ backgroundColor: topic.color }}
      />

      <div>
        {/* Top bar with icon and index/badge */}
        <div className="flex items-center justify-between mb-3">
          <div 
            className="w-10 h-10 rounded-xl flex items-center justify-center border transition-all duration-300 group-hover:scale-110"
            style={{ 
              backgroundColor: `${topic.color}15`,
              borderColor: `${topic.color}40`,
              color: topic.color
            }}
          >
            <IconComponent className="w-5 h-5" />
          </div>
          <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-purple-950/60 border border-purple-800/40 text-purple-300">
            #{String(index + 1).padStart(2, '0')}
          </span>
        </div>

        {/* Title and subtitle */}
        <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-cyan-300 transition-colors line-clamp-1">
          {topic.name}
        </h3>
        <p className="text-xs text-gray-400 mt-1 line-clamp-2 leading-relaxed">
          {topic.description}
        </p>
      </div>

      {/* Footer info: Concepts count and Action arrow */}
      <div className="mt-4 pt-3 border-t border-purple-900/30 flex items-center justify-between">
        <span className="text-[11px] font-medium text-cyan-400/90 flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
          {topic.concepts.length} Concepts
        </span>
        <div className="flex items-center text-xs font-semibold text-purple-400 group-hover:text-cyan-400 transition-colors gap-0.5">
          <span>Explore</span>
          <ChevronRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
        </div>
      </div>
    </Link>
  );
}
