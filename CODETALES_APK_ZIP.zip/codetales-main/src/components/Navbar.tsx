'use client';

import React, { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { 
  BookOpen, Sparkles, User, Key, Menu, X, LogOut, 
  Compass, BarChart3, Settings, Shield, ChevronDown 
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import ApiKeyModal from './ApiKeyModal';

export default function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const { user, isLoading, logout } = useAuth();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [showKeyModal, setShowKeyModal] = useState(false);

  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setProfileDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSignOut = async () => {
    setProfileDropdownOpen(false);
    setMobileMenuOpen(false);
    await logout();
    router.push('/');
  };

  const navLinks = [
    { href: '/', label: 'Home', icon: Compass },
    { href: '/#topics', label: 'Topics', icon: BookOpen },
    { href: '/profile', label: 'Journey', icon: BarChart3 },
  ];

  return (
    <>
      <nav className="sticky top-0 z-50 backdrop-blur-md bg-cyber-dark/85 border-b border-purple-900/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2 group">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 via-indigo-600 to-cyan-500 p-[2px] transition-transform duration-300 group-hover:scale-105 shadow-neon-purple">
                <div className="w-full h-full bg-cyber-dark rounded-[10px] flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-cyan-400 group-hover:text-purple-400 transition-colors" />
                </div>
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-black tracking-wider bg-gradient-to-r from-purple-400 via-cyan-400 to-blue-400 bg-clip-text text-transparent">
                  CODETALES
                </span>
                <span className="text-[10px] font-mono tracking-widest text-gray-400 -mt-1 uppercase">
                  AI CS Allegories
                </span>
              </div>
            </Link>

            {/* Desktop Navigation Links */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => {
                const Icon = link.icon;
                const isActive = pathname === link.href;
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                      isActive
                        ? 'text-cyan-400 bg-cyan-950/30 border border-cyan-500/30 shadow-neon-blue'
                        : 'text-gray-300 hover:text-white hover:bg-purple-950/20'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {link.label}
                  </Link>
                );
              })}
            </div>

            {/* Right Actions: AI Key & Profile/Auth */}
            <div className="hidden md:flex items-center gap-3">
              
              {/* AI Key Button (Available before and after login) */}
              <button
                onClick={() => setShowKeyModal(true)}
                title="Configure AI Model & Tokens (Hugging Face / Gemini)"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono border border-purple-500/30 bg-purple-950/20 text-purple-300 hover:border-cyan-400 hover:bg-purple-900/30 transition-all shadow-sm"
              >
                <Key className="w-3.5 h-3.5 text-cyan-400" />
                <span>AI Key</span>
              </button>

              {/* Authentication section with loading skeleton */}
              {isLoading ? (
                <div className="w-24 h-8 bg-purple-950/30 animate-pulse rounded-lg border border-purple-900/30" />
              ) : user ? (
                /* AFTER LOGIN: Hide Sign In / Get Started, display Profile Avatar Icon & Dropdown */
                <div className="relative" ref={dropdownRef}>
                  <button
                    onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                    aria-label="User Profile Menu"
                    className="flex items-center gap-2 p-1 pl-1.5 pr-2.5 rounded-full bg-cyber-card border border-purple-600/50 hover:border-cyan-400 transition-all duration-200 hover:shadow-neon-cyan group"
                  >
                    {user.avatarUrl ? (
                      <img
                        src={user.avatarUrl}
                        alt={user.name}
                        className="w-7 h-7 rounded-full object-cover border border-cyan-400"
                      />
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-purple-600 to-cyan-400 flex items-center justify-center text-[11px] font-bold text-white uppercase shadow-sm">
                        {user.name ? user.name.substring(0, 2) : 'U'}
                      </div>
                    )}
                    <span className="text-xs font-semibold text-gray-200 max-w-[100px] truncate group-hover:text-cyan-300">
                      {user.name}
                    </span>
                    <ChevronDown className={`w-3.5 h-3.5 text-gray-400 transition-transform duration-200 ${profileDropdownOpen ? 'rotate-180 text-cyan-400' : ''}`} />
                  </button>

                  {/* Profile Dropdown Menu */}
                  {profileDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-64 rounded-2xl bg-cyber-card border border-purple-500/40 shadow-neon-purple p-2 text-xs space-y-1 animate-in fade-in zoom-in-95 duration-150 z-50">
                      
                      {/* User Header */}
                      <div className="px-3 py-2.5 bg-purple-950/40 rounded-xl border border-purple-900/40 mb-1">
                        <div className="flex items-center gap-2.5">
                          {user.avatarUrl ? (
                            <img src={user.avatarUrl} alt={user.name} className="w-8 h-8 rounded-full object-cover" />
                          ) : (
                            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-600 to-cyan-400 flex items-center justify-center text-xs font-bold text-white uppercase">
                              {user.name.substring(0, 2)}
                            </div>
                          )}
                          <div className="overflow-hidden">
                            <div className="font-bold text-white truncate text-sm">{user.name}</div>
                            <div className="text-[11px] font-mono text-gray-400 truncate">{user.email}</div>
                          </div>
                        </div>
                      </div>

                      {/* Menu Options */}
                      <Link
                        href="/profile"
                        onClick={() => setProfileDropdownOpen(false)}
                        className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-gray-200 hover:text-cyan-300 hover:bg-purple-950/40 transition-colors"
                      >
                        <User className="w-4 h-4 text-purple-400" />
                        <span>Profile & Vault</span>
                      </Link>

                      <Link
                        href="/profile?tab=edit"
                        onClick={() => setProfileDropdownOpen(false)}
                        className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-gray-200 hover:text-cyan-300 hover:bg-purple-950/40 transition-colors"
                      >
                        <Settings className="w-4 h-4 text-cyan-400" />
                        <span>Edit Profile</span>
                      </Link>

                      <Link
                        href="/profile?tab=security"
                        onClick={() => setProfileDropdownOpen(false)}
                        className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-gray-200 hover:text-cyan-300 hover:bg-purple-950/40 transition-colors"
                      >
                        <Shield className="w-4 h-4 text-indigo-400" />
                        <span>Change Password</span>
                      </Link>

                      <Link
                        href="/profile?tab=learning"
                        onClick={() => setProfileDropdownOpen(false)}
                        className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-gray-200 hover:text-cyan-300 hover:bg-purple-950/40 transition-colors"
                      >
                        <BarChart3 className="w-4 h-4 text-emerald-400" />
                        <span>Learning Progress</span>
                      </Link>

                      <div className="border-t border-purple-900/40 my-1"></div>

                      <button
                        onClick={handleSignOut}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-rose-300 hover:bg-rose-950/30 transition-colors text-left font-medium"
                      >
                        <LogOut className="w-4 h-4 text-rose-400" />
                        <span>Sign Out</span>
                      </button>

                    </div>
                  )}
                </div>
              ) : (
                /* BEFORE LOGIN: Show Sign In and Get Started */
                <div className="flex items-center gap-2">
                  <Link
                    href="/auth/login"
                    className="px-3.5 py-1.5 rounded-lg text-xs font-semibold text-gray-300 hover:text-white transition-colors"
                  >
                    Sign In
                  </Link>
                  <Link
                    href="/auth/signup"
                    className="px-4 py-1.5 rounded-lg text-xs font-bold bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 text-white shadow-neon-purple hover:scale-105 active:scale-95 transition-all"
                  >
                    Get Started
                  </Link>
                </div>
              )}

            </div>

            {/* Mobile Hamburger & Actions */}
            <div className="flex md:hidden items-center gap-2">
              <button
                onClick={() => setShowKeyModal(true)}
                className="p-2 text-purple-400 hover:bg-purple-950/30 rounded-lg"
                title="AI Key"
              >
                <Key className="w-4 h-4" />
              </button>

              {/* Mobile Profile Quick Avatar */}
              {user && (
                <Link
                  href="/profile"
                  className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-600 to-cyan-400 p-[1.5px] flex items-center justify-center text-xs font-bold text-white uppercase shadow-neon-blue"
                  title="View Profile"
                >
                  <div className="w-full h-full rounded-full bg-cyber-dark flex items-center justify-center">
                    {user.avatarUrl ? (
                      <img src={user.avatarUrl} alt={user.name} className="w-full h-full rounded-full object-cover" />
                    ) : (
                      user.name.substring(0, 2)
                    )}
                  </div>
                </Link>
              )}

              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-gray-300 hover:text-white focus:outline-none"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>

          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-cyber-dark/95 border-b border-purple-900/50 px-4 pt-2 pb-5 space-y-2">
            {navLinks.map((link) => {
              const Icon = link.icon;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-base font-medium text-gray-200 hover:bg-purple-950/30 hover:text-cyan-400 transition-colors"
                >
                  <Icon className="w-5 h-5" />
                  {link.label}
                </Link>
              );
            })}

            <div className="pt-3 border-t border-purple-900/40 space-y-2">
              {user ? (
                <>
                  <div className="flex items-center justify-between px-3 py-2.5 bg-purple-950/30 rounded-xl border border-purple-900/40">
                    <Link
                      href="/profile"
                      onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-2.5 overflow-hidden"
                    >
                      <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-600 to-cyan-400 flex items-center justify-center text-xs font-bold text-white uppercase flex-shrink-0">
                        {user.name.substring(0, 2)}
                      </div>
                      <div className="truncate">
                        <div className="text-sm font-bold text-white truncate">{user.name}</div>
                        <div className="text-[10px] text-gray-400 truncate">{user.email}</div>
                      </div>
                    </Link>
                    <button
                      onClick={handleSignOut}
                      className="text-xs text-rose-400 hover:underline px-2 py-1 font-semibold"
                    >
                      Sign Out
                    </button>
                  </div>
                </>
              ) : (
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <Link
                    href="/auth/login"
                    onClick={() => setMobileMenuOpen(false)}
                    className="w-full text-center py-2 px-3 rounded-lg border border-purple-700/40 text-sm font-medium text-gray-200 hover:bg-purple-950/30"
                  >
                    Sign In
                  </Link>
                  <Link
                    href="/auth/signup"
                    onClick={() => setMobileMenuOpen(false)}
                    className="w-full text-center py-2 px-3 rounded-lg bg-gradient-to-r from-purple-600 to-cyan-500 text-sm font-semibold text-white shadow-neon-purple"
                  >
                    Get Started
                  </Link>
                </div>
              )}
            </div>
          </div>
        )}
      </nav>

      <ApiKeyModal isOpen={showKeyModal} onClose={() => setShowKeyModal(false)} />
    </>
  );
}
