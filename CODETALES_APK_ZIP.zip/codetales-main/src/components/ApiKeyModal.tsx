'use client';

import React, { useState, useEffect } from 'react';
import { X, Key, ShieldCheck, ExternalLink, Check, Sparkles, Cpu, Layers } from 'lucide-react';
import { 
  getCustomHfToken, setCustomHfToken, 
  getCustomHfModel, setCustomHfModel,
  getCustomApiKey, setCustomApiKey 
} from '@/lib/storage';
import { VERIFIED_TEXT_MODELS } from '@/lib/huggingface';

interface ApiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ApiKeyModal({ isOpen, onClose }: ApiKeyModalProps) {
  const [activeTab, setActiveTab] = useState<'huggingface' | 'gemini'>('huggingface');
  const [hfToken, setHfToken] = useState('');
  const [hfModel, setHfModel] = useState('Qwen/Qwen2.5-72B-Instruct');
  const [geminiKey, setGeminiKey] = useState('');
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setHfToken(getCustomHfToken());
      setHfModel(getCustomHfModel() || 'Qwen/Qwen2.5-72B-Instruct');
      setGeminiKey(getCustomApiKey());
      setSaved(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSave = () => {
    setCustomHfToken(hfToken);
    setCustomHfModel(hfModel);
    setCustomApiKey(geminiKey);
    setSaved(true);
    setTimeout(() => {
      onClose();
    }, 900);
  };

  const handleClear = () => {
    setHfToken('');
    setCustomHfToken('');
    setHfModel('Qwen/Qwen2.5-72B-Instruct');
    setCustomHfModel('Qwen/Qwen2.5-72B-Instruct');
    setGeminiKey('');
    setCustomApiKey('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-cyber-card border border-purple-500/40 rounded-3xl p-6 sm:p-7 shadow-neon-purple space-y-5">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-purple-900/40">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-gradient-to-tr from-purple-600 to-cyan-500 rounded-xl shadow-neon-blue">
              <Key className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <span>AI Ecosystem Settings</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950 border border-cyan-500/40 text-cyan-300">
                  Transformers
                </span>
              </h3>
              <p className="text-xs text-gray-400">Configure Hugging Face & AI inference endpoints</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-white rounded-lg hover:bg-purple-950/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab selection */}
        <div className="flex items-center gap-2 p-1 bg-cyber-surface border border-purple-900/40 rounded-xl">
          <button
            type="button"
            onClick={() => setActiveTab('huggingface')}
            className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'huggingface'
                ? 'bg-gradient-to-r from-purple-600 to-cyan-500 text-white shadow-neon-purple'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Hugging Face Transformers (Primary)</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('gemini')}
            className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'gemini'
                ? 'bg-gradient-to-r from-purple-600 to-cyan-500 text-white shadow-neon-purple'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Gemini Backup</span>
          </button>
        </div>

        {/* HUGGING FACE TAB */}
        {activeTab === 'huggingface' && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="p-3.5 bg-purple-950/30 border border-purple-700/40 rounded-2xl text-xs text-purple-200 flex items-start gap-2.5 leading-relaxed">
              <ShieldCheck className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
              <span>
                CODETALES uses Hugging Face Inference Providers to synthesize educational stories and generate adaptive quizzes. You can configure <strong className="text-white">HUGGINGFACE_API_KEY</strong> on your server, or provide your token below for browser sessions.
              </span>
            </div>

            {/* Hugging Face Token input */}
            <div>
              <label className="block text-xs font-mono text-gray-300 mb-1.5">
                Hugging Face Access Token (User Read Token)
              </label>
              <input
                type="password"
                value={hfToken}
                onChange={(e) => setHfToken(e.target.value)}
                placeholder="hf_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                className="w-full px-3.5 py-2.5 bg-cyber-surface border border-purple-800/40 rounded-xl text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 font-mono"
              />
            </div>

            {/* Model Selector */}
            <div>
              <label className="block text-xs font-mono text-gray-300 mb-1.5">
                Selected Transformers Model
              </label>
              <select
                value={hfModel}
                onChange={(e) => setHfModel(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-cyber-surface border border-purple-800/40 rounded-xl text-xs text-gray-200 focus:outline-none focus:border-cyan-400 font-mono"
              >
                {VERIFIED_TEXT_MODELS.map((m) => (
                  <option key={m} value={m} className="bg-cyber-dark text-white">
                    {m} {m === 'Qwen/Qwen2.5-72B-Instruct' ? '(Recommended)' : ''}
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-gray-400 mt-1">
                Verified chat-completion models supported by Hugging Face Inference Providers.
              </p>
            </div>

            <div className="pt-1 flex items-center justify-between text-xs">
              <a
                href="https://huggingface.co/settings/tokens"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-cyan-400 hover:text-cyan-300 transition-colors underline"
              >
                <span>Get a free Hugging Face token (read access)</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        )}

        {/* GEMINI TAB */}
        {activeTab === 'gemini' && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="p-3.5 bg-cyan-950/20 border border-cyan-500/30 rounded-2xl text-xs text-cyan-200 flex items-start gap-2.5 leading-relaxed">
              <ShieldCheck className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
              <span>
                Optional fallback provider. If you have a Google AI Studio key, you can enter it here to enable Gemini 1.5/2.0 as an alternate story generation backend.
              </span>
            </div>

            <div>
              <label className="block text-xs font-mono text-gray-300 mb-1.5">
                Gemini API Key
              </label>
              <input
                type="password"
                value={geminiKey}
                onChange={(e) => setGeminiKey(e.target.value)}
                placeholder="AIzaSy..."
                className="w-full px-3.5 py-2.5 bg-cyber-surface border border-purple-800/40 rounded-xl text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 font-mono"
              />
            </div>

            <a
              href="https://aistudio.google.com/app/apikey"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-xs text-purple-400 hover:text-cyan-400 transition-colors"
            >
              <span>Get a free Gemini API key from Google AI Studio</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        )}

        {/* Footer actions */}
        <div className="mt-6 flex items-center justify-between pt-4 border-t border-purple-900/40">
          <button
            onClick={handleClear}
            className="text-xs text-gray-400 hover:text-rose-400 transition-colors"
          >
            Clear Stored Keys
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded-xl border border-gray-700 text-xs font-medium text-gray-300 hover:bg-gray-800 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 text-xs font-bold text-white shadow-neon-purple hover:scale-105 active:scale-95 transition-all flex items-center gap-1.5"
            >
              {saved ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Settings Saved!</span>
                </>
              ) : (
                <span>Save Configuration</span>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
