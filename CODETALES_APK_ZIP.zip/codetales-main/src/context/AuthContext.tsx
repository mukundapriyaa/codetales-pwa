'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { getLocalSession, setLocalSession, LocalUserSession } from '@/lib/storage';

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  avatarUrl?: string;
  isGuest?: boolean;
  createdAt: string;
}

interface AuthContextType {
  user: AuthUser | null;
  isLoading: boolean;
  login: (email: string, password?: string) => Promise<void>;
  signup: (email: string, password: string, name: string) => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (updates: { name?: string; avatarUrl?: string }) => Promise<void>;
  changePassword: (newPassword: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AUTH_CHANGE_EVENT = 'codetales-auth-change';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Sync state and notify all listeners
  const notifyUserChange = (newUser: AuthUser | null) => {
    setUser(newUser);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(AUTH_CHANGE_EVENT, { detail: newUser }));
    }
  };

  useEffect(() => {
    let mounted = true;

    const initializeAuth = async () => {
      try {
        // 1. First check local session store
        const local = getLocalSession();
        // A guest user is not considered a logged-in user in terms of account state
        if (local && !local.isGuest) {
          if (mounted) {
            setUser({
              id: local.id,
              email: local.email,
              name: local.name,
              avatarUrl: local.avatarSeed || '',
              isGuest: false,
              createdAt: local.createdAt || new Date().toISOString(),
            });
          }
        }

        // 2. Check Supabase session if configured
        if (isSupabaseConfigured) {
          const { data } = await supabase.auth.getSession();
          if (data.session?.user && mounted) {
            const u = data.session.user;
            const authUser: AuthUser = {
              id: u.id,
              email: u.email || '',
              name: u.user_metadata?.name || u.email?.split('@')[0] || 'Coder',
              avatarUrl: u.user_metadata?.avatar_url || '',
              isGuest: false,
              createdAt: u.created_at || new Date().toISOString(),
            };
            setUser(authUser);
            setLocalSession({
              id: authUser.id,
              email: authUser.email,
              name: authUser.name,
              avatarSeed: authUser.avatarUrl,
              isGuest: false,
              createdAt: authUser.createdAt,
            });
          }
        }
      } catch (err) {
        console.error('Failed to initialize auth:', err);
      } finally {
        if (mounted) setIsLoading(false);
      }
    };

    initializeAuth();

    // Listen to Supabase auth events
    let subscription: { unsubscribe: () => void } | null = null;
    if (isSupabaseConfigured) {
      const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
        if (!mounted) return;
        if (session?.user) {
          const u = session.user;
          const authUser: AuthUser = {
            id: u.id,
            email: u.email || '',
            name: u.user_metadata?.name || u.email?.split('@')[0] || 'Coder',
            avatarUrl: u.user_metadata?.avatar_url || '',
            isGuest: false,
            createdAt: u.created_at || new Date().toISOString(),
          };
          setUser(authUser);
          setLocalSession({
            id: authUser.id,
            email: authUser.email,
            name: authUser.name,
            avatarSeed: authUser.avatarUrl,
            isGuest: false,
            createdAt: authUser.createdAt,
          });
        } else {
          setUser(null);
          setLocalSession(null);
        }
      });
      subscription = authListener.subscription;
    }

    // Listen to internal auth change events
    const handleAuthChange = (e: Event) => {
      const customEvent = e as CustomEvent<AuthUser | null>;
      setUser(customEvent.detail || null);
    };

    window.addEventListener(AUTH_CHANGE_EVENT, handleAuthChange);

    return () => {
      mounted = false;
      if (subscription) subscription.unsubscribe();
      window.removeEventListener(AUTH_CHANGE_EVENT, handleAuthChange);
    };
  }, []);

  const login = async (email: string, password?: string) => {
    setIsLoading(true);
    try {
      if (isSupabaseConfigured && password) {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        });
        if (error) throw error;
        if (data.user) {
          const authUser: AuthUser = {
            id: data.user.id,
            email: data.user.email || email,
            name: data.user.user_metadata?.name || email.split('@')[0],
            avatarUrl: data.user.user_metadata?.avatar_url || '',
            isGuest: false,
            createdAt: data.user.created_at || new Date().toISOString(),
          };
          setLocalSession({
            id: authUser.id,
            email: authUser.email,
            name: authUser.name,
            avatarSeed: authUser.avatarUrl,
            isGuest: false,
            createdAt: authUser.createdAt,
          });
          notifyUserChange(authUser);
          return;
        }
      }

      // Local/Demo Mode fallback
      const demoUser: AuthUser = {
        id: 'usr_' + Math.random().toString(36).substring(2, 9),
        email: email.trim(),
        name: email.split('@')[0],
        avatarUrl: '',
        isGuest: false,
        createdAt: new Date().toISOString(),
      };
      setLocalSession({
        id: demoUser.id,
        email: demoUser.email,
        name: demoUser.name,
        avatarSeed: '',
        isGuest: false,
        createdAt: demoUser.createdAt,
      });
      notifyUserChange(demoUser);
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (email: string, password: string, name: string) => {
    setIsLoading(true);
    try {
      if (isSupabaseConfigured) {
        const { data, error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: {
            data: {
              name: name.trim() || email.split('@')[0],
            },
          },
        });
        if (error) throw error;
        if (data.user) {
          const authUser: AuthUser = {
            id: data.user.id,
            email: data.user.email || email,
            name: name.trim() || email.split('@')[0],
            avatarUrl: '',
            isGuest: false,
            createdAt: data.user.created_at || new Date().toISOString(),
          };
          setLocalSession({
            id: authUser.id,
            email: authUser.email,
            name: authUser.name,
            avatarSeed: '',
            isGuest: false,
            createdAt: authUser.createdAt,
          });
          notifyUserChange(authUser);
          return;
        }
      }

      // Local/Demo Mode fallback
      const newUser: AuthUser = {
        id: 'usr_' + Math.random().toString(36).substring(2, 9),
        email: email.trim(),
        name: name.trim() || email.split('@')[0],
        avatarUrl: '',
        isGuest: false,
        createdAt: new Date().toISOString(),
      };
      setLocalSession({
        id: newUser.id,
        email: newUser.email,
        name: newUser.name,
        avatarSeed: '',
        isGuest: false,
        createdAt: newUser.createdAt,
      });
      notifyUserChange(newUser);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    setIsLoading(true);
    try {
      if (isSupabaseConfigured) {
        await supabase.auth.signOut();
      }
      setLocalSession(null);
      notifyUserChange(null);
    } catch (err) {
      console.error('Logout error:', err);
      setLocalSession(null);
      notifyUserChange(null);
    } finally {
      setIsLoading(false);
    }
  };

  const updateProfile = async (updates: { name?: string; avatarUrl?: string }) => {
    if (!user) throw new Error('No authenticated user to update.');

    if (isSupabaseConfigured) {
      const { error } = await supabase.auth.updateUser({
        data: {
          name: updates.name ?? user.name,
          avatar_url: updates.avatarUrl ?? user.avatarUrl,
        },
      });
      if (error) throw error;
    }

    const updatedUser: AuthUser = {
      ...user,
      name: updates.name !== undefined ? updates.name : user.name,
      avatarUrl: updates.avatarUrl !== undefined ? updates.avatarUrl : user.avatarUrl,
    };

    setLocalSession({
      id: updatedUser.id,
      email: updatedUser.email,
      name: updatedUser.name,
      avatarSeed: updatedUser.avatarUrl,
      isGuest: false,
      createdAt: updatedUser.createdAt,
    });

    notifyUserChange(updatedUser);
  };

  const changePassword = async (newPassword: string) => {
    if (!user) throw new Error('No authenticated user to change password for.');
    if (newPassword.length < 6) {
      throw new Error('Password must be at least 6 characters.');
    }

    if (isSupabaseConfigured) {
      const { error } = await supabase.auth.updateUser({
        password: newPassword,
      });
      if (error) throw error;
    }
    // In local demo mode, simulated success is granted
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        login,
        signup,
        logout,
        updateProfile,
        changePassword,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
