'use client';

import React, { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { 
  ArrowLeft, ArrowRight, Award, CheckCircle2, XCircle, 
  RotateCcw, Home, Sparkles, BookOpen, AlertCircle, Loader2 
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { GeneratedStory, QuizQuestion, QuizResult } from '@/types';
import { getSavedStories, saveQuizResult, getCustomApiKey, getCustomHfToken, getCustomHfModel } from '@/lib/storage';

function QuizContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const storyId = searchParams.get('storyId');

  const [story, setStory] = useState<GeneratedStory | null>(null);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');

  // Active quiz state
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [result, setResult] = useState<QuizResult | null>(null);

  // Load story and fetch dynamic quiz
  useEffect(() => {
    let activeStory: GeneratedStory | null = null;

    const stored = sessionStorage.getItem('current_story');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (!storyId || parsed.id === storyId) {
          activeStory = parsed;
        }
      } catch (e) {
        console.error(e);
      }
    }

    if (!activeStory && storyId) {
      const saved = getSavedStories();
      activeStory = saved.find((s) => s.id === storyId) || null;
    }

    if (!activeStory) {
      const allSaved = getSavedStories();
      if (allSaved.length > 0) {
        activeStory = allSaved[0];
      }
    }

    if (!activeStory) {
      router.push('/customize');
      return;
    }

    setStory(activeStory);
    fetchQuiz(activeStory);
  }, [storyId, router]);

  const fetchQuiz = async (s: GeneratedStory) => {
    setLoading(true);
    setErrorMsg('');

    try {
      const customApiKey = getCustomHfToken() || getCustomApiKey();
      const hfModel = getCustomHfModel();

      const response = await fetch('/api/generate-quiz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topicName: s.topicName,
          conceptName: s.conceptName,
          storyTitle: s.title,
          storySummary: s.paragraphs.slice(0, 2).join(' '),
          customApiKey,
          hfModel,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to generate quiz.');
      }

      setQuestions(data.questions);
      setLoading(false);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Error generating quiz.');
      setLoading(false);
    }
  };

  const handleSelectOption = (questionId: number, optionId: string) => {
    if (isSubmitted) return;
    setUserAnswers((prev) => ({
      ...prev,
      [questionId]: optionId,
    }));
  };

  const handleSubmit = () => {
    if (!story || questions.length === 0) return;

    let score = 0;
    questions.forEach((q) => {
      if (userAnswers[q.id] === q.correctAnswerId) {
        score++;
      }
    });

    const percentage = Math.round((score / questions.length) * 100);

    const quizResult: QuizResult = {
      score,
      totalQuestions: questions.length,
      percentage,
      userAnswers,
      questions,
      completedAt: new Date().toISOString(),
      topicName: story.topicName,
      conceptName: story.conceptName,
    };

    setResult(quizResult);
    setIsSubmitted(true);
    saveQuizResult(quizResult);

    // Trigger gamified celebration confetti
    if (percentage >= 60) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#a855f7', '#00f0ff', '#3b82f6', '#ec4899'],
      });
    }
  };

  const handleRetry = () => {
    setUserAnswers({});
    setIsSubmitted(false);
    setResult(null);
    setCurrentIndex(0);
    if (story) {
      fetchQuiz(story);
    }
  };

  if (loading) {
    return (
      <div className="py-24 text-center max-w-md mx-auto space-y-4">
        <div className="relative w-20 h-20 mx-auto">
          <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-purple-600 to-cyan-400 blur-xl opacity-60 animate-pulse" />
          <div className="relative w-full h-full rounded-full bg-cyber-dark border border-cyan-400 flex items-center justify-center">
            <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
          </div>
        </div>
        <h2 className="text-xl font-black text-white">Synthesizing Adaptive Quiz...</h2>
        <p className="text-xs font-mono text-cyan-300">
          Generating dynamic multiple-choice assessment grounded in your story.
        </p>
      </div>
    );
  }

  if (errorMsg || questions.length === 0) {
    return (
      <div className="py-16 text-center max-w-md mx-auto space-y-4">
        <AlertCircle className="w-12 h-12 text-rose-400 mx-auto" />
        <h2 className="text-lg font-bold text-white">Quiz Generation Error</h2>
        <p className="text-xs text-rose-300">{errorMsg || 'Unable to generate questions at this time.'}</p>
        <button
          onClick={() => story && fetchQuiz(story)}
          className="px-4 py-2 rounded-xl bg-purple-600 text-white text-xs font-semibold"
        >
          Try Again
        </button>
      </div>
    );
  }

  // ==========================================
  // RESULTS VIEW (REQUIREMENT 13)
  // ==========================================
  if (isSubmitted && result) {
    const isMastery = result.percentage >= 80;
    const isPassing = result.percentage >= 60;

    return (
      <div className="max-w-3xl mx-auto py-6 sm:py-10 space-y-8 animate-in fade-in duration-300">
        
        {/* Results Banner */}
        <div className="relative overflow-hidden rounded-3xl bg-cyber-card border border-purple-500/40 p-6 sm:p-10 text-center shadow-neon-purple">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-950/60 border border-purple-500/40 text-xs font-mono text-cyan-300 mb-4">
            <Award className="w-4 h-4 text-cyan-400" />
            <span>Assessment Complete</span>
          </div>

          <h1 className="text-3xl sm:text-4xl font-black text-white">
            {isMastery ? 'Architectural Mastery!' : isPassing ? 'Solid Understanding!' : 'Keep Exploring!'}
          </h1>

          <p className="text-xs sm:text-sm text-gray-300 mt-2">
            Assessment on <strong className="text-white">{result.conceptName}</strong> ({result.topicName})
          </p>

          {/* Metric Badges */}
          <div className="mt-8 grid grid-cols-3 gap-3 sm:gap-6 max-w-lg mx-auto">
            <div className="p-4 rounded-2xl bg-purple-950/30 border border-purple-800/40">
              <div className="text-2xl sm:text-3xl font-black text-cyan-300">
                {result.score}/{result.totalQuestions}
              </div>
              <div className="text-[11px] font-mono text-gray-400 uppercase mt-1">Score</div>
            </div>

            <div className="p-4 rounded-2xl bg-purple-950/30 border border-purple-800/40">
              <div className="text-2xl sm:text-3xl font-black text-purple-400">
                {result.percentage}%
              </div>
              <div className="text-[11px] font-mono text-gray-400 uppercase mt-1">Accuracy</div>
            </div>

            <div className="p-4 rounded-2xl bg-purple-950/30 border border-purple-800/40">
              <div className="text-2xl sm:text-3xl font-black text-rose-400">
                {result.totalQuestions - result.score}
              </div>
              <div className="text-[11px] font-mono text-gray-400 uppercase mt-1">Missed</div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={handleRetry}
              className="px-5 py-2.5 rounded-xl bg-purple-950/60 border border-purple-600 hover:border-cyan-400 text-xs font-bold text-cyan-300 transition-all flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Retry Quiz</span>
            </button>

            {story && (
              <Link
                href={`/story?id=${story.id}`}
                className="px-5 py-2.5 rounded-xl bg-cyber-card border border-purple-800/40 text-xs font-semibold text-gray-200 hover:text-white transition-all flex items-center gap-2"
              >
                <BookOpen className="w-4 h-4 text-purple-400" />
                <span>Reread Story</span>
              </Link>
            )}

            <Link
              href="/"
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 text-xs font-bold text-white shadow-neon-purple hover:scale-105 transition-all flex items-center gap-2"
            >
              <Home className="w-4 h-4" />
              <span>Return Home</span>
            </Link>
          </div>
        </div>

        {/* Detailed Question Review */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <span>Detailed Answer Breakdown & Explanations</span>
          </h2>

          {questions.map((q, idx) => {
            const userAnswer = userAnswers[q.id];
            const isCorrect = userAnswer === q.correctAnswerId;

            return (
              <div
                key={q.id}
                className={`p-5 rounded-2xl border transition-all ${
                  isCorrect
                    ? 'bg-cyber-card border-emerald-500/30'
                    : 'bg-cyber-card border-rose-500/30'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono px-2 py-0.5 rounded bg-purple-950/60 border border-purple-800/40 text-purple-300">
                      Q{idx + 1}
                    </span>
                    <span className="text-sm sm:text-base font-bold text-white">
                      {q.question}
                    </span>
                  </div>
                  {isCorrect ? (
                    <span className="flex items-center gap-1 text-xs font-mono text-emerald-400 flex-shrink-0">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Correct</span>
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-xs font-mono text-rose-400 flex-shrink-0">
                      <XCircle className="w-4 h-4" />
                      <span>Incorrect</span>
                    </span>
                  )}
                </div>

                {/* Options List */}
                <div className="mt-3 space-y-1.5">
                  {q.options.map((opt) => {
                    const isUserChoice = userAnswer === opt.id;
                    const isRightAnswer = q.correctAnswerId === opt.id;

                    let optStyle = 'bg-cyber-surface border-gray-800 text-gray-400';
                    if (isRightAnswer) {
                      optStyle = 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300 font-semibold';
                    } else if (isUserChoice && !isCorrect) {
                      optStyle = 'bg-rose-950/40 border-rose-500/50 text-rose-300';
                    }

                    return (
                      <div
                        key={opt.id}
                        className={`p-2.5 rounded-xl border text-xs flex items-center justify-between ${optStyle}`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold">{opt.id}.</span>
                          <span>{opt.text}</span>
                        </div>
                        {isRightAnswer && (
                          <span className="text-[10px] font-mono uppercase text-emerald-400">Correct Answer</span>
                        )}
                        {isUserChoice && !isRightAnswer && (
                          <span className="text-[10px] font-mono uppercase text-rose-400">Your Answer</span>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Explanation */}
                <div className="mt-3 p-3 rounded-xl bg-purple-950/20 border border-purple-900/30 text-xs text-cyan-200/90 leading-relaxed">
                  <strong className="text-white font-mono">Pedagogical Explanation:</strong> {q.explanation}
                </div>
              </div>
            );
          })}
        </div>

      </div>
    );
  }

  // ==========================================
  // ACTIVE GAMIFIED QUIZ VIEW (REQUIREMENT 12)
  // ==========================================
  const currentQ = questions[currentIndex];
  const progressPercent = ((currentIndex + 1) / questions.length) * 100;
  const answeredCount = Object.keys(userAnswers).length;
  const allAnswered = answeredCount === questions.length;

  return (
    <div className="max-w-2xl mx-auto py-4 sm:py-8 space-y-8 animate-in fade-in duration-300">
      
      {/* Top Bar with Story Backlink and Neon Progress */}
      <div>
        <div className="flex items-center justify-between text-xs font-mono text-gray-400 mb-2">
          {story && (
            <Link
              href={`/story?id=${story.id}`}
              className="text-cyan-400 hover:underline flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Story</span>
            </Link>
          )}
          <span>
            Question <strong className="text-white">{currentIndex + 1}</strong> of {questions.length}
          </span>
        </div>

        {/* Neon Progress Bar */}
        <div className="w-full h-2 rounded-full bg-gray-900 overflow-hidden border border-purple-900/40">
          <div
            className="h-full bg-gradient-to-r from-purple-500 via-cyan-400 to-blue-500 shadow-neon-blue transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Gamified Question Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-cyber-card border border-purple-500/40 shadow-neon-purple space-y-6">
        
        <div className="flex items-center justify-between">
          <span className="px-3 py-1 rounded-full text-xs font-mono bg-purple-950/60 border border-purple-500/40 text-cyan-300">
            {story?.conceptName}
          </span>
          <span className="text-xs font-mono text-purple-400">
            Answered {answeredCount}/{questions.length}
          </span>
        </div>

        <h2 className="text-lg sm:text-xl font-bold text-white leading-relaxed">
          {currentQ.question}
        </h2>

        {/* 4 Glowing Answer Option Cards */}
        <div className="space-y-3">
          {currentQ.options.map((opt) => {
            const isSelected = userAnswers[currentQ.id] === opt.id;

            return (
              <button
                type="button"
                key={opt.id}
                onClick={() => handleSelectOption(currentQ.id, opt.id)}
                className={`w-full p-4 rounded-2xl border text-left transition-all duration-200 flex items-center justify-between gap-3 ${
                  isSelected
                    ? 'bg-purple-950/80 border-cyan-400 shadow-neon-cyan ring-1 ring-cyan-400/50 text-white font-semibold'
                    : 'bg-cyber-surface border-purple-900/40 hover:border-purple-600/60 text-gray-300 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-mono font-bold border transition-colors ${
                      isSelected
                        ? 'bg-cyan-500 text-black border-cyan-400 shadow-neon-blue'
                        : 'bg-purple-950/60 text-purple-300 border-purple-800/40'
                    }`}
                  >
                    {opt.id}
                  </span>
                  <span className="text-sm leading-snug">{opt.text}</span>
                </div>

                {isSelected && (
                  <CheckCircle2 className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                )}
              </button>
            );
          })}
        </div>

        {/* Question Navigation Controls */}
        <div className="pt-4 border-t border-purple-900/40 flex items-center justify-between gap-3">
          <button
            onClick={() => setCurrentIndex((prev) => Math.max(prev - 1, 0))}
            disabled={currentIndex === 0}
            className="px-4 py-2 rounded-xl bg-purple-950/40 border border-purple-800/40 text-xs font-medium text-gray-300 disabled:opacity-30 disabled:pointer-events-none hover:text-white transition-all flex items-center gap-1.5"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Previous</span>
          </button>

          {currentIndex < questions.length - 1 ? (
            <button
              onClick={() => setCurrentIndex((prev) => Math.min(prev + 1, questions.length - 1))}
              className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-bold text-white shadow-neon-purple transition-all flex items-center gap-1.5"
            >
              <span>Next</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={!allAnswered}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 text-xs font-extrabold text-white shadow-neon-purple hover:scale-105 active:scale-95 disabled:opacity-40 disabled:hover:scale-100 transition-all flex items-center gap-2"
            >
              <Award className="w-4 h-4" />
              <span>Submit & View Results</span>
            </button>
          )}
        </div>

      </div>

      {/* Progress jump pills */}
      <div className="flex items-center justify-center gap-2">
        {questions.map((q, idx) => {
          const isAnswered = Boolean(userAnswers[q.id]);
          const isCurrent = idx === currentIndex;

          return (
            <button
              key={q.id}
              onClick={() => setCurrentIndex(idx)}
              className={`w-7 h-7 rounded-lg text-xs font-mono font-bold border transition-all ${
                isCurrent
                  ? 'border-cyan-400 bg-cyan-950/80 text-cyan-300 ring-2 ring-cyan-400/30'
                  : isAnswered
                  ? 'border-purple-600 bg-purple-950/50 text-purple-300'
                  : 'border-gray-800 bg-gray-900 text-gray-500'
              }`}
            >
              {idx + 1}
            </button>
          );
        })}
      </div>

    </div>
  );
}

export default function QuizPage() {
  return (
    <Suspense fallback={<div className="p-12 text-center text-cyan-400 font-mono">Loading Assessment...</div>}>
      <QuizContent />
    </Suspense>
  );
}
