import type { Metadata, Viewport } from 'next';
import './globals.css';
import Navbar from '@/components/Navbar';
import { AuthProvider } from '@/context/AuthContext';
import { Sparkles, ShieldAlert } from 'lucide-react';

export const metadata: Metadata = {
  title: 'CODETALES | AI-Powered Computer Science Stories & Learning',
  description: 'Transform complex Computer Science concepts into unforgettable, personalized educational stories powered by AI.',
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: '#050508',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className="bg-cyber-dark text-gray-100 min-h-screen flex flex-col selection:bg-cyan-500 selection:text-black">
        <AuthProvider>
          <Navbar />
          
          <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
            {children}
          </main>

          <footer className="border-t border-purple-950/50 bg-[#05050a]/90 backdrop-blur-md py-8 mt-16">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center text-center space-y-4">
              
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-purple-600 to-cyan-500 p-[1.5px]">
                  <div className="w-full h-full bg-cyber-dark rounded-[6px] flex items-center justify-center">
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  </div>
                </div>
                <span className="text-base font-black tracking-wider bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
                  CODETALES
                </span>
              </div>

              <p className="text-xs text-gray-400 max-w-md leading-relaxed">
                Empowering engineers, students, and curious minds to master Computer Science architectures through narrative intuition and cognitive allegories.
              </p>

              <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-purple-950/20 border border-purple-900/30 text-[11px] text-gray-400">
                <ShieldAlert className="w-3.5 h-3.5 text-cyan-400" />
                <span>
                  Educational stories serve as cognitive conceptual models; always consult formal language specifications for exact syntax.
                </span>
              </div>

              <div className="pt-2 text-[11px] text-gray-500">
                © {new Date().getFullYear()} CODETALES. Built with modern web standards and deep technical passion.
              </div>

            </div>
          </footer>
        </AuthProvider>
      </body>
    </html>
  );
}
