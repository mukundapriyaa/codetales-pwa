'use client';

import React, { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { 
  User, Award, BookOpen, Clock, BarChart3, 
  Sparkles, ChevronRight, LogOut, Settings, Shield, 
  CheckCircle2, AlertCircle, Save, Camera, RotateCcw, 
  Compass, ExternalLink, Lock 
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { getUserProgress, getQuizResults, getSavedStories } from '@/lib/storage';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { UserProgress, QuizResult, GeneratedStory } from '@/types';

// Preset avatar avatars for the futuristic dark theme
const AVATAR_PRESETS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=256&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=256&q=80',
  'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=256&q=80',
  'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=256&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=256&q=80',
];

function ProfileContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialTab = searchParams.get('tab') || 'overview';

  const { user, isLoading, logout, updateProfile, changePassword } = useAuth();

  const [activeTab, setActiveTab] = useState<'overview' | 'edit' | 'security' | 'settings' | 'learning'>(
    initialTab === 'edit' || initialTab === 'security' || initialTab === 'learning' || initialTab === 'settings'
      ? initialTab
      : 'overview'
  );

  // Edit Profile Form State
  const [editName, setEditName] = useState('');
  const [editAvatarUrl, setEditAvatarUrl] = useState('');
  const [profileSaving, setProfileSaving] = useState(false);
  const [profileSuccess, setProfileSuccess] = useState('');
  const [profileError, setProfileError] = useState('');

  // Change Password Form State
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordSaving, setPasswordSaving] = useState(false);
  const [passwordSuccess, setPasswordSuccess] = useState('');
  const [passwordError, setPasswordError] = useState('');

  // Settings State
  const [preferredDifficulty, setPreferredDifficulty] = useState('Intermediate');
  const [settingsSaved, setSettingsSaved] = useState(false);

  // Real Data
  const [progress, setProgress] = useState<UserProgress | null>(null);
  const [quizzes, setQuizzes] = useState<QuizResult[]>([]);
  const [savedStories, setSavedStories] = useState<GeneratedStory[]>([]);

  useEffect(() => {
    if (user) {
      setEditName(user.name);
      setEditAvatarUrl(user.avatarUrl || '');

      // Load quiz scores from Supabase if configured
      if (isSupabaseConfigured && user.id && !user.isGuest) {
        (async () => {
          try {
            const { data, error } = await supabase
              .from('quiz_scores')
              .select('*')
              .eq('user_id', user.id)
              .order('completed_at', { ascending: false });

            if (!error && data && data.length > 0) {
              const dbQuizzes: QuizResult[] = data.map((d: any) => ({
                score: d.score,
                totalQuestions: d.total_questions,
                percentage: d.percentage,
                userAnswers: {},
                questions: [],
                completedAt: d.completed_at,
                topicName: d.topic_name,
                conceptName: d.concept_name,
              }));

              setQuizzes((prev) => {
                const combined = [...dbQuizzes, ...prev];
                return combined.filter(
                  (q, idx, arr) =>
                    arr.findIndex(
                      (o) => o.conceptName === q.conceptName && o.completedAt === q.completedAt
                    ) === idx
                );
              });
            }
          } catch (err) {
            console.warn('Supabase profile load error:', err);
          }
        })();
      }
    }
    setProgress(getUserProgress());
    setQuizzes(getQuizResults());
    setSavedStories(getSavedStories());
  }, [user]);

  // Handle URL tab changes
  useEffect(() => {
    const tabParam = searchParams.get('tab');
    if (tabParam === 'edit' || tabParam === 'security' || tabParam === 'learning' || tabParam === 'settings') {
      setActiveTab(tabParam);
    }
  }, [searchParams]);

  // Guard: If not logged in and not loading, show restricted view
  if (!isLoading && !user) {
    return (
      <div className="max-w-md mx-auto py-16 text-center space-y-6 animate-in fade-in">
        <div className="w-16 h-16 rounded-2xl bg-purple-950/40 border border-purple-800/40 flex items-center justify-center mx-auto text-cyan-400">
          <Lock className="w-8 h-8" />
        </div>
        <h1 className="text-2xl font-black text-white">Access Restricted</h1>
        <p className="text-xs text-gray-400 max-w-sm mx-auto leading-relaxed">
          The Profile Vault and learning progress history are only accessible to authenticated learners. Please sign in to access your profile.
        </p>
        <div className="flex items-center justify-center gap-3 pt-2">
          <Link
            href="/auth/login"
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 text-xs font-bold text-white shadow-neon-purple hover:scale-105 transition-all"
          >
            Sign In Now
          </Link>
          <Link
            href="/"
            className="px-5 py-2.5 rounded-xl bg-cyber-card border border-purple-800/40 text-xs font-semibold text-gray-300 hover:text-white"
          >
            Return Home
          </Link>
        </div>
      </div>
    );
  }

  // Handle Profile Update
  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSaving(true);
    setProfileSuccess('');
    setProfileError('');

    if (!editName.trim()) {
      setProfileError('Full name cannot be empty.');
      setProfileSaving(false);
      return;
    }

    try {
      await updateProfile({
        name: editName.trim(),
        avatarUrl: editAvatarUrl.trim(),
      });
      setProfileSuccess('Profile changes saved successfully to the database!');
      setTimeout(() => setProfileSuccess(''), 4000);
    } catch (err: any) {
      setProfileError(err.message || 'Failed to update profile.');
    } finally {
      setProfileSaving(false);
    }
  };

  // Handle Password Change
  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordSaving(true);
    setPasswordSuccess('');
    setPasswordError('');

    if (newPassword.length < 6) {
      setPasswordError('New password must be at least 6 characters.');
      setPasswordSaving(false);
      return;
    }

    if (newPassword !== confirmPassword) {
      setPasswordError('Passwords do not match.');
      setPasswordSaving(false);
      return;
    }

    try {
      await changePassword(newPassword);
      setPasswordSuccess('Password updated successfully!');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => setPasswordSuccess(''), 4000);
    } catch (err: any) {
      setPasswordError(err.message || 'Failed to update password.');
    } finally {
      setPasswordSaving(false);
    }
  };

  const handleSignOut = async () => {
    await logout();
    router.push('/');
  };

  return (
    <div className="max-w-5xl mx-auto py-4 sm:py-8 space-y-8 animate-in fade-in duration-300">
      
      {/* 1, 2, 3: User Avatar, Name, Email and Quick Actions Header */}
      <div className="relative overflow-hidden p-6 sm:p-8 rounded-3xl bg-cyber-card border border-purple-500/40 shadow-neon-purple flex flex-col md:flex-row md:items-center justify-between gap-6">
        
        <div className="flex items-center gap-5">
          {/* 1. Avatar */}
          <div className="relative group">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-400 p-[2px] shadow-neon-blue flex-shrink-0">
              <div className="w-full h-full bg-cyber-dark rounded-[14px] overflow-hidden flex items-center justify-center">
                {user?.avatarUrl ? (
                  <img src={user.avatarUrl} alt={user.name} className="w-full h-full object-cover" />
                ) : (
                  <span className="text-2xl font-black text-white uppercase font-mono">
                    {user?.name ? user.name.substring(0, 2) : 'U'}
                  </span>
                )}
              </div>
            </div>
            <button
              onClick={() => setActiveTab('edit')}
              title="Change Avatar"
              className="absolute -bottom-1 -right-1 p-1.5 rounded-lg bg-cyber-dark border border-cyan-400 text-cyan-300 shadow-sm hover:scale-110 transition-transform"
            >
              <Camera className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* 2 & 3. Name & Email */}
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h1 className="text-2xl sm:text-3xl font-black text-white tracking-wide">
                {user?.name}
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono bg-cyan-950/60 border border-cyan-500/40 text-cyan-300">
                Verified Account
              </span>
            </div>
            <p className="text-xs sm:text-sm text-gray-300 font-mono flex items-center gap-1.5">
              <span>{user?.email}</span>
            </p>
            <p className="text-[11px] text-gray-500 font-mono">
              Member since {new Date(user?.createdAt || Date.now()).toLocaleDateString(undefined, { month: 'short', year: 'numeric' })}
            </p>
          </div>
        </div>

        {/* 9. Logout Button and Tab Shortcuts */}
        <div className="flex items-center gap-2.5 self-start md:self-center">
          <button
            onClick={() => setActiveTab('edit')}
            className="px-3.5 py-2 rounded-xl bg-purple-950/40 border border-purple-800/40 hover:border-cyan-400 text-xs font-semibold text-cyan-300 transition-colors flex items-center gap-1.5"
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Edit Profile</span>
          </button>
          <button
            onClick={handleSignOut}
            className="px-4 py-2 rounded-xl bg-rose-950/40 border border-rose-800/40 hover:bg-rose-900/40 text-xs font-bold text-rose-300 transition-colors flex items-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Log Out</span>
          </button>
        </div>

      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-purple-900/40">
        {[
          { id: 'overview', label: 'Vault Overview', icon: User },
          { id: 'learning', label: 'Learning Progress & Scores', icon: BarChart3 },
          { id: 'edit', label: 'Edit Profile', icon: Settings },
          { id: 'security', label: 'Change Password', icon: Shield },
          { id: 'settings', label: 'Account Settings', icon: Sparkles },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-purple-950/80 border border-cyan-400 text-cyan-300 shadow-neon-blue'
                  : 'text-gray-400 hover:text-white hover:bg-purple-950/20'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          
          {/* Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
            <div className="p-4 rounded-2xl bg-cyber-card border border-purple-900/40 shadow-sm">
              <div className="flex items-center justify-between text-gray-400 mb-1.5">
                <span className="text-xs font-mono">Tales Explored</span>
                <BookOpen className="w-4 h-4 text-purple-400" />
              </div>
              <div className="text-2xl font-black text-white">{savedStories.length}</div>
            </div>

            <div className="p-4 rounded-2xl bg-cyber-card border border-purple-900/40 shadow-sm">
              <div className="flex items-center justify-between text-gray-400 mb-1.5">
                <span className="text-xs font-mono">Quizzes Finished</span>
                <Award className="w-4 h-4 text-cyan-400" />
              </div>
              <div className="text-2xl font-black text-white">{quizzes.length}</div>
            </div>

            <div className="p-4 rounded-2xl bg-cyber-card border border-purple-900/40 shadow-sm">
              <div className="flex items-center justify-between text-gray-400 mb-1.5">
                <span className="text-xs font-mono">Avg Accuracy</span>
                <BarChart3 className="w-4 h-4 text-indigo-400" />
              </div>
              <div className="text-2xl font-black text-cyan-300">
                {quizzes.length > 0 
                  ? Math.round(quizzes.reduce((acc, q) => acc + q.percentage, 0) / quizzes.length) 
                  : 0}%
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-cyber-card border border-purple-900/40 shadow-sm">
              <div className="flex items-center justify-between text-gray-400 mb-1.5">
                <span className="text-xs font-mono">Mastered Topics</span>
                <Compass className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-black text-emerald-400">
                {new Set(quizzes.map(q => q.topicName)).size}/15
              </div>
            </div>
          </div>

          {/* Recent Quiz Scores Section */}
          <div className="p-6 rounded-3xl bg-cyber-card border border-purple-900/40 space-y-4 shadow-cyber-card">
            <div className="flex items-center justify-between pb-3 border-b border-purple-900/30">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Award className="w-4 h-4 text-cyan-400" />
                <span>Recent Quiz Scores</span>
              </h2>
              <button
                onClick={() => setActiveTab('learning')}
                className="text-xs text-purple-400 hover:text-cyan-300 hover:underline"
              >
                View Full Log &rarr;
              </button>
            </div>

            {quizzes.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {quizzes.slice(0, 4).map((q, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-2xl bg-cyber-surface border border-purple-900/30 flex items-center justify-between"
                  >
                    <div>
                      <div className="text-xs font-bold text-white line-clamp-1">{q.conceptName}</div>
                      <div className="text-[10px] font-mono text-gray-400 mt-0.5">{q.topicName}</div>
                    </div>
                    <span
                      className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold ${
                        q.percentage >= 80
                          ? 'bg-cyan-950/70 border border-cyan-500/40 text-cyan-300'
                          : q.percentage >= 60
                          ? 'bg-purple-950/70 border border-purple-500/40 text-purple-300'
                          : 'bg-rose-950/70 border border-rose-500/40 text-rose-300'
                      }`}
                    >
                      {q.score}/{q.totalQuestions} ({q.percentage}%)
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-8 text-center text-xs text-gray-400 space-y-2">
                <p>No assessment records yet.</p>
                <Link href="/#topics" className="text-cyan-400 hover:underline font-semibold inline-block">
                  Explore Topics & Generate Your First Quiz &rarr;
                </Link>
              </div>
            )}
          </div>

        </div>
      )}

      {/* TAB 2: LEARNING PROGRESS & QUIZ SCORES (REQUIREMENTS 7 & 8) */}
      {activeTab === 'learning' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          
          <div className="p-6 rounded-3xl bg-cyber-card border border-purple-900/40 space-y-4">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-cyan-400" />
              <span>Learning Progress & Quiz Attempts</span>
            </h2>
            <p className="text-xs text-gray-400">
              Real-time records of every educational tale completed and quiz submitted.
            </p>

            {/* 7 & 8: Show scores only when actual data exists; clean empty state for new users */}
            {quizzes.length > 0 ? (
              <div className="space-y-3 pt-2">
                {quizzes.map((q, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-2xl bg-cyber-surface border border-purple-900/40 hover:border-cyan-400/50 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{q.conceptName}</span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950/60 border border-purple-800/40 text-purple-300">
                          {q.topicName}
                        </span>
                      </div>
                      <div className="text-[11px] font-mono text-gray-500 mt-1">
                        Attempted: {new Date(q.completedAt).toLocaleString()}
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <span
                        className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold ${
                          q.percentage >= 80
                            ? 'bg-cyan-950/80 border border-cyan-400 text-cyan-300 shadow-neon-blue'
                            : q.percentage >= 60
                            ? 'bg-purple-950/80 border border-purple-500 text-purple-300'
                            : 'bg-rose-950/80 border border-rose-500 text-rose-300'
                        }`}
                      >
                        Score: {q.score} / {q.totalQuestions} ({q.percentage}%)
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-12 text-center rounded-2xl bg-cyber-surface/50 border border-purple-900/30 p-6 space-y-3">
                <Award className="w-10 h-10 text-gray-600 mx-auto" />
                <h3 className="text-sm font-bold text-white">No Learning Progress Recorded Yet</h3>
                <p className="text-xs text-gray-400 max-w-sm mx-auto leading-relaxed">
                  You haven&apos;t taken any quizzes yet. As you generate stories and complete assessments, your actual performance scores will appear here.
                </p>
                <Link
                  href="/#topics"
                  className="inline-block mt-2 px-5 py-2 rounded-xl bg-purple-600 text-xs font-bold text-white shadow-neon-purple hover:scale-105 transition-all"
                >
                  Start First Learning Quest
                </Link>
              </div>
            )}
          </div>

        </div>
      )}

      {/* TAB 3: EDIT PROFILE (REQUIREMENT 4) */}
      {activeTab === 'edit' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-cyber-card border border-purple-500/40 shadow-neon-purple space-y-6 animate-in fade-in duration-200">
          
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Settings className="w-5 h-5 text-cyan-400" />
              <span>Edit Profile Details</span>
            </h2>
            <p className="text-xs text-gray-400 mt-0.5">
              Update your display name and customize your avatar representation.
            </p>
          </div>

          {profileSuccess && (
            <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/50 text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
              <span>{profileSuccess}</span>
            </div>
          )}

          {profileError && (
            <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/50 text-xs text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{profileError}</span>
            </div>
          )}

          <form onSubmit={handleProfileSave} className="space-y-6">
            
            {/* Name Input */}
            <div>
              <label className="block text-xs font-mono text-gray-300 mb-1.5">
                Full Name
              </label>
              <input
                type="text"
                required
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                placeholder="e.g. Maya Chen"
                className="w-full max-w-md px-3.5 py-2.5 bg-cyber-surface border border-purple-800/40 rounded-xl text-sm text-gray-200 focus:outline-none focus:border-cyan-400"
              />
            </div>

            {/* Email (Readonly) */}
            <div>
              <label className="block text-xs font-mono text-gray-400 mb-1.5">
                Registered Email (Managed by Auth Provider)
              </label>
              <input
                type="email"
                disabled
                value={user?.email || ''}
                className="w-full max-w-md px-3.5 py-2.5 bg-gray-900 border border-gray-800 rounded-xl text-sm text-gray-500 cursor-not-allowed font-mono"
              />
            </div>

            {/* Avatar Selection Presets */}
            <div className="space-y-3">
              <label className="block text-xs font-mono text-gray-300">
                Choose Profile Avatar Preset
              </label>
              <div className="flex flex-wrap gap-3">
                {AVATAR_PRESETS.map((preset, idx) => (
                  <button
                    type="button"
                    key={idx}
                    onClick={() => setEditAvatarUrl(preset)}
                    className={`w-12 h-12 rounded-xl overflow-hidden border-2 transition-all ${
                      editAvatarUrl === preset
                        ? 'border-cyan-400 shadow-neon-blue scale-110'
                        : 'border-purple-900/40 hover:border-purple-500 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={preset} alt="preset" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Avatar URL */}
            <div>
              <label className="block text-xs font-mono text-gray-300 mb-1.5">
                Or Custom Avatar Image URL
              </label>
              <input
                type="url"
                value={editAvatarUrl}
                onChange={(e) => setEditAvatarUrl(e.target.value)}
                placeholder="https://example.com/avatar.png"
                className="w-full max-w-md px-3.5 py-2 bg-cyber-surface border border-purple-800/40 rounded-xl text-xs text-gray-200 focus:outline-none focus:border-cyan-400 font-mono"
              />
            </div>

            <button
              type="submit"
              disabled={profileSaving}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 text-xs font-bold text-white shadow-neon-purple hover:scale-105 active:scale-95 disabled:opacity-50 transition-all flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              <span>{profileSaving ? 'Saving to Database...' : 'Save Profile Changes'}</span>
            </button>

          </form>

        </div>
      )}

      {/* TAB 4: CHANGE PASSWORD (REQUIREMENT 5) */}
      {activeTab === 'security' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-cyber-card border border-purple-500/40 shadow-neon-purple space-y-6 animate-in fade-in duration-200">
          
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Shield className="w-5 h-5 text-indigo-400" />
              <span>Change Account Password</span>
            </h2>
            <p className="text-xs text-gray-400 mt-0.5">
              Update your security credentials with your authentication provider.
            </p>
          </div>

          {passwordSuccess && (
            <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/50 text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
              <span>{passwordSuccess}</span>
            </div>
          )}

          {passwordError && (
            <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/50 text-xs text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{passwordError}</span>
            </div>
          )}

          <form onSubmit={handlePasswordChange} className="space-y-4 max-w-md">
            <div>
              <label className="block text-xs font-mono text-gray-300 mb-1.5">
                New Password (minimum 6 characters)
              </label>
              <input
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-3.5 py-2.5 bg-cyber-surface border border-purple-800/40 rounded-xl text-sm text-gray-200 focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-gray-300 mb-1.5">
                Confirm New Password
              </label>
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-3.5 py-2.5 bg-cyber-surface border border-purple-800/40 rounded-xl text-sm text-gray-200 focus:outline-none focus:border-cyan-400"
              />
            </div>

            <button
              type="submit"
              disabled={passwordSaving}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-xs font-bold text-white shadow-neon-purple hover:scale-105 active:scale-95 disabled:opacity-50 transition-all flex items-center gap-2"
            >
              <Lock className="w-4 h-4" />
              <span>{passwordSaving ? 'Updating Password...' : 'Update Password'}</span>
            </button>
          </form>

        </div>
      )}

      {/* TAB 5: ACCOUNT SETTINGS (REQUIREMENT 6) */}
      {activeTab === 'settings' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-cyber-card border border-purple-500/40 shadow-neon-purple space-y-6 animate-in fade-in duration-200">
          
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-cyan-400" />
              <span>Account & Learning Preferences</span>
            </h2>
            <p className="text-xs text-gray-400 mt-0.5">
              Configure personal settings for your story and quiz experiences.
            </p>
          </div>

          {settingsSaved && (
            <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/50 text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
              <span>Preferences saved successfully!</span>
            </div>
          )}

          <div className="space-y-5 max-w-lg">
            <div>
              <label className="block text-xs font-mono text-gray-300 mb-1.5">
                Default Narrative Difficulty
              </label>
              <select
                value={preferredDifficulty}
                onChange={(e) => {
                  setPreferredDifficulty(e.target.value);
                  setSettingsSaved(true);
                  setTimeout(() => setSettingsSaved(false), 3000);
                }}
                className="w-full px-3.5 py-2.5 bg-cyber-surface border border-purple-800/40 rounded-xl text-sm text-gray-200 focus:outline-none focus:border-cyan-400"
              >
                <option value="Beginner">Beginner (Foundational metaphors)</option>
                <option value="Intermediate">Intermediate (Real constraints & types)</option>
                <option value="Advanced">Advanced (Memory & asymptotic complexity)</option>
              </select>
            </div>

            <div className="p-4 rounded-2xl bg-purple-950/30 border border-purple-900/30 space-y-2">
              <div className="text-xs font-bold text-white">AI Provider Ecosystem</div>
              <p className="text-[11px] text-gray-400 leading-relaxed">
                CODETALES uses the Hugging Face Transformers ecosystem for server-side educational story and quiz generation. You can configure your Hugging Face Access Token in the AI Key dialog.
              </p>
            </div>

            <div className="pt-2">
              <button
                onClick={handleSignOut}
                className="px-4 py-2 rounded-xl bg-rose-950/50 border border-rose-800/50 text-xs font-bold text-rose-300 hover:bg-rose-900/50 transition-colors flex items-center gap-1.5"
              >
                <LogOut className="w-4 h-4" />
                <span>Log Out of Session</span>
              </button>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}

export default function ProfilePage() {
  return (
    <Suspense fallback={<div className="p-12 text-center text-cyan-400 font-mono">Loading Profile Vault...</div>}>
      <ProfileContent />
    </Suspense>
  );
}
