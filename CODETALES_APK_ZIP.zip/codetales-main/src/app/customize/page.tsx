'use client';

import React, { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { 
  ArrowLeft, Sparkles, Compass, Shield, Wand2, 
  Clock, User, MapPin, AlertCircle, CheckCircle2, Loader2 
} from 'lucide-react';
import { TOPICS } from '@/data/topics';
import { Genre, Difficulty, StoryLength, StoryCustomization } from '@/types';
import { saveStory, getCustomApiKey, getCustomHfToken, getCustomHfModel } from '@/lib/storage';

const GENRES: { id: Genre; label: string; icon: string; desc: string }[] = [
  { id: 'Science Fiction', label: 'Sci-Fi', icon: '🚀', desc: 'Cyberpunk cities, AI matrices & interstellar probes' },
  { id: 'Fantasy', label: 'Fantasy', icon: '🔮', desc: 'Ancient magic spires, elemental runes & enchanted realms' },
  { id: 'Mystery', label: 'Mystery', icon: '🕵️', desc: 'Noir investigations, cryptographic secrets & hidden clues' },
  { id: 'Adventure', label: 'Adventure', icon: '⚔️', desc: 'High-stakes expeditions, dungeon traps & lost treasures' },
  { id: 'Comedy', label: 'Comedy', icon: '🎭', desc: 'Quirky chaos, humorous mishaps & witty droids' },
];

const DIFFICULTIES: { id: Difficulty; label: string; desc: string }[] = [
  { id: 'Beginner', label: 'Beginner', desc: 'Gentle everyday analogies, foundational mechanics' },
  { id: 'Intermediate', label: 'Intermediate', desc: 'Deeper technical constraints, standard edge cases' },
  { id: 'Advanced', label: 'Advanced', desc: 'Rigorous architectural subtleties, memory & asymptotic complexity' },
];

const LENGTHS: { id: StoryLength; label: string; time: string; words: string }[] = [
  { id: 'Short', label: 'Short', time: '~2 min read', words: '300 words' },
  { id: 'Medium', label: 'Medium', time: '~4 min read', words: '600 words' },
  { id: 'Long', label: 'Long', time: '~6 min read', words: '900 words' },
];

function CustomizeForm() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const queryTopic = searchParams.get('topicId') || 'python';
  const queryConcept = searchParams.get('conceptId') || 'functions-recursion';

  const [topicId, setTopicId] = useState(queryTopic);
  const [conceptId, setConceptId] = useState(queryConcept);
  const [genre, setGenre] = useState<Genre>('Science Fiction');
  const [difficulty, setDifficulty] = useState<Difficulty>('Beginner');
  const [length, setLength] = useState<StoryLength>('Medium');
  const [characterName, setCharacterName] = useState('');
  const [setting, setSetting] = useState('');

  const [isGenerating, setIsGenerating] = useState(false);
  const [loadingStep, setLoadingStep] = useState('Initializing AI Model...');
  const [errorMsg, setErrorMsg] = useState('');

  const currentTopic = TOPICS.find((t) => t.id === topicId) || TOPICS[3];
  const currentConcept = currentTopic.concepts.find((c) => c.id === conceptId) || currentTopic.concepts[0];

  useEffect(() => {
    // Sync if concept doesn't belong to topic
    if (!currentTopic.concepts.some((c) => c.id === conceptId)) {
      setConceptId(currentTopic.concepts[0]?.id || '');
    }
  }, [topicId, currentTopic, conceptId]);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);
    setErrorMsg('');

    const steps = [
      'Grounded in ' + currentTopic.name + '...',
      'Mapping technical constraints for ' + currentConcept.name + '...',
      'Crafting narrative allegory in ' + genre + ' genre...',
      'Polishing story-to-concept architectural breakdown...',
    ];

    let stepIdx = 0;
    const interval = setInterval(() => {
      if (stepIdx < steps.length) {
        setLoadingStep(steps[stepIdx]);
        stepIdx++;
      }
    }, 1200);

    try {
      const customApiKey = getCustomHfToken() || getCustomApiKey();
      const hfModel = getCustomHfModel();

      const response = await fetch('/api/generate-story', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topicId,
          conceptId,
          genre,
          difficulty,
          length,
          characterName: characterName.trim() || undefined,
          setting: setting.trim() || undefined,
          customApiKey,
          hfModel,
        }),
      });

      clearInterval(interval);

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.error || 'Failed to generate story.');
      }

      // Save to client storage and navigate to reader
      saveStory(result.story);
      sessionStorage.setItem('current_story', JSON.stringify(result.story));
      router.push(`/story?id=${result.story.id}`);
    } catch (err: any) {
      clearInterval(interval);
      setIsGenerating(false);
      setErrorMsg(err.message || 'An error occurred while communicating with the AI backend.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-4 sm:py-6 space-y-8 animate-in fade-in duration-300">
      
      {/* Top Navigation */}
      <Link
        href={`/topic/${currentTopic.id}`}
        className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-purple-950/30 border border-purple-800/40 text-xs font-medium text-cyan-400 hover:border-cyan-400 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Change Concept ({currentTopic.name})</span>
      </Link>

      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/40 border border-cyan-500/30 text-xs font-mono text-cyan-300 mb-2">
          <Wand2 className="w-3.5 h-3.5" />
          <span>Stage 03: Story Studio</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-black text-white">
          Customize Your Educational Tale
        </h1>
        <p className="text-xs sm:text-sm text-gray-400 mt-1 max-w-2xl">
          Tune the narrative parameters to craft a story that aligns with your preferred learning style, setting, and difficulty level.
        </p>
      </div>

      {/* Target Concept Summary Card */}
      <div className="p-4 sm:p-5 rounded-2xl bg-cyber-card border border-purple-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-neon-purple">
        <div>
          <span className="text-[11px] font-mono text-purple-400 uppercase tracking-wider">
            Selected Concept
          </span>
          <h2 className="text-xl font-bold text-white mt-0.5">
            {currentConcept.name}
          </h2>
          <p className="text-xs text-gray-300 mt-1">
            {currentConcept.description}
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-center flex-shrink-0">
          <span className="px-2.5 py-1 rounded-lg text-xs font-mono bg-purple-950/60 border border-purple-700/50 text-cyan-300">
            {currentTopic.name}
          </span>
        </div>
      </div>

      {errorMsg && (
        <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-500/50 text-rose-300 text-xs flex items-center gap-3">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Customization Form */}
      <form onSubmit={handleGenerate} className="space-y-8">
        
        {/* 1. Genre Selection */}
        <div className="space-y-3">
          <label className="block text-sm font-bold text-white flex items-center gap-2">
            <span>1. Story Genre</span>
            <span className="text-xs text-gray-400 font-normal">Choose your narrative universe</span>
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {GENRES.map((g) => {
              const isSelected = genre === g.id;
              return (
                <button
                  type="button"
                  key={g.id}
                  onClick={() => setGenre(g.id)}
                  className={`p-3.5 rounded-2xl border text-left flex flex-col justify-between transition-all ${
                    isSelected
                      ? 'bg-purple-950/70 border-cyan-400 shadow-neon-cyan ring-1 ring-cyan-400/50'
                      : 'bg-cyber-card border-purple-900/40 hover:border-purple-600/60'
                  }`}
                >
                  <span className="text-2xl mb-2">{g.icon}</span>
                  <div>
                    <div className="text-sm font-bold text-white">{g.label}</div>
                    <div className="text-[10px] text-gray-400 mt-0.5 line-clamp-2 leading-tight">{g.desc}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* 2. Difficulty Selection */}
        <div className="space-y-3">
          <label className="block text-sm font-bold text-white flex items-center gap-2">
            <span>2. Technical Depth</span>
            <span className="text-xs text-gray-400 font-normal">How deeply to explore edge cases</span>
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {DIFFICULTIES.map((d) => {
              const isSelected = difficulty === d.id;
              return (
                <button
                  type="button"
                  key={d.id}
                  onClick={() => setDifficulty(d.id)}
                  className={`p-4 rounded-2xl border text-left transition-all ${
                    isSelected
                      ? 'bg-purple-950/70 border-cyan-400 shadow-neon-cyan ring-1 ring-cyan-400/50'
                      : 'bg-cyber-card border-purple-900/40 hover:border-purple-600/60'
                  }`}
                >
                  <div className="text-sm font-bold text-white flex items-center justify-between">
                    <span>{d.label}</span>
                    {isSelected && <CheckCircle2 className="w-4 h-4 text-cyan-400" />}
                  </div>
                  <p className="text-xs text-gray-400 mt-1 leading-snug">{d.desc}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* 3. Length Selection */}
        <div className="space-y-3">
          <label className="block text-sm font-bold text-white flex items-center gap-2">
            <span>3. Story Length</span>
            <span className="text-xs text-gray-400 font-normal">Estimated reading and audio duration</span>
          </label>
          <div className="grid grid-cols-3 gap-3">
            {LENGTHS.map((l) => {
              const isSelected = length === l.id;
              return (
                <button
                  type="button"
                  key={l.id}
                  onClick={() => setLength(l.id)}
                  className={`p-3.5 rounded-2xl border text-center transition-all ${
                    isSelected
                      ? 'bg-purple-950/70 border-cyan-400 shadow-neon-cyan ring-1 ring-cyan-400/50'
                      : 'bg-cyber-card border-purple-900/40 hover:border-purple-600/60'
                  }`}
                >
                  <div className="text-sm font-bold text-white">{l.label}</div>
                  <div className="text-xs font-mono text-cyan-300 mt-0.5">{l.time}</div>
                  <div className="text-[10px] text-gray-400 mt-0.5">{l.words}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* 4. Optional Character and Setting Customization */}
        <div className="p-5 rounded-2xl bg-cyber-card/70 border border-purple-900/40 space-y-4">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-purple-400" />
            <h3 className="text-sm font-bold text-white">
              Optional Worldbuilding & Protagonist
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono text-gray-400 mb-1">
                Protagonist Name (Optional)
              </label>
              <input
                type="text"
                value={characterName}
                onChange={(e) => setCharacterName(e.target.value)}
                placeholder="e.g. Maya the Kernel Hacker"
                className="w-full px-3.5 py-2 bg-cyber-surface border border-purple-800/40 rounded-xl text-sm text-gray-200 focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-gray-400 mb-1">
                Setting / World (Optional)
              </label>
              <input
                type="text"
                value={setting}
                onChange={(e) => setSetting(e.target.value)}
                placeholder="e.g. Subterranean Cyber City Neo-Arcadia"
                className="w-full px-3.5 py-2 bg-cyber-surface border border-purple-800/40 rounded-xl text-sm text-gray-200 focus:outline-none focus:border-cyan-400"
              />
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isGenerating}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 text-white font-extrabold text-base shadow-neon-purple hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 disabled:hover:scale-100 transition-all flex items-center justify-center gap-2"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>{loadingStep}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 text-cyan-300" />
                <span>Generate AI Tale</span>
              </>
            )}
          </button>
        </div>

      </form>

      {/* Loading Overlay Modal */}
      {isGenerating && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-300">
          <div className="w-full max-w-md p-8 rounded-3xl bg-cyber-card border border-purple-500/50 shadow-neon-purple text-center flex flex-col items-center">
            
            {/* Holographic Glowing Pulse */}
            <div className="relative w-24 h-24 mb-6">
              <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-purple-600 via-cyan-400 to-blue-500 blur-xl opacity-60 animate-pulse" />
              <div className="relative w-full h-full rounded-full bg-cyber-dark border-2 border-cyan-400 flex items-center justify-center">
                <Sparkles className="w-10 h-10 text-cyan-400 animate-spin" style={{ animationDuration: '4s' }} />
              </div>
            </div>

            <h3 className="text-xl font-black text-white mb-2">
              Synthesizing Tale...
            </h3>
            
            <p className="text-xs font-mono text-cyan-300 mb-4 px-4 py-1.5 rounded-full bg-cyan-950/40 border border-cyan-500/30">
              {loadingStep}
            </p>

            <p className="text-xs text-gray-400 max-w-xs leading-relaxed">
              Weaving computer science algorithms into an interactive narrative grounded in pedagogical truth.
            </p>

          </div>
        </div>
      )}

    </div>
  );
}

export default function CustomizePage() {
  return (
    <Suspense fallback={<div className="p-12 text-center text-cyan-400 font-mono">Loading Story Studio...</div>}>
      <CustomizeForm />
    </Suspense>
  );
}
