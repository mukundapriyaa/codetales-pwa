'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { 
  Sparkles, ArrowRight, BookOpen, Brain, 
  Headphones, Award, Search, Compass, ChevronDown 
} from 'lucide-react';
import { TOPICS } from '@/data/topics';
import TopicCard from '@/components/TopicCard';

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredTopics = TOPICS.filter((topic) =>
    topic.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    topic.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    topic.concepts.some(c => c.name.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="space-y-16 py-4 sm:py-8 animate-in fade-in duration-500">
      
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-cyber-gradient border border-purple-900/40 p-6 sm:p-12 text-center flex flex-col items-center">
        
        {/* Ambient background glows */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 right-10 w-80 h-80 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Top Badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-purple-950/60 border border-purple-500/40 text-xs font-mono text-cyan-300 shadow-neon-purple mb-6">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>Next-Gen Computer Science Pedagogy</span>
        </div>

        {/* Main Title */}
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white max-w-4xl leading-tight">
          Master Complex CS Concepts Through{' '}
          <span className="bg-gradient-to-r from-purple-400 via-cyan-400 to-blue-400 bg-clip-text text-transparent">
            Personalized AI Tales
          </span>
        </h1>

        {/* Subtitle */}
        <p className="mt-4 sm:mt-6 text-sm sm:text-lg text-gray-300 max-w-2xl leading-relaxed">
          Struggling with recursion, pointers, deadlocks, or neural transformers?{' '}
          <strong className="text-white">CODETALES</strong> translates intimidating code and system architecture into vivid, memorable stories with text-to-speech audio and interactive gamified quizzes.
        </p>

        {/* Action Buttons */}
        <div className="mt-8 flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
          <a
            href="#topics"
            className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 text-white font-bold text-sm shadow-neon-purple hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 group"
          >
            <span>Start Learning</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </a>
          <Link
            href="/topic/python"
            className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-cyber-dark/80 border border-purple-800/50 text-gray-200 hover:text-cyan-300 hover:border-cyan-500/60 font-semibold text-sm transition-all flex items-center justify-center gap-2"
          >
            <Compass className="w-4 h-4 text-purple-400" />
            <span>Try Quick Demo</span>
          </Link>
        </div>

        {/* Feature Highlights Grid */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 w-full max-w-3xl pt-8 border-t border-purple-900/30">
          <div className="p-3 rounded-xl bg-purple-950/20 border border-purple-900/30 flex items-center gap-2.5">
            <BookOpen className="w-5 h-5 text-purple-400 flex-shrink-0" />
            <div className="text-left">
              <div className="text-xs font-bold text-white">15 Domains</div>
              <div className="text-[10px] text-gray-400">Low-level to AI</div>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-cyan-950/20 border border-cyan-900/30 flex items-center gap-2.5">
            <Brain className="w-5 h-5 text-cyan-400 flex-shrink-0" />
            <div className="text-left">
              <div className="text-xs font-bold text-white">AI Grounded</div>
              <div className="text-[10px] text-gray-400">Concept Mappings</div>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-purple-950/20 border border-purple-900/30 flex items-center gap-2.5">
            <Headphones className="w-5 h-5 text-purple-300 flex-shrink-0" />
            <div className="text-left">
              <div className="text-xs font-bold text-white">Futuristic TTS</div>
              <div className="text-[10px] text-gray-400">Listen Hands-Free</div>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-cyan-950/20 border border-cyan-900/30 flex items-center gap-2.5">
            <Award className="w-5 h-5 text-cyan-400 flex-shrink-0" />
            <div className="text-left">
              <div className="text-xs font-bold text-white">Gamified Quiz</div>
              <div className="text-[10px] text-gray-400">Score & Retain</div>
            </div>
          </div>
        </div>

      </section>

      {/* Explore Topics Section */}
      <section id="topics" className="space-y-6 pt-6">
        
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-mono text-cyan-400 uppercase tracking-widest mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Curriculum Hierarchy</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white">
              Explore Computer Science Topics
            </h2>
            <p className="text-xs sm:text-sm text-gray-400 mt-1">
              Select a domain to inspect its architectural concepts and customize your educational story.
            </p>
          </div>

          {/* Search bar */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search 15 topics or concepts..."
              className="w-full pl-9 pr-4 py-2 bg-cyber-card border border-purple-800/40 rounded-xl text-xs sm:text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:border-cyan-400 transition-colors"
            />
          </div>
        </div>

        {/* 15 Topics in Responsive Two-Column Grid on Mobile */}
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-5">
          {filteredTopics.map((topic, index) => (
            <TopicCard key={topic.id} topic={topic} index={index} />
          ))}
        </div>

        {filteredTopics.length === 0 && (
          <div className="p-12 text-center bg-cyber-card/50 border border-purple-900/30 rounded-2xl">
            <p className="text-sm text-gray-400">No topics match your search query &ldquo;{searchQuery}&rdquo;.</p>
            <button
              onClick={() => setSearchQuery('')}
              className="mt-3 text-xs text-cyan-400 hover:underline"
            >
              Clear filter
            </button>
          </div>
        )}

      </section>

      {/* The 5-Step Learning Loop Visualizer */}
      <section className="p-6 sm:p-8 rounded-3xl bg-cyber-card border border-purple-900/40 space-y-6">
        <div className="text-center max-w-xl mx-auto">
          <h3 className="text-lg sm:text-xl font-bold text-white">
            The CODETALES Pedagogical Flow
          </h3>
          <p className="text-xs text-gray-400 mt-1">
            Engineered from cognitive science principles to turn abstract syntax into persistent mental models.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { step: '01', title: 'Pick Topic', desc: 'Select from 15 core computer science domains.' },
            { step: '02', title: 'Pick Concept', desc: 'Isolate a specific technical concept or algorithm.' },
            { step: '03', title: 'Customize', desc: 'Choose genre, length, difficulty, character & setting.' },
            { step: '04', title: 'AI Story', desc: 'Read or listen to the technical allegory with highlighted terms.' },
            { step: '05', title: 'Mapping', desc: 'Inspect how the fiction matches real CS architecture.' },
            { step: '06', title: 'Gamified Quiz', desc: 'Test retention and cement your newfound mastery.' },
          ].map((item) => (
            <div key={item.step} className="p-3.5 rounded-xl bg-purple-950/20 border border-purple-900/30 text-center">
              <span className="text-[10px] font-mono font-bold text-cyan-400 px-1.5 py-0.5 rounded bg-cyan-950/50 border border-cyan-500/30">
                {item.step}
              </span>
              <div className="text-xs font-bold text-white mt-2">{item.title}</div>
              <div className="text-[10px] text-gray-400 mt-1 leading-snug">{item.desc}</div>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}
