import { NextRequest, NextResponse } from 'next/server';
import { TOPICS } from '@/data/topics';
import { generateStoryWithHuggingFace, getHuggingFaceToken, getHuggingFaceModel } from '@/lib/huggingface';
import { buildStoryPrompt } from '@/lib/gemini';
import { synthesizePedagogicalStory } from '@/lib/story-engine';
import { StoryCustomization } from '@/types';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      topicId,
      conceptId,
      genre = 'Science Fiction',
      difficulty = 'Beginner',
      length = 'Medium',
      characterName,
      setting,
      customApiKey, // Can be user's Hugging Face token or Gemini key
      hfModel,
      provider = 'huggingface',
    } = body;

    const topic = TOPICS.find((t) => t.id === topicId) || TOPICS[0];
    const concept = topic.concepts.find((c) => c.id === conceptId) || topic.concepts[0];

    const customization: StoryCustomization = {
      topicId: topic.id,
      conceptId: concept.id,
      genre,
      difficulty,
      length,
      characterName,
      setting,
    };

    // Priority 1: Hugging Face Transformers Integration
    const hfToken = getHuggingFaceToken(customApiKey);

    if (hfToken) {
      try {
        const story = await generateStoryWithHuggingFace(
          customization,
          topic.name,
          concept.name,
          concept.keyTerms,
          hfToken,
          hfModel
        );

        return NextResponse.json({
          success: true,
          story,
          provider: 'huggingface-transformers',
          model: getHuggingFaceModel(hfModel),
        });
      } catch (hfError: any) {
        console.warn('Hugging Face generation error, applying pedagogical fallback:', hfError?.message);
        const fallbackStory = synthesizePedagogicalStory(
          customization,
          topic.name,
          concept.name,
          concept.keyTerms
        );
        return NextResponse.json({
          success: true,
          story: fallbackStory,
          provider: 'pedagogical-grounding',
          notice: `Hugging Face notice: ${hfError.message || 'Model execution fallback applied.'}`,
        });
      }
    }

    // Priority 2: Alternative Gemini provider if Gemini key is set
    const geminiKey = process.env.GEMINI_API_KEY || (customApiKey?.startsWith('AIza') ? customApiKey : '');
    if (geminiKey) {
      try {
        const prompt = buildStoryPrompt(customization, topic.name, concept.name, concept.keyTerms);
        const response = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${geminiKey}`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              contents: [{ parts: [{ text: prompt }] }],
              generationConfig: {
                temperature: 0.7,
                responseMimeType: 'application/json',
              },
            }),
            signal: AbortSignal.timeout(20000),
          }
        );

        if (response.ok) {
          const data = await response.json();
          const rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text;
          if (rawText) {
            const parsed = JSON.parse(rawText);
            const story = {
              id: 'story_' + Math.random().toString(36).substring(2, 9),
              title: parsed.title || `The Legend of ${concept.name}`,
              topicId: topic.id,
              topicName: topic.name,
              conceptId: concept.id,
              conceptName: concept.name,
              genre: customization.genre,
              difficulty: customization.difficulty,
              length: customization.length,
              characterName: customization.characterName || 'The Protagonist',
              setting: customization.setting || 'The Cyber Realm',
              paragraphs: parsed.paragraphs || [rawText],
              keyTerms: parsed.keyTerms || concept.keyTerms,
              readingTimeMinutes: parsed.readingTimeMinutes || 3,
              conceptMappings: parsed.conceptMappings || [],
              createdAt: new Date().toISOString(),
            };

            return NextResponse.json({
              success: true,
              story,
              provider: 'gemini-fallback',
            });
          }
        }
      } catch (geminiError: any) {
        console.warn('Gemini fallback attempt failed:', geminiError?.message);
      }
    }

    // Priority 3: Dynamic pedagogical generation engine (Zero downtime, zero failures)
    const story = synthesizePedagogicalStory(
      customization,
      topic.name,
      concept.name,
      concept.keyTerms
    );

    return NextResponse.json({
      success: true,
      story,
      provider: 'pedagogical-grounding',
      notice: 'Hugging Face Transformers ready. You can configure your custom HF_TOKEN in the AI Key menu.',
    });
  } catch (error: any) {
    console.error('API generate-story fatal error:', error);
    return NextResponse.json(
      { success: false, error: error?.message || 'Failed to generate story' },
      { status: 500 }
    );
  }
}
