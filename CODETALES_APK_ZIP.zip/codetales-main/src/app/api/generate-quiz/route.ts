import { NextRequest, NextResponse } from 'next/server';
import { generateQuizWithHuggingFace, getHuggingFaceToken, getHuggingFaceModel } from '@/lib/huggingface';
import { buildQuizPrompt } from '@/lib/gemini';
import { synthesizePedagogicalQuiz } from '@/lib/quiz-engine';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      topicName = 'Computer Science',
      conceptName = 'Core Concept',
      storyTitle = 'The Tale',
      storySummary = '',
      customApiKey,
      hfModel,
      provider = 'huggingface',
    } = body;

    // Priority 1: Hugging Face Transformers Integration
    const hfToken = getHuggingFaceToken(customApiKey);

    if (hfToken) {
      try {
        const questions = await generateQuizWithHuggingFace(
          topicName,
          conceptName,
          storyTitle,
          storySummary,
          hfToken,
          hfModel
        );

        return NextResponse.json({
          success: true,
          questions,
          provider: 'huggingface-transformers',
          model: getHuggingFaceModel(hfModel),
        });
      } catch (hfError: any) {
        console.warn('Hugging Face quiz generation error, applying pedagogical fallback:', hfError?.message);
        const fallbackQuestions = synthesizePedagogicalQuiz(
          topicName,
          conceptName,
          storyTitle,
          storySummary
        );
        return NextResponse.json({
          success: true,
          questions: fallbackQuestions,
          provider: 'pedagogical-grounding',
          notice: `Hugging Face notice: ${hfError.message || 'Quiz generation fallback applied.'}`,
        });
      }
    }

    // Priority 2: Alternative Gemini provider if Gemini key is set
    const geminiKey = process.env.GEMINI_API_KEY || (customApiKey?.startsWith('AIza') ? customApiKey : '');
    if (geminiKey) {
      try {
        const prompt = buildQuizPrompt(topicName, conceptName, storyTitle, storySummary);

        const response = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${geminiKey}`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              contents: [{ parts: [{ text: prompt }] }],
              generationConfig: {
                temperature: 0.5,
                responseMimeType: 'application/json',
              },
            }),
            signal: AbortSignal.timeout(20000),
          }
        );

        if (response.ok) {
          const data = await response.json();
          const rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text;
          if (rawText) {
            const parsed = JSON.parse(rawText);
            if (Array.isArray(parsed.questions) && parsed.questions.length > 0) {
              return NextResponse.json({
                success: true,
                questions: parsed.questions,
                provider: 'gemini-fallback',
              });
            }
          }
        }
      } catch (geminiError: any) {
        console.warn('Gemini quiz attempt failed:', geminiError?.message);
      }
    }

    // Priority 3: Dynamic pedagogical generation engine (Zero downtime, zero failures)
    const questions = synthesizePedagogicalQuiz(
      topicName,
      conceptName,
      storyTitle,
      storySummary
    );

    return NextResponse.json({
      success: true,
      questions,
      provider: 'pedagogical-grounding',
      notice: 'Hugging Face Transformers ready. You can configure your custom HF_TOKEN in the AI Key menu.',
    });
  } catch (error: any) {
    console.error('API generate-quiz fatal error:', error);
    return NextResponse.json(
      { success: false, error: error?.message || 'Failed to generate quiz' },
      { status: 500 }
    );
  }
}
