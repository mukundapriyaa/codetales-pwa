'use client';

import React, { useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { 
  ArrowLeft, Sparkles, ChevronRight, Layers, 
  Terminal, Cpu, Coffee, FileCode2, Network, 
  Boxes, Globe, Palette, Code, Database, 
  HardDrive, Wifi, Filter, BookOpen 
} from 'lucide-react';
import { TOPICS } from '@/data/topics';
import { Difficulty } from '@/types';

const iconMap: Record<string, React.ElementType> = {
  Terminal,
  Cpu,
  Coffee,
  FileCode2,
  Layers,
  Network,
  Sparkles,
  Boxes,
  Globe,
  Palette,
  Code,
  Database,
  HardDrive,
  Wifi,
};

export default function TopicConceptsPage() {
  const params = useParams();
  const router = useRouter();
  const topicId = params?.id as string;

  const topic = TOPICS.find((t) => t.id === topicId) || TOPICS[0];
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('All');
  const [searchFilter, setSearchFilter] = useState('');

  const IconComponent = iconMap[topic.icon] || BookOpen;

  const filteredConcepts = topic.concepts.filter((concept) => {
    const matchesDiff = selectedDifficulty === 'All' || concept.difficulty === selectedDifficulty;
    const matchesSearch = 
      concept.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
      concept.description.toLowerCase().includes(searchFilter.toLowerCase()) ||
      concept.keyTerms.some(t => t.toLowerCase().includes(searchFilter.toLowerCase()));
    return matchesDiff && matchesSearch;
  });

  const getDifficultyBadge = (diff: Difficulty) => {
    switch (diff) {
      case 'Beginner':
        return 'bg-emerald-950/50 border-emerald-500/40 text-emerald-300';
      case 'Intermediate':
        return 'bg-amber-950/50 border-amber-500/40 text-amber-300';
      case 'Advanced':
        return 'bg-rose-950/50 border-rose-500/40 text-rose-300';
    }
  };

  return (
    <div className="space-y-8 py-4 sm:py-6 animate-in fade-in duration-300">
      
      {/* Back navigation */}
      <Link
        href="/"
        className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-purple-950/30 border border-purple-800/40 text-xs font-medium text-cyan-400 hover:border-cyan-400 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to All Topics</span>
      </Link>

      {/* Topic Header Hero Banner */}
      <div 
        className="relative overflow-hidden rounded-3xl p-6 sm:p-10 border border-purple-900/40 bg-cyber-card shadow-cyber-card"
        style={{
          background: `linear-gradient(135deg, ${topic.color}15 0%, rgba(10, 10, 20, 0.95) 100%)`
        }}
      >
        <div 
          className="absolute -top-16 -right-16 w-64 h-64 rounded-full blur-3xl opacity-20 pointer-events-none"
          style={{ backgroundColor: topic.color }}
        />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div 
              className="w-14 h-14 rounded-2xl flex items-center justify-center border shadow-neon-purple flex-shrink-0"
              style={{ 
                backgroundColor: `${topic.color}20`,
                borderColor: `${topic.color}60`,
                color: topic.color 
              }}
            >
              <IconComponent className="w-7 h-7" />
            </div>
            <div>
              <span className="text-[11px] font-mono uppercase tracking-wider text-purple-400">
                {topic.badge}
              </span>
              <h1 className="text-2xl sm:text-4xl font-black text-white mt-0.5">
                {topic.name}
              </h1>
              <p className="text-xs sm:text-sm text-gray-300 mt-2 max-w-2xl leading-relaxed">
                {topic.description}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 self-start sm:self-center">
            <div className="px-4 py-2 rounded-xl bg-purple-950/40 border border-purple-800/40 text-center">
              <div className="text-lg font-black text-cyan-300">{topic.concepts.length}</div>
              <div className="text-[10px] uppercase tracking-wider text-gray-400">Total Concepts</div>
            </div>
          </div>
        </div>

      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        
        {/* Difficulty Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-cyber-card border border-purple-900/40 rounded-xl overflow-x-auto">
          {['All', 'Beginner', 'Intermediate', 'Advanced'].map((diff) => (
            <button
              key={diff}
              onClick={() => setSelectedDifficulty(diff)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                selectedDifficulty === diff
                  ? 'bg-purple-600 text-white shadow-neon-purple font-semibold'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {diff}
            </button>
          ))}
        </div>

        {/* Search input */}
        <div className="w-full sm:w-64">
          <input
            type="text"
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            placeholder={`Filter ${topic.name} concepts...`}
            className="w-full px-3.5 py-1.5 bg-cyber-card border border-purple-800/40 rounded-xl text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-cyan-400"
          />
        </div>

      </div>

      {/* Concepts List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredConcepts.map((concept, index) => (
          <div
            key={concept.id}
            className="group relative flex flex-col justify-between p-5 rounded-2xl bg-cyber-card/90 border border-purple-900/40 hover:border-cyan-400/80 transition-all duration-300 hover:shadow-neon-cyan hover:-translate-y-0.5"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono border font-medium ${getDifficultyBadge(concept.difficulty)}`}>
                  {concept.difficulty}
                </span>
                <span className="text-[10px] font-mono text-gray-500">
                  Concept #{String(index + 1).padStart(2, '0')}
                </span>
              </div>

              <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors">
                {concept.name}
              </h3>
              <p className="text-xs text-gray-300 mt-1.5 leading-relaxed">
                {concept.description}
              </p>

              {/* Key terms pills */}
              <div className="mt-4 flex flex-wrap gap-1.5">
                {concept.keyTerms.slice(0, 4).map((term, tIdx) => (
                  <span
                    key={tIdx}
                    className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950/40 border border-purple-800/30 text-purple-300"
                  >
                    #{term}
                  </span>
                ))}
              </div>
            </div>

            {/* Launch button */}
            <div className="mt-5 pt-3 border-t border-purple-900/30 flex items-center justify-between">
              <span className="text-[11px] text-gray-400 font-mono">
                AI Allegory Ready
              </span>
              <button
                onClick={() => router.push(`/customize?topicId=${topic.id}&conceptId=${concept.id}`)}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 text-xs font-bold text-white shadow-neon-purple hover:scale-105 active:scale-95 transition-all flex items-center gap-1.5"
              >
                <span>Customize Story</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>
        ))}
      </div>

      {filteredConcepts.length === 0 && (
        <div className="p-12 text-center bg-cyber-card/40 border border-purple-900/30 rounded-2xl">
          <p className="text-sm text-gray-400">No concepts match the selected filter.</p>
          <button
            onClick={() => { setSelectedDifficulty('All'); setSearchFilter(''); }}
            className="mt-2 text-xs text-cyan-400 hover:underline"
          >
            Reset Filters
          </button>
        </div>
      )}

    </div>
  );
}
