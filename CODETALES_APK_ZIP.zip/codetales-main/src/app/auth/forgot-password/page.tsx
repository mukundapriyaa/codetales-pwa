'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, Mail, Sparkles, CheckCircle2, AlertCircle } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!email) {
      setErrorMsg('Please enter your email address.');
      return;
    }

    setLoading(true);

    try {
      if (isSupabaseConfigured) {
        const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
          redirectTo: `${window.location.origin}/auth/login`,
        });
        if (error) throw error;
      }
      setSubmitted(true);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to send recovery instructions.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto py-8 sm:py-16 space-y-6 animate-in fade-in duration-300">
      
      <Link
        href="/auth/login"
        className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-purple-950/30 border border-purple-800/40 text-xs font-medium text-cyan-400 hover:border-cyan-400 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Sign In</span>
      </Link>

      <div className="text-center space-y-2">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-600 to-cyan-500 p-[2px] shadow-neon-purple mb-2">
          <div className="w-full h-full bg-cyber-dark rounded-[14px] flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-cyan-400" />
          </div>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white">
          Reset Password
        </h1>
        <p className="text-xs text-gray-400">
          Enter your registered email to receive access recovery instructions.
        </p>
      </div>

      <div className="p-6 sm:p-8 rounded-3xl bg-cyber-card border border-purple-500/30 shadow-neon-purple space-y-5">
        
        {submitted ? (
          <div className="text-center space-y-4 py-4">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
            <h3 className="text-lg font-bold text-white">Recovery Signal Transmitted</h3>
            <p className="text-xs text-gray-300 leading-relaxed">
              If an account exists for <strong className="text-cyan-300">{email}</strong>, a password recovery transmission has been dispatched.
            </p>
            <Link
              href="/auth/login"
              className="inline-block mt-4 px-6 py-2.5 rounded-xl bg-purple-600 text-xs font-bold text-white shadow-neon-purple"
            >
              Return to Login
            </Link>
          </div>
        ) : (
          <form onSubmit={handleReset} className="space-y-4">
            {errorMsg && (
              <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/40 text-xs text-rose-300 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-mono text-gray-300 mb-1.5">
                Registered Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="developer@matrix.io"
                  className="w-full pl-9 pr-3.5 py-2.5 bg-cyber-surface border border-purple-800/40 rounded-xl text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:border-cyan-400 transition-colors"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 text-white font-bold text-sm shadow-neon-purple hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 transition-all"
            >
              {loading ? 'Transmitting...' : 'Send Recovery Instructions'}
            </button>
          </form>
        )}

      </div>

    </div>
  );
}
