'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Lock, Mail, ArrowRight, Sparkles, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

export default function LoginPage() {
  const router = useRouter();
  const { login } = useAuth();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!email || !password) {
      setErrorMsg('Please enter both email and password.');
      return;
    }

    setLoading(true);

    try {
      await login(email.trim(), password);
      setSuccessMsg('Authentication successful! Teleporting to your vault...');
      setTimeout(() => {
        router.push('/profile');
      }, 500);
    } catch (err: any) {
      setErrorMsg(err.message || 'Invalid credentials or sign-in failure.');
      setLoading(false);
    }
  };

  const handleDemoSignIn = async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      await login('demo.coder@codetales.ai', 'demo1234');
      setSuccessMsg('Demo session active! Teleporting to your vault...');
      setTimeout(() => {
        router.push('/profile');
      }, 500);
    } catch (err: any) {
      setErrorMsg(err.message || 'Demo sign-in failed.');
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto py-8 sm:py-16 space-y-6 animate-in fade-in duration-300">
      
      {/* Brand Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-600 via-indigo-600 to-cyan-500 p-[2px] shadow-neon-purple mb-2">
          <div className="w-full h-full bg-cyber-dark rounded-[14px] flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-cyan-400" />
          </div>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white">
          Access Your Cyber Vault
        </h1>
        <p className="text-xs text-gray-400">
          Sign in to preserve your learning progress and assessment scores.
        </p>
      </div>

      {/* Main Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-cyber-card border border-purple-500/30 shadow-neon-purple space-y-5">
        
        {errorMsg && (
          <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/40 text-xs text-rose-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-mono text-gray-300 mb-1.5">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="developer@matrix.io"
                className="w-full pl-9 pr-3.5 py-2.5 bg-cyber-surface border border-purple-800/40 rounded-xl text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:border-cyan-400 transition-colors"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-mono text-gray-300">
                Password
              </label>
              <Link
                href="/auth/forgot-password"
                className="text-xs text-purple-400 hover:text-cyan-400 transition-colors"
              >
                Forgot password?
              </Link>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full pl-9 pr-3.5 py-2.5 bg-cyber-surface border border-purple-800/40 rounded-xl text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:border-cyan-400 transition-colors"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 text-white font-bold text-sm shadow-neon-purple hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 transition-all flex items-center justify-center gap-2"
          >
            {loading ? (
              <span>Authenticating...</span>
            ) : (
              <>
                <span>Sign In</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        <div className="relative flex py-2 items-center">
          <div className="flex-grow border-t border-purple-900/40"></div>
          <span className="flex-shrink mx-3 text-[11px] font-mono text-gray-500 uppercase">Or</span>
          <div className="flex-grow border-t border-purple-900/40"></div>
        </div>

        {/* 1-Click Demo Login Button */}
        <button
          onClick={handleDemoSignIn}
          type="button"
          disabled={loading}
          className="w-full py-2.5 rounded-xl bg-purple-950/40 border border-purple-800/40 hover:border-cyan-400 text-xs font-semibold text-cyan-300 transition-colors text-center"
        >
          Instant Demo Sign In (1-Click)
        </button>

        <div className="text-center text-xs text-gray-400 pt-2">
          Don&apos;t have an account yet?{' '}
          <Link href="/auth/signup" className="text-cyan-400 font-semibold hover:underline">
            Create account
          </Link>
        </div>

      </div>

    </div>
  );
}
