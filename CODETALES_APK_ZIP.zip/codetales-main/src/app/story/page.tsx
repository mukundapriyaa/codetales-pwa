'use client';

import React, { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { 
  ArrowLeft, Headphones, Award, Sparkles, BookOpen, 
  Clock, Share2, Layers, CheckCircle2, Bookmark, Check 
} from 'lucide-react';
import { GeneratedStory } from '@/types';
import { getSavedStories } from '@/lib/storage';
import AudioPlayer from '@/components/AudioPlayer';

function StoryContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const storyId = searchParams.get('id');

  const [story, setStory] = useState<GeneratedStory | null>(null);
  const [audioOpen, setAudioOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeTerm, setActiveTerm] = useState<string | null>(null);

  useEffect(() => {
    // 1. Try reading from sessionStorage
    const stored = sessionStorage.getItem('current_story');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (!storyId || parsed.id === storyId) {
          setStory(parsed);
          return;
        }
      } catch (e) {
        console.error('Failed to parse current_story', e);
      }
    }

    // 2. Try looking up in saved stories
    if (storyId) {
      const saved = getSavedStories();
      const match = saved.find((s) => s.id === storyId);
      if (match) {
        setStory(match);
        return;
      }
    }

    // 3. Fallback: Take first saved story or redirect
    const allSaved = getSavedStories();
    if (allSaved.length > 0) {
      setStory(allSaved[0]);
    } else {
      router.push('/customize');
    }
  }, [storyId, router]);

  const handleShare = () => {
    if (typeof window !== 'undefined') {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleTakeQuiz = () => {
    if (story) {
      sessionStorage.setItem('current_story', JSON.stringify(story));
      router.push(`/quiz?storyId=${story.id}`);
    }
  };

  // Helper to render text with highlighted **terms**
  const renderParagraph = (text: string, pIdx: number) => {
    const parts = text.split(/(\*\*[^*]+\*\*)/g);

    return (
      <p key={pIdx} className="text-base sm:text-lg text-gray-200 leading-relaxed sm:leading-loose">
        {parts.map((part, idx) => {
          if (part.startsWith('**') && part.endsWith('**')) {
            const cleanTerm = part.slice(2, -2);
            return (
              <span
                key={idx}
                onClick={() => setActiveTerm(cleanTerm)}
                className="tech-term"
                title={`Technical term: ${cleanTerm} (Click to inspect)`}
              >
                {cleanTerm}
              </span>
            );
          }
          return part;
        })}
      </p>
    );
  };

  if (!story) {
    return (
      <div className="py-20 text-center font-mono text-cyan-400 flex flex-col items-center gap-3">
        <Sparkles className="w-8 h-8 animate-spin" />
        <span>Retrieving Tale Archives...</span>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-4 sm:py-8 space-y-10 animate-in fade-in duration-300">
      
      {/* Top Navigation & Meta */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-purple-900/40">
        <Link
          href={`/topic/${story.topicId}`}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-purple-950/30 border border-purple-800/40 text-xs font-medium text-cyan-400 hover:border-cyan-400 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to {story.topicName}</span>
        </Link>

        <div className="flex items-center gap-2">
          <button
            onClick={handleShare}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyber-card border border-purple-800/40 text-xs text-gray-300 hover:text-white transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-cyan-400" /> : <Share2 className="w-3.5 h-3.5" />}
            <span>{copied ? 'Link Copied!' : 'Share Tale'}</span>
          </button>
        </div>
      </div>

      {/* Story Header */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
          <span className="px-2.5 py-1 rounded-full bg-purple-950/60 border border-purple-700/50 text-purple-300">
            {story.topicName}
          </span>
          <span className="px-2.5 py-1 rounded-full bg-cyan-950/60 border border-cyan-500/50 text-cyan-300">
            {story.conceptName}
          </span>
          <span className="px-2.5 py-1 rounded-full bg-indigo-950/60 border border-indigo-700/50 text-indigo-300">
            {story.genre}
          </span>
          <span className="px-2.5 py-1 rounded-full bg-gray-900 border border-gray-700 text-gray-400 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {story.readingTimeMinutes} min read
          </span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
          {story.title}
        </h1>

        {story.characterName && (
          <p className="text-xs sm:text-sm text-gray-400 font-mono">
            Protagonist: <span className="text-cyan-300 font-bold">{story.characterName}</span>
            {story.setting && <> &bull; Setting: <span className="text-purple-300">{story.setting}</span></>}
          </p>
        )}
      </div>

      {/* Floating Action Bar (TTS & Quiz) */}
      <div className="sticky top-20 z-30 p-3 sm:p-4 rounded-2xl bg-[#070712]/90 backdrop-blur-xl border border-purple-700/50 shadow-neon-purple flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
          <span className="text-xs font-bold text-white hidden sm:inline">Story Audio Player & Assessment</span>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          {/* TTS Audio Player Button */}
          <button
            onClick={() => setAudioOpen(true)}
            className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-purple-950/80 border border-purple-500/60 hover:border-cyan-400 text-xs font-bold text-cyan-300 hover:text-white shadow-neon-blue transition-all flex items-center justify-center gap-2"
          >
            <Headphones className="w-4 h-4 text-cyan-400" />
            <span>Listen to Story (TTS)</span>
          </button>

          {/* Take Quiz Button */}
          <button
            onClick={handleTakeQuiz}
            className="flex-1 sm:flex-none px-5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 text-xs font-extrabold text-white shadow-neon-purple hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            <Award className="w-4 h-4" />
            <span>Take Quiz</span>
          </button>
        </div>
      </div>

      {/* Active Term Notification Pill */}
      {activeTerm && (
        <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-500/40 text-xs text-cyan-300 flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <span>Term highlighted: <strong>{activeTerm}</strong> — Notice how its role mirrors real-world computation.</span>
          </div>
          <button
            onClick={() => setActiveTerm(null)}
            className="text-gray-400 hover:text-white text-[11px] font-mono ml-2 underline"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Story Text Container */}
      <article className="p-6 sm:p-10 rounded-3xl bg-cyber-card border border-purple-900/40 shadow-cyber-card space-y-6">
        {story.paragraphs.map((p, idx) => renderParagraph(p, idx))}
      </article>

      {/* REQUIREMENT 11: STORY-TO-CONCEPT MAPPING SECTION */}
      <section className="space-y-6 pt-4">
        
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-widest mb-1">
            <Layers className="w-3.5 h-3.5" />
            <span>Conceptual Deconstruction</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            Story-to-Concept Mapping
          </h2>
          <p className="text-xs sm:text-sm text-gray-400 mt-1 max-w-2xl">
            How the characters, obstacles, and events in this tale directly symbolize the technical realities of {story.conceptName}.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {story.conceptMappings.map((mapping, idx) => (
            <div
              key={idx}
              className="p-5 rounded-2xl bg-cyber-card border border-purple-800/40 hover:border-cyan-400/70 transition-all flex flex-col justify-between"
            >
              <div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950/60 border border-purple-800/40 text-purple-300">
                  Mapping #{idx + 1}
                </span>

                <div className="mt-3">
                  <div className="text-[11px] font-mono text-cyan-400 uppercase">Story Metaphor</div>
                  <div className="text-sm font-bold text-white mt-0.5 leading-snug">
                    {mapping.storyElement}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-purple-900/30">
                  <div className="text-[11px] font-mono text-purple-400 uppercase">Computer Science Reality</div>
                  <div className="text-sm font-bold text-cyan-300 mt-0.5">
                    {mapping.technicalConcept}
                  </div>
                </div>

                <p className="text-xs text-gray-300 mt-2 leading-relaxed">
                  {mapping.explanation}
                </p>
              </div>

              <div className="mt-4 pt-2 flex items-center gap-1.5 text-[10px] text-gray-500 font-mono">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Verified Concept Grounding</span>
              </div>
            </div>
          ))}
        </div>

      </section>

      {/* Bottom Call-to-Action to Quiz */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-purple-950/60 via-indigo-950/60 to-cyan-950/60 border border-purple-500/40 text-center space-y-4 shadow-neon-purple">
        <h3 className="text-xl sm:text-2xl font-black text-white">
          Solidify Your Understanding
        </h3>
        <p className="text-xs sm:text-sm text-gray-300 max-w-md mx-auto leading-relaxed">
          Take the interactive gamified assessment. Questions are generated dynamically from {story.conceptName} and the story you just read.
        </p>
        <button
          onClick={handleTakeQuiz}
          className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 text-white font-extrabold text-sm shadow-neon-purple hover:scale-105 active:scale-95 transition-all inline-flex items-center gap-2"
        >
          <Award className="w-4 h-4" />
          <span>Launch Gamified Quiz</span>
        </button>
      </div>

      {/* Full-screen Futuristic Audio Player TTS */}
      <AudioPlayer
        isOpen={audioOpen}
        onClose={() => setAudioOpen(false)}
        storyTitle={story.title}
        topicName={story.topicName}
        conceptName={story.conceptName}
        paragraphs={story.paragraphs}
      />

    </div>
  );
}

export default function StoryPage() {
  return (
    <Suspense fallback={<div className="p-12 text-center text-cyan-400 font-mono">Loading Tale Reader...</div>}>
      <StoryContent />
    </Suspense>
  );
}
