import { GeneratedStory, StoryCustomization, QuizQuestion } from '@/types';
import { TOPICS } from '@/data/topics';

// Concept grounding templates for high-fidelity fallback or grounding enhancements
interface FallbackStoryBlueprint {
  title: string;
  elements: { storyElement: string; technicalConcept: string; explanation: string }[];
  generateStory: (char: string, setting: string, genre: string, difficulty: string, length: string) => string[];
  generateQuiz: () => QuizQuestion[];
}

export function buildStoryPrompt(custom: StoryCustomization, topicName: string, conceptName: string, keyTerms: string[]): string {
  const char = custom.characterName?.trim() || 'Alex the Code Weaver';
  const setting = custom.setting?.trim() || 'The Neon Matrix of Cyberia';

  return `You are a world-class Computer Science educator and award-winning fiction writer.
Your mission is to write an engaging, creative story that acts as an accurate educational allegory for a technical Computer Science concept.

TOPIC: ${topicName}
CONCEPT: ${conceptName}
GENRE: ${custom.genre}
DIFFICULTY LEVEL: ${custom.difficulty}
STORY LENGTH: ${custom.length} (Short = 300 words, Medium = 600 words, Long = 900 words)
PROTAGONIST: ${char}
SETTING: ${setting}
KEY TECHNICAL TERMS TO WEAVE IN: ${keyTerms.join(', ')}

STRICT REQUIREMENTS:
1. The story must be exciting and narrative-driven, fitting the requested genre (${custom.genre}).
2. Every core mechanic, obstacle, and resolution in the story must correspond DIRECTLY to how the Computer Science concept "${conceptName}" actually works.
3. Surround important technical terms in the story with double asterisks like **term** so the user's interface can highlight them.
4. Provide a clear "conceptMappings" section explaining how specific story elements symbolize technical realities (e.g. "Entering smaller nested chambers = Recursive call frames").
5. The explanation must be pedagogically sound and accurate for the ${custom.difficulty} level.
6. Return ONLY valid JSON in this exact structure without markdown backticks:
{
  "title": "A captivating, evocative title for the tale",
  "paragraphs": [
    "First paragraph...",
    "Second paragraph...",
    "Third paragraph..."
  ],
  "keyTerms": ["term1", "term2", "term3"],
  "readingTimeMinutes": 3,
  "conceptMappings": [
    {
      "storyElement": "The nested chambers descending deeper into the tower",
      "technicalConcept": "Recursive Call Stack",
      "explanation": "Each new chamber entered represents a new stack frame created when a function calls itself."
    },
    {
      "storyElement": "The ancient golden lock with no further doors",
      "technicalConcept": "Base Case",
      "explanation": "The stopping condition that halts infinite recursion and triggers the return sequence."
    },
    {
      "storyElement": "Carrying the crystal back up through every room previously visited",
      "technicalConcept": "Stack Unwinding & Return Values",
      "explanation": "Each recursive call resolves its return value back up to the caller in reverse order (LIFO)."
    }
  ]
}`;
}

export function buildQuizPrompt(topicName: string, conceptName: string, storyTitle: string, storySummary: string): string {
  return `You are an expert Computer Science professor creating an interactive gamified assessment.
Based on the concept "${conceptName}" from "${topicName}" and the educational story "${storyTitle}", create 5 challenging multiple-choice questions.

STORY CONTEXT:
${storySummary}

REQUIREMENTS:
1. Exactly 5 multiple-choice questions.
2. 4 options per question labeled 'A', 'B', 'C', 'D'.
3. Only ONE unambiguously correct answer per question.
4. Ground questions in both the conceptual metaphor of the story and real-world Computer Science principles.
5. Provide a clear, educational explanation for why the correct answer is right and why distractors are wrong.
6. Return ONLY valid JSON in this exact structure without markdown backticks:
{
  "questions": [
    {
      "id": 1,
      "question": "What is the primary purpose of...",
      "options": [
        { "id": "A", "text": "Option A text" },
        { "id": "B", "text": "Option B text" },
        { "id": "C", "text": "Option C text" },
        { "id": "D", "text": "Option D text" }
      ],
      "correctAnswerId": "B",
      "explanation": "Detailed explanation of why B is correct..."
    }
  ]
}`;
}

// Procedural high-fidelity generator when API keys are not supplied or hit limits
export function generateProceduralStory(custom: StoryCustomization): GeneratedStory {
  const topic = TOPICS.find(t => t.id === custom.topicId) || TOPICS[3]; // Python default
  const concept = topic.concepts.find(c => c.id === custom.conceptId) || topic.concepts[0];
  const char = custom.characterName?.trim() || 'Aiden the Cyber-Archivist';
  const setting = custom.setting?.trim() || 'The Obsidian Spire of Neo-Arcadia';
  const now = new Date().toISOString();
  const storyId = 'story_' + Math.random().toString(36).substring(2, 9);

  const title = `The Chronicle of ${concept.name}: ${char} in ${setting}`;
  
  // Custom narrative depending on concept and genre
  const paragraphs: string[] = [
    `In the neon-drenched depths of ${setting}, the digital atmospheric pressure hummed at peak frequencies. ${char} stood before the towering holographic terminal, their neural interface flickering with pulses of electric blue. Today's mission was unlike any other: a critical system failure in the core matrix threatened total collapse unless the ancient protocol of **${concept.name}** could be decoded and executed.`,
    
    `"Every computational structure has a pulse," muttered ${char}, analyzing the glowing telemetry. In this realm, understanding **${concept.keyTerms[0] || 'memory allocation'}** was the difference between harmony and total fragmentation. As security droids hovered nearby with scanning lasers, ${char} initiated the primary sequence. The system reacted instantly, requiring precise alignment of **${concept.keyTerms[1] || 'data structures'}** to unlock the subsequent security layers.`,
    
    `The architectural challenge unfolded before them. Just as the rules of **${topic.name}** dictated, every action carried irreversible weight. The telemetry streamed raw packets across the air; to stabilize the conduit, ${char} had to respect the fundamental constraints of **${concept.keyTerms[2] || 'control flow'}**. One misplaced index or improper reference would trigger an irreversible fault cascading through the entire subterranean network.`,
    
    `Drawing upon deep foundational knowledge, ${char} deployed a master solution utilizing **${concept.keyTerms[3] || 'optimal execution'}**. The fluctuating flux fields suddenly snapped into crisp equilibrium. The terminal flashed bright ultraviolet, signaling that the state of **${concept.name}** was flawlessly verified. The automated sirens ceased their wail, replaced by the serene chime of computational perfection. ${char} smiled, knowing the digital sanctuary was secure for another cycle.`
  ];

  if (custom.length === 'Long') {
    paragraphs.push(
      `Reflecting upon the battle, ${char} documented the breakthrough in the central databank: "Never underestimate the elegance of foundational concepts. When we structure our logic with clarity and discipline, even the most chaotic systems yield to predictable beauty."`
    );
  }

  const conceptMappings = [
    {
      storyElement: `The terminal requiring the exact sequence of ${concept.name}`,
      technicalConcept: `${concept.name} Execution Rules`,
      explanation: `Represents how the runtime or compiler enforces syntactic and logical correctness when evaluating ${concept.name}.`
    },
    {
      storyElement: `The security lasers and threat of total system collapse`,
      technicalConcept: `Error Conditions & Edge Cases`,
      explanation: `Symbolizes runtime crashes, exceptions, or memory corruption that occur when ${concept.keyTerms[0] || 'critical constraints'} are violated.`
    },
    {
      storyElement: `The ultraviolet stabilization and harmonious chime`,
      technicalConcept: `Deterministic Successful Output`,
      explanation: `Illustrates how proper implementation of ${concept.name} results in predictable, verifiable, and optimal program states.`
    }
  ];

  return {
    id: storyId,
    title,
    topicId: topic.id,
    topicName: topic.name,
    conceptId: concept.id,
    conceptName: concept.name,
    genre: custom.genre,
    difficulty: custom.difficulty,
    length: custom.length,
    characterName: char,
    setting,
    paragraphs,
    keyTerms: concept.keyTerms,
    readingTimeMinutes: custom.length === 'Short' ? 2 : custom.length === 'Medium' ? 4 : 6,
    conceptMappings,
    createdAt: now
  };
}

export function generateProceduralQuiz(topicName: string, conceptName: string, storyTitle: string): QuizQuestion[] {
  return [
    {
      id: 1,
      question: `In the context of ${conceptName}, what is the foundational responsibility of this mechanism?`,
      options: [
        { id: 'A', text: 'To randomly scramble data across physical memory sectors.' },
        { id: 'B', text: `To systematically manage and process data according to ${conceptName} specifications.` },
        { id: 'C', text: 'To terminate the operating system when memory exceeds 50% capacity.' },
        { id: 'D', text: 'To disable network firewalls during heavy processing workloads.' }
      ],
      correctAnswerId: 'B',
      explanation: `${conceptName} provides structured, deterministic rules for organizing, processing, or transforming data in computer systems.`
    },
    {
      id: 2,
      question: `In the story "${storyTitle}", how did the protagonist prevent system collapse?`,
      options: [
        { id: 'A', text: 'By ignoring error logs and resetting the power generator.' },
        { id: 'B', text: 'By deleting the entire root database permanently.' },
        { id: 'C', text: `By precisely respecting the rules and constraints of ${conceptName}.` },
        { id: 'D', text: 'By downloading an unverified binary from an unknown peer.' }
      ],
      correctAnswerId: 'C',
      explanation: 'Technical stability in software systems depends on adhering strictly to language protocols, memory boundaries, and algorithmic invariants.'
    },
    {
      id: 3,
      question: `Which of the following describes the most severe edge-case or failure mode associated with ${conceptName}?`,
      options: [
        { id: 'A', text: 'Violating boundary conditions leading to unexpected states or crashes.' },
        { id: 'B', text: 'Using standard naming conventions for identifiers.' },
        { id: 'C', text: 'Formatting code with consistent four-space indentation.' },
        { id: 'D', text: 'Documenting functions with clear docstrings and comments.' }
      ],
      correctAnswerId: 'A',
      explanation: 'Edge cases and boundary condition violations (such as off-by-one errors, infinite recursion, or null dereferences) are the primary sources of system failure.'
    },
    {
      id: 4,
      question: `How does mastering ${conceptName} in ${topicName} improve overall software architecture?`,
      options: [
        { id: 'A', text: 'It forces all applications to run in a single thread.' },
        { id: 'B', text: 'It enhances code maintainability, computational efficiency, and predictability.' },
        { id: 'C', text: 'It eliminates the need for unit testing and code reviews.' },
        { id: 'D', text: 'It restricts software deployment to only 32-bit hardware architectures.' }
      ],
      correctAnswerId: 'B',
      explanation: 'Deep understanding of core CS concepts enables developers to design efficient, bug-resilient architectures that scale gracefully.'
    },
    {
      id: 5,
      question: `What lesson from the story-to-concept mapping is most critical for engineering real-world systems?`,
      options: [
        { id: 'A', text: 'Shortcuts are always preferable to understanding underlying mechanics.' },
        { id: 'B', text: 'Complex systems can be mastered by decomposing them into clear mental models and verified rules.' },
        { id: 'C', text: 'Modern languages do not require conceptual understanding.' },
        { id: 'D', text: 'Errors should always be silenced rather than handled gracefully.' }
      ],
      correctAnswerId: 'B',
      explanation: 'Decomposing complex technical principles into intuitive mental models empowers engineers to write cleaner, more reliable software.'
    }
  ];
}
