import { QuizQuestion } from '@/types';

export function synthesizePedagogicalQuiz(
  topicName: string,
  conceptName: string,
  storyTitle: string,
  storySummary: string
): QuizQuestion[] {
  return [
    {
      id: 1,
      question: `In the context of ${topicName}, what is the foundational purpose of ${conceptName}?`,
      options: [
        { id: 'A', text: `To govern state, control flow, and enforce computational guarantees for ${conceptName}` },
        { id: 'B', text: `To bypass operating system kernel security boundaries entirely` },
        { id: 'C', text: `To replace hardware memory management with random access allocations` },
        { id: 'D', text: `To disable compilation checks and runtime type validation` }
      ],
      correctAnswerId: 'A',
      explanation: `${conceptName} provides structured architectural rules within ${topicName} that govern state transitions, computational efficiency, and predictable execution.`
    },
    {
      id: 2,
      question: `How did the narrative events in "${storyTitle}" represent the underlying mechanics of ${conceptName}?`,
      options: [
        { id: 'A', text: `By ignoring physical laws and executing undefined behavior` },
        { id: 'B', text: `By using physical metaphors and obstacles that directly mirror real computational state changes` },
        { id: 'C', text: `By converting all data into uncompressed text files on disk` },
        { id: 'D', text: `By running synchronous blocking tasks in the main user interface thread` }
      ],
      correctAnswerId: 'B',
      explanation: `Pedagogical allegories map abstract software architecture (such as call stacks, memory cells, or packet handshakes) into tangible narrative challenges.`
    },
    {
      id: 3,
      question: `Which critical boundary condition or edge case must engineers handle when implementing ${conceptName}?`,
      options: [
        { id: 'A', text: `Preventing infinite loops, memory leaks, or unhandled null states` },
        { id: 'B', text: `Assuming unlimited RAM and zero-latency hardware at all times` },
        { id: 'C', text: `Hardcoding all variables as global static mutable constants` },
        { id: 'D', text: `Suppressing all error signals and exceptions automatically` }
      ],
      correctAnswerId: 'A',
      explanation: `Robust computer science implementations require strictly validating termination criteria, memory bounds, and invariant conditions to avoid system crashes.`
    },
    {
      id: 4,
      question: `What is the computational trade-off commonly associated with optimizing ${conceptName}?`,
      options: [
        { id: 'A', text: `Time complexity vs. Space (memory) complexity requirements` },
        { id: 'B', text: `Operating system version vs. monitor screen refresh rate` },
        { id: 'C', text: `Variable identifier length vs. network packet MTU size` },
        { id: 'D', text: `Code comments count vs. CPU transistor temperature` }
      ],
      correctAnswerId: 'A',
      explanation: `The fundamental tradeoff in algorithm and systems design is time vs. space: faster lookups often require additional memory caches or auxiliary indices.`
    },
    {
      id: 5,
      question: `When deploying production systems in ${topicName}, what confirms that ${conceptName} has stabilized?`,
      options: [
        { id: 'A', text: `Continuous uncontrolled recursion until physical memory exhausts` },
        { id: 'B', text: `Successful invariant verification, deterministic return values, and resource deallocation` },
        { id: 'C', text: `Re-executing the entire program from source on every user keystroke` },
        { id: 'D', text: `Writing unencrypted memory buffers directly to public networks` }
      ],
      correctAnswerId: 'B',
      explanation: `A system stabilizes when all execution paths terminate cleanly, resource cleanup (RAII / garbage collection) completes, and outputs adhere to specification contracts.`
    }
  ];
}
