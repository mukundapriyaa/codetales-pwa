import { HfInference } from '@huggingface/inference';
import { StoryCustomization, GeneratedStory, QuizQuestion, ConceptMapping } from '@/types';

// Configurable Hugging Face model supporting text-generation / chat completions
export const DEFAULT_HF_MODEL = process.env.HUGGINGFACE_MODEL || 'Qwen/Qwen2.5-72B-Instruct';

// Verified text-generation models supported on Hugging Face Inference Providers
export const VERIFIED_TEXT_MODELS = [
  'Qwen/Qwen2.5-72B-Instruct',
  'meta-llama/Llama-3.3-70B-Instruct',
  'meta-llama/Llama-3.1-8B-Instruct',
  'mistralai/Mistral-7B-Instruct-v0.3',
  'google/gemma-2-9b-it',
  'HuggingFaceH4/zephyr-7b-beta',
];

export function getHuggingFaceToken(customKey?: string): string {
  return (
    customKey?.trim() ||
    process.env.HUGGINGFACE_API_KEY?.trim() ||
    process.env.HF_TOKEN?.trim() ||
    process.env.HUGGINGFACE_TOKEN?.trim() ||
    ''
  );
}

export function getHuggingFaceModel(customModel?: string): string {
  return customModel?.trim() || process.env.HUGGINGFACE_MODEL?.trim() || DEFAULT_HF_MODEL;
}

// Clean and parse JSON from Hugging Face text generation output
export function extractJsonFromText(rawText: string): any {
  if (!rawText) throw new Error('Model returned an empty response.');

  let cleaned = rawText.trim();

  // Strip markdown code fences if present
  if (cleaned.includes('```json')) {
    const match = cleaned.match(/```json\s*([\s\S]*?)\s*```/);
    if (match && match[1]) {
      cleaned = match[1].trim();
    }
  } else if (cleaned.includes('```')) {
    const match = cleaned.match(/```\s*([\s\S]*?)\s*```/);
    if (match && match[1]) {
      cleaned = match[1].trim();
    }
  }

  // Find outermost JSON object or array
  const firstBrace = cleaned.indexOf('{');
  const lastBrace = cleaned.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
    cleaned = cleaned.substring(firstBrace, lastBrace + 1);
  }

  return JSON.parse(cleaned);
}

// Build Hugging Face system & user prompts for story generation
export function buildHfStoryMessages(
  custom: StoryCustomization,
  topicName: string,
  conceptName: string,
  keyTerms: string[]
) {
  const protagonist = custom.characterName?.trim() || 'Ada the Systems Weaver';
  const setting = custom.setting?.trim() || 'The Neon Matrix of Neo-Arcadia';

  const systemPrompt = `You are a world-class Computer Science educator and award-winning fiction author.
Your task is to generate a rich, accurate educational allegory story that explains a technical Computer Science concept through an engaging narrative.

STRICT ACCURACY RULES:
1. Explain the technical concept "${conceptName}" accurately through the story's events.
2. Every major event, obstacle, and resolution must directly symbolize how the concept operates in real-world systems.
3. Highlight all important technical terms in the text by surrounding them in double asterisks, like **term**.
4. Include an explicit "conceptMappings" array detailing how specific story metaphors represent the real CS principles.
5. Output ONLY valid, parseable JSON with NO markdown backticks or extra text outside the JSON object.`;

  const userPrompt = `TOPIC: ${topicName}
CONCEPT: ${conceptName}
GENRE: ${custom.genre}
DIFFICULTY: ${custom.difficulty}
LENGTH: ${custom.length} (Target: Short ~300 words, Medium ~600 words, Long ~900 words)
PROTAGONIST: ${protagonist}
SETTING: ${setting}
KEY TERMS TO INCORPORATE: ${keyTerms.join(', ')}

Return ONLY JSON matching this exact structure:
{
  "title": "A compelling title for the story",
  "paragraphs": [
    "First paragraph of the story with **technical terms** highlighted...",
    "Second paragraph continuing the narrative...",
    "Third paragraph concluding with system stabilization..."
  ],
  "keyTerms": ["${keyTerms.slice(0, 4).join('", "')}"],
  "readingTimeMinutes": 3,
  "conceptMappings": [
    {
      "storyElement": "The specific metaphor or obstacle in the story",
      "technicalConcept": "The real CS concept it represents",
      "explanation": "Clear explanation of how the story element mirrors real-world mechanics"
    },
    {
      "storyElement": "The second story metaphor or action",
      "technicalConcept": "The underlying CS architectural rule",
      "explanation": "Clear explanation of the technical accuracy"
    },
    {
      "storyElement": "The third story element",
      "technicalConcept": "The resolution or output state",
      "explanation": "Clear explanation"
    }
  ]
}`;

  return [
    { role: 'system', content: systemPrompt },
    { role: 'user', content: userPrompt }
  ];
}

// Build Hugging Face system & user prompts for quiz generation
export function buildHfQuizMessages(
  topicName: string,
  conceptName: string,
  storyTitle: string,
  storySummary: string
) {
  const systemPrompt = `You are an expert Computer Science professor creating an interactive gamified assessment.
Create exactly 5 challenging multiple-choice questions based on the technical concept and story context.

REQUIREMENTS:
1. Exactly 5 multiple-choice questions.
2. 4 answer options per question labeled 'A', 'B', 'C', 'D'.
3. Exactly ONE unambiguously correct answer per question.
4. Ground questions in both the conceptual metaphor of the story and real Computer Science mechanics.
5. Provide a clear educational explanation for the correct answer.
6. Output ONLY valid JSON matching the requested schema with no commentary or markdown backticks outside.`;

  const userPrompt = `TOPIC: ${topicName}
CONCEPT: ${conceptName}
STORY TITLE: ${storyTitle}
STORY CONTEXT: ${storySummary}

Return ONLY JSON matching this exact schema:
{
  "questions": [
    {
      "id": 1,
      "question": "Question text here?",
      "options": [
        { "id": "A", "text": "Option A" },
        { "id": "B", "text": "Option B" },
        { "id": "C", "text": "Option C" },
        { "id": "D", "text": "Option D" }
      ],
      "correctAnswerId": "A",
      "explanation": "Detailed explanation of why A is correct..."
    }
  ]
}`;

  return [
    { role: 'system', content: systemPrompt },
    { role: 'user', content: userPrompt }
  ];
}

// Generate Story using Hugging Face Transformers Inference
export async function generateStoryWithHuggingFace(
  custom: StoryCustomization,
  topicName: string,
  conceptName: string,
  keyTerms: string[],
  customToken?: string,
  customModel?: string
): Promise<GeneratedStory> {
  const token = getHuggingFaceToken(customToken);
  if (!token) {
    throw new Error(
      'Hugging Face access token is missing. Please configure HUGGINGFACE_API_KEY (or HF_TOKEN) in your server environment variables, or enter your Hugging Face Token in the AI Key settings.'
    );
  }

  const model = getHuggingFaceModel(customModel);
  const messages = buildHfStoryMessages(custom, topicName, conceptName, keyTerms);

  const hf = new HfInference(token);

  let rawOutput = '';

  try {
    // 1. Try Chat Completion endpoint via HfInference / Hugging Face Router
    const response = await hf.chatCompletion({
      model,
      messages: messages as any,
      max_tokens: 2000,
      temperature: 0.7,
    });

    rawOutput = response.choices?.[0]?.message?.content || '';
  } catch (chatErr: any) {
    console.warn(`Hugging Face chatCompletion attempt with ${model} failed, trying router endpoint:`, chatErr?.message);

    // 2. Direct HTTP call to Hugging Face Inference Providers router as backup
    const routerUrl = 'https://router.huggingface.co/hf-inference/v1/chat/completions';
    const fallbackResp = await fetch(routerUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model,
        messages,
        max_tokens: 2000,
        temperature: 0.7,
      }),
      signal: AbortSignal.timeout(30000),
    });

    if (!fallbackResp.ok) {
      const errText = await fallbackResp.text();
      let parsedErr = errText;
      try {
        const jsonErr = JSON.parse(errText);
        parsedErr = jsonErr.error || jsonErr.message || errText;
      } catch {}
      throw new Error(`Hugging Face API Error (${fallbackResp.status}): ${parsedErr}`);
    }

    const data = await fallbackResp.json();
    rawOutput = data.choices?.[0]?.message?.content || '';
  }

  if (!rawOutput) {
    throw new Error('Hugging Face model generated an empty response.');
  }

  // Parse and validate story JSON
  const parsed = extractJsonFromText(rawOutput);

  if (!parsed.title || typeof parsed.title !== 'string') {
    throw new Error('Hugging Face response is missing a valid story title.');
  }

  if (!Array.isArray(parsed.paragraphs) || parsed.paragraphs.length === 0) {
    throw new Error('Hugging Face response does not contain valid story paragraphs.');
  }

  const conceptMappings: ConceptMapping[] = Array.isArray(parsed.conceptMappings) && parsed.conceptMappings.length > 0
    ? parsed.conceptMappings.map((m: any) => ({
        storyElement: String(m.storyElement || 'Narrative Element'),
        technicalConcept: String(m.technicalConcept || conceptName),
        explanation: String(m.explanation || 'Symbolizes real computational mechanics.'),
      }))
    : [
        {
          storyElement: `The operational rules of ${conceptName}`,
          technicalConcept: `${conceptName} Architectural Protocol`,
          explanation: `Mirrors how ${topicName} executes ${conceptName} in production software.`,
        }
      ];

  const now = new Date().toISOString();
  return {
    id: 'hf_' + Math.random().toString(36).substring(2, 9),
    title: parsed.title,
    topicId: custom.topicId,
    topicName,
    conceptId: custom.conceptId,
    conceptName,
    genre: custom.genre,
    difficulty: custom.difficulty,
    length: custom.length,
    characterName: custom.characterName || 'The Protagonist',
    setting: custom.setting || 'The Cyber Dimension',
    paragraphs: parsed.paragraphs,
    keyTerms: Array.isArray(parsed.keyTerms) && parsed.keyTerms.length > 0 ? parsed.keyTerms : keyTerms,
    readingTimeMinutes: Number(parsed.readingTimeMinutes) || (custom.length === 'Short' ? 2 : custom.length === 'Medium' ? 4 : 6),
    conceptMappings,
    createdAt: now,
  };
}

// Generate Quiz using Hugging Face Transformers Inference
export async function generateQuizWithHuggingFace(
  topicName: string,
  conceptName: string,
  storyTitle: string,
  storySummary: string,
  customToken?: string,
  customModel?: string
): Promise<QuizQuestion[]> {
  const token = getHuggingFaceToken(customToken);
  if (!token) {
    throw new Error(
      'Hugging Face access token is missing. Please configure HUGGINGFACE_API_KEY (or HF_TOKEN) in your server environment variables, or enter your Hugging Face Token in the AI Key settings.'
    );
  }

  const model = getHuggingFaceModel(customModel);
  const messages = buildHfQuizMessages(topicName, conceptName, storyTitle, storySummary);

  const hf = new HfInference(token);
  let rawOutput = '';

  try {
    const response = await hf.chatCompletion({
      model,
      messages: messages as any,
      max_tokens: 1800,
      temperature: 0.5,
    });

    rawOutput = response.choices?.[0]?.message?.content || '';
  } catch (chatErr: any) {
    console.warn(`Hugging Face quiz chatCompletion failed, trying direct router:`, chatErr?.message);

    const routerUrl = 'https://router.huggingface.co/hf-inference/v1/chat/completions';
    const fallbackResp = await fetch(routerUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model,
        messages,
        max_tokens: 1800,
        temperature: 0.5,
      }),
      signal: AbortSignal.timeout(30000),
    });

    if (!fallbackResp.ok) {
      const errText = await fallbackResp.text();
      let parsedErr = errText;
      try {
        const jsonErr = JSON.parse(errText);
        parsedErr = jsonErr.error || jsonErr.message || errText;
      } catch {}
      throw new Error(`Hugging Face API Error (${fallbackResp.status}): ${parsedErr}`);
    }

    const data = await fallbackResp.json();
    rawOutput = data.choices?.[0]?.message?.content || '';
  }

  if (!rawOutput) {
    throw new Error('Hugging Face model returned an empty quiz response.');
  }

  const parsed = extractJsonFromText(rawOutput);

  if (!Array.isArray(parsed.questions) || parsed.questions.length === 0) {
    throw new Error('Hugging Face response does not contain a valid questions array.');
  }

  // Validate each question
  const validatedQuestions: QuizQuestion[] = parsed.questions.map((q: any, idx: number) => {
    if (!q.question || typeof q.question !== 'string') {
      throw new Error(`Question #${idx + 1} is missing a question string.`);
    }

    if (!Array.isArray(q.options) || q.options.length !== 4) {
      throw new Error(`Question #${idx + 1} must contain exactly 4 answer options.`);
    }

    const validOptions = q.options.map((opt: any, optIdx: number) => ({
      id: opt.id || ['A', 'B', 'C', 'D'][optIdx],
      text: String(opt.text || ''),
    }));

    const validCorrectId = ['A', 'B', 'C', 'D'].includes(q.correctAnswerId)
      ? q.correctAnswerId
      : 'A';

    return {
      id: idx + 1,
      question: q.question,
      options: validOptions,
      correctAnswerId: validCorrectId,
      explanation: String(q.explanation || 'Detailed concept explanation.'),
    };
  });

  return validatedQuestions;
}
