import { StoryCustomization, GeneratedStory, ConceptMapping } from '@/types';
import { TOPICS } from '@/data/topics';

// Conceptual metaphor generators grounded in pedagogy
const METAPHORS: Record<string, {
  elements: ConceptMapping[];
  scenario: string;
}> = {
  'functions-recursion': {
    scenario: 'a nested sequence of dimensional vaults where each inner chamber holds a key to unlock the outer gate',
    elements: [
      {
        storyElement: 'Entering consecutive concentric vault chambers',
        technicalConcept: 'Recursive Call Stack Frames',
        explanation: 'Each step into a smaller chamber allocates a new execution context on the call stack preserving local state.'
      },
      {
        storyElement: 'Finding the smallest crystalline core with the primary release rune',
        technicalConcept: 'Base Case Condition',
        explanation: 'The terminal guard condition that halts further descent and prevents infinite recursion / stack overflow.'
      },
      {
        storyElement: 'Unlocking and retreating backwards through each chamber in reverse order',
        technicalConcept: 'Stack Frame Unwinding & Returns',
        explanation: 'Each completed sub-problem returns its computed value upward until the original top-level function completes.'
      }
    ]
  },
  'pointers-memory': {
    scenario: 'a labyrinth of numbered neon storage lockers where coordinates rather than items are traded',
    elements: [
      {
        storyElement: 'Reading the coordinates etched on a crystal beacon',
        technicalConcept: 'Memory Address Lookup',
        explanation: 'Accessing the physical hex address where the data resides rather than copying the value.'
      },
      {
        storyElement: 'Opening the locker pointed to by the holographic coordinate',
        technicalConcept: 'Dereferencing (*ptr)',
        explanation: 'Resolving a pointer address to read or write the actual value stored in that RAM cell.'
      },
      {
        storyElement: 'A corrupted map entry pointing to the infinite vacuum abyss',
        technicalConcept: 'Null Pointer & Segmentation Fault',
        explanation: 'Attempting to dereference unmapped or illegal memory triggers an immediate system panic.'
      }
    ]
  },
  'deadlock-bankers': {
    scenario: 'four cybernetic starcruisers caught in a synchronized tractor-beam intersection',
    elements: [
      {
        storyElement: 'Cruiser Alpha holds Beam 1 while requesting Beam 2 held by Beta',
        technicalConcept: 'Circular Wait Condition',
        explanation: 'A closed chain of processes each holding a resource while demanding a resource held by the next.'
      },
      {
        storyElement: 'The orbital beacon granting energy only if a safe trajectory remains open',
        technicalConcept: "Banker's Algorithm Safe State Check",
        explanation: 'Testing whether allocating requested units still leaves an operational order to avoid deadlock.'
      },
      {
        storyElement: 'Cruiser Delta releasing its tractor field to let the convoy clear',
        technicalConcept: 'Resource Preemption / Release',
        explanation: 'Breaking mutual exclusion or hold-and-wait to allow the execution pipeline to drain.'
      }
    ]
  },
  'virtual-memory-paging': {
    scenario: 'an archival palace with small display shelves and a vast subterranean storage warehouse',
    elements: [
      {
        storyElement: 'The archivist searching the front display desk for requested scrolls',
        technicalConcept: 'TLB (Translation Lookaside Buffer) Cache',
        explanation: 'Checking ultra-fast hardware associative memory to resolve virtual addresses to physical RAM frames.'
      },
      {
        storyElement: 'A scroll missing from the shelf triggering a retrieval expedition to the deep vaults',
        technicalConcept: 'Page Fault & Disk Swap',
        explanation: 'When the requested page is not in physical RAM, an interrupt fetches the page from slower secondary storage.'
      },
      {
        storyElement: 'Replacing the least-read scroll on the shelf to make room for the new arrival',
        technicalConcept: 'Page Replacement Algorithm (LRU)',
        explanation: 'Evicting memory frames using Least Recently Used heuristics to optimize hit ratios.'
      }
    ]
  },
  'tcp-handshake-udp': {
    scenario: 'two orbital stations establishing a cryptographic communication conduit before transmitting cargo',
    elements: [
      {
        storyElement: 'Transmitting the synchronize signal beacon from Station Alpha',
        technicalConcept: 'TCP SYN Packet',
        explanation: 'Initiating the transport handshake with an initial sequence number (ISN).'
      },
      {
        storyElement: 'Station Beta returning acknowledgement and its own synchronization pulse',
        technicalConcept: 'TCP SYN-ACK Response',
        explanation: 'Confirming receipt of sequence numbers and verifying bidirectional connectivity.'
      },
      {
        storyElement: 'Final confirmation beacon transmitted before reliable cargo flow begins',
        technicalConcept: 'TCP ACK Packet & Established State',
        explanation: 'Guarantees reliable, ordered, error-checked packet streams unlike stateless UDP datagrams.'
      }
    ]
  }
};

export function synthesizePedagogicalStory(
  custom: StoryCustomization,
  topicName: string,
  conceptName: string,
  keyTerms: string[]
): GeneratedStory {
  const protagonist = custom.characterName?.trim() || 'Ada the Systems Weaver';
  const setting = custom.setting?.trim() || 'The Quantum Core of Neo-Arcadia';
  const genre = custom.genre;
  const difficulty = custom.difficulty;

  // Find or generate concept mapping
  const known = METAPHORS[custom.conceptId];
  const conceptMappings: ConceptMapping[] = known ? known.elements : [
    {
      storyElement: `The operational rules governing ${conceptName} in ${setting}`,
      technicalConcept: `${conceptName} Architecture`,
      explanation: `Symbolizes how ${topicName} enforces memory, execution, and state guarantees for ${conceptName}.`
    },
    {
      storyElement: `The primary obstacle encountered by ${protagonist}`,
      technicalConcept: `${keyTerms[0] || 'State Invariant'} Constraint`,
      explanation: `Mirrors the core computational challenge and edge cases that engineers solve when designing ${conceptName}.`
    },
    {
      storyElement: `The resolution protocol executed to stabilize the matrix`,
      technicalConcept: `${keyTerms[1] || 'Resolution Algorithm'} Execution`,
      explanation: `Demonstrates the deterministic completion and correct termination of the algorithm in real hardware.`
    }
  ];

  // Genre flavor words
  const genreFlavor = {
    'Science Fiction': { world: 'neon-lit orbital terminal', threat: 'a cascade divergence in the mainframe', device: 'quantum logic scanner' },
    'Fantasy': { world: 'ancient citadel of ethereal crystal', threat: 'an unbound arcane resonance', device: 'runic cipher staff' },
    'Mystery': { world: 'shadowy rain-slicked metropolis', threat: 'a cryptographic blackout of missing records', device: 'forensic decryptor' },
    'Adventure': { world: 'forgotten subterranean ruins', threat: 'an ancient automated defense trap', device: 'relic navigation compass' },
    'Comedy': { world: 'chaotic automated bakery matrix', threat: 'a rogue pastry synthesizer running in an infinite loop', device: 'emergency spork overrides' }
  }[genre] || { world: 'cybernetic hub', threat: 'a system disruption', device: 'diagnostic probe' };

  const paragraphs: string[] = [
    `Within the heart of ${setting}, ${protagonist} stood before the towering computational monolith of ${topicName}. The air hummed with raw energy as ${genreFlavor.threat} threatened to destabilize the entire matrix. To prevent catastrophic collapse, ${protagonist} was tasked with mastering the intricate mechanics of **${conceptName}**, where every instruction obeyed immutable computational laws.`,
    
    `The primary challenge centered upon **${keyTerms[0] || 'memory allocation'}** and **${keyTerms[1] || 'runtime execution'}**. As ${protagonist} activated the ${genreFlavor.device}, the architecture revealed its true nature: data could not simply wander unchecked; it required strict adherence to **${keyTerms[2] || 'control flow'}**. In this ${genreFlavor.world}, every operation was bounded by **${keyTerms[3] || 'asymptotic complexity'}**, ensuring that resources remained strictly accounted for even under heavy load.`,
    
    `With calm precision, ${protagonist} configured the operational parameters. Observing the state transitions carefully, they ensured that the **${keyTerms[4] || 'invariant condition'}** held true across every cycle. As the final verification pass executed, the anomalous signals dissipated. The ${topicName} subsystem synchronized seamlessly, demonstrating the elegant power and reliability of **${conceptName}** when engineered with mathematical rigor.`
  ];

  const readingTime = custom.length === 'Short' ? 2 : custom.length === 'Medium' ? 4 : 6;

  return {
    id: 'story_' + Math.random().toString(36).substring(2, 9),
    title: `The Chronicles of ${conceptName}: Quest in ${setting}`,
    topicId: custom.topicId,
    topicName,
    conceptId: custom.conceptId,
    conceptName,
    genre,
    difficulty,
    length: custom.length,
    characterName: protagonist,
    setting,
    paragraphs,
    keyTerms,
    readingTimeMinutes: readingTime,
    conceptMappings,
    createdAt: new Date().toISOString()
  };
}
