import { GeneratedStory, QuizResult, UserProgress } from '@/types';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

const SESSION_KEY = 'codetales_user_session';
const STORIES_KEY = 'codetales_saved_stories';
const QUIZZES_KEY = 'codetales_quiz_results';
const CUSTOM_API_KEY = 'codetales_custom_gemini_key';
const CUSTOM_HF_TOKEN = 'codetales_custom_hf_token';
const CUSTOM_HF_MODEL = 'codetales_custom_hf_model';

export interface LocalUserSession {
  id: string;
  email: string;
  name: string;
  isGuest: boolean;
  avatarSeed?: string;
  createdAt: string;
}

export function getLocalSession(): LocalUserSession | null {
  if (typeof window === 'undefined') return null;
  const data = localStorage.getItem(SESSION_KEY);
  if (!data) return null;
  try {
    return JSON.parse(data);
  } catch {
    return null;
  }
}

export function setLocalSession(session: LocalUserSession | null): void {
  if (typeof window === 'undefined') return;
  if (!session) {
    localStorage.removeItem(SESSION_KEY);
  } else {
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  }
}

export function getSavedStories(): GeneratedStory[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(STORIES_KEY);
  if (!data) return [];
  try {
    return JSON.parse(data);
  } catch {
    return [];
  }
}

export function saveStory(story: GeneratedStory): void {
  if (typeof window === 'undefined') return;
  const current = getSavedStories();
  const exists = current.some(s => s.id === story.id);
  const updated = exists ? current.map(s => s.id === story.id ? story : s) : [story, ...current];
  localStorage.setItem(STORIES_KEY, JSON.stringify(updated.slice(0, 50)));
}

export function getQuizResults(): QuizResult[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(QUIZZES_KEY);
  if (!data) return [];
  try {
    return JSON.parse(data);
  } catch {
    return [];
  }
}

export function saveQuizResult(result: QuizResult): void {
  if (typeof window === 'undefined') return;
  const current = getQuizResults();
  const updated = [result, ...current];
  localStorage.setItem(QUIZZES_KEY, JSON.stringify(updated.slice(0, 50)));

  // If Supabase is connected and user is authenticated, persist to database
  if (isSupabaseConfigured) {
    const session = getLocalSession();
    if (session && !session.isGuest && session.id) {
      (async () => {
        try {
          const { error } = await supabase
            .from('quiz_scores')
            .insert({
              user_id: session.id,
              topic_name: result.topicName,
              concept_name: result.conceptName,
              score: result.score,
              total_questions: result.totalQuestions,
              percentage: result.percentage,
              completed_at: result.completedAt || new Date().toISOString(),
            });
          if (error) {
            console.warn('Failed to sync quiz score to Supabase:', error.message);
          }
        } catch (err) {
          console.warn('Supabase quiz sync error:', err);
        }
      })();
    }
  }
}

export function getUserProgress(): UserProgress {
  const stories = getSavedStories();
  const quizzes = getQuizResults();
  
  const completedTopics = Array.from(new Set(stories.map(s => s.topicId)));
  const totalScore = quizzes.reduce((acc, q) => acc + q.percentage, 0);
  const avgScore = quizzes.length > 0 ? Math.round(totalScore / quizzes.length) : 0;

  return {
    storiesRead: stories.length,
    quizzesTaken: quizzes.length,
    averageScore: avgScore,
    completedTopics,
    recentStories: stories.slice(0, 5),
    recentQuizResults: quizzes.slice(0, 5),
  };
}

export function getCustomApiKey(): string {
  if (typeof window === 'undefined') return '';
  return localStorage.getItem(CUSTOM_API_KEY) || '';
}

export function setCustomApiKey(key: string): void {
  if (typeof window === 'undefined') return;
  if (!key) {
    localStorage.removeItem(CUSTOM_API_KEY);
  } else {
    localStorage.setItem(CUSTOM_API_KEY, key.trim());
  }
}

export function getCustomHfToken(): string {
  if (typeof window === 'undefined') return '';
  return localStorage.getItem(CUSTOM_HF_TOKEN) || '';
}

export function setCustomHfToken(token: string): void {
  if (typeof window === 'undefined') return;
  if (!token) {
    localStorage.removeItem(CUSTOM_HF_TOKEN);
  } else {
    localStorage.setItem(CUSTOM_HF_TOKEN, token.trim());
  }
}

export function getCustomHfModel(): string {
  if (typeof window === 'undefined') return 'Qwen/Qwen2.5-72B-Instruct';
  return localStorage.getItem(CUSTOM_HF_MODEL) || 'Qwen/Qwen2.5-72B-Instruct';
}

export function setCustomHfModel(model: string): void {
  if (typeof window === 'undefined') return;
  if (!model) {
    localStorage.removeItem(CUSTOM_HF_MODEL);
  } else {
    localStorage.setItem(CUSTOM_HF_MODEL, model.trim());
  }
}
