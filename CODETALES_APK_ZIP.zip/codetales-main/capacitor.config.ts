import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.codetales.app',
  appName: 'CODETALES',
  webDir: 'www',
  server: {
    url: 'https://codetales-6dwd.vercel.app',
    cleartext: false
  }
};

export default config;
