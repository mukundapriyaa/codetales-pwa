$nodeExe = "C:\Program Files\nodejs\node.exe"
if (-not (Test-Path $nodeExe)) {
    $cmd = Get-Command node -ErrorAction SilentlyContinue
    if ($cmd) { $nodeExe = $cmd.Source }
}
if (-not (Test-Path $nodeExe)) {
    $nodeExe = 'C:\Users\mukun\.gemini\antigravity\scratch\tools\nodejs\node.exe'
}
Set-Location 'C:\Users\mukun\.gemini\antigravity\scratch\codetales'

$nextCli = "C:\Users\mukun\.gemini\antigravity\scratch\codetales\node_modules\next\dist\bin\next"
$cloudflared = "C:\Users\mukun\.gemini\antigravity\scratch\tools\cloudflared.exe"

# Clean up any lingering processes
Get-Process -Name "node", "cloudflared" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 1

$serverLog = "C:\Users\mukun\.gemini\antigravity\scratch\codetales\server.log"
$serverErr = "C:\Users\mukun\.gemini\antigravity\scratch\codetales\server_err.log"
if (Test-Path $serverLog) { Remove-Item $serverLog -Force }
if (Test-Path $serverErr) { Remove-Item $serverErr -Force }

Write-Output "Starting Next.js production server on port 3000..."
$serverProc = Start-Process -FilePath $nodeExe -ArgumentList @($nextCli, "start", "-p", "3000", "-H", "127.0.0.1") -WorkingDirectory "C:\Users\mukun\.gemini\antigravity\scratch\codetales" -RedirectStandardOutput $serverLog -RedirectStandardError $serverErr -PassThru

# Wait for server to bind port
Start-Sleep -Seconds 3

Write-Output "Starting Cloudflare quick tunnel..."
$tunnelLog = "C:\Users\mukun\.gemini\antigravity\scratch\codetales\tunnel.log"
if (Test-Path $tunnelLog) { Remove-Item $tunnelLog -Force }

$tunnelProc = Start-Process -FilePath $cloudflared -ArgumentList @("tunnel", "--url", "http://127.0.0.1:3000") -RedirectStandardError $tunnelLog -PassThru

Write-Output "Waiting for public HTTPS tunnel URL..."
$publicUrl = ""
for ($i = 0; $i -lt 30; $i++) {
    Start-Sleep -Seconds 1
    if (Test-Path $tunnelLog) {
        $content = Get-Content $tunnelLog -Raw
        if ($content -match "https://[a-zA-Z0-9-]+\.trycloudflare\.com") {
            $publicUrl = $matches[0]
            break
        }
    }
}

if ($publicUrl) {
    Write-Output "=========================================="
    Write-Output "CODETALES LIVE PUBLIC URL:"
    Write-Output $publicUrl
    Write-Output "=========================================="
    Set-Content -Path "C:\Users\mukun\.gemini\antigravity\scratch\codetales\public_url.txt" -Value $publicUrl
} else {
    Write-Output "Could not extract public URL yet. Content of tunnel log:"
    if (Test-Path $tunnelLog) { Get-Content $tunnelLog | Select-Object -Last 10 }
}

Write-Output "Server and tunnel processes launched (Server PID: $($serverProc.Id), Tunnel PID: $($tunnelProc.Id))."

# Keep running as long as both processes are alive
while (-not $serverProc.HasExited -and -not $tunnelProc.HasExited) {
    Start-Sleep -Seconds 5
}
