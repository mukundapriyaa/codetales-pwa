# CODETALES 🌌
### AI-Powered Educational Storytelling Web Application for Computer Science

CODETALES is a production-ready, full-stack educational web application that transforms abstract, intimidating Computer Science concepts into personalized educational stories using AI. It empowers students and developers to master difficult programming principles through narrative allegories, deep concept mappings, audio narration (Text-to-Speech), and interactive gamified assessments.

---

## 🚀 Live Public Deployment

- **Public HTTPS URL**: Available via the public gateway link below (accessible on Android, iPhone, iPad, tablets, laptops, and desktops with zero installation required).
- **Responsive Web Application**: Pure responsive web application crafted with Next.js 14, React 18, TypeScript, and Tailwind CSS.

---

## 🛠️ Complete Technology Stack

| Layer | Technologies & Ecosystem |
| :--- | :--- |
| **Frontend Framework** | **Next.js 14** (App Router), **React 18**, **TypeScript** |
| **Styling & Theme** | **Tailwind CSS** with Dark Futuristic aesthetic, glowing neon borders, cyber gradients |
| **Icons & Effects** | **Lucide React**, **Canvas Confetti** for gamified mastery celebrations |
| **Authentication & Database** | **Supabase** (Auth, Row Level Security, PostgreSQL database, profiles, quiz scores, learning progress) |
| **AI Ecosystem** | **Hugging Face Transformers** ecosystem via `@huggingface/inference` and serverless inference providers (`/api/generate-story`, `/api/generate-quiz`) |
| **Audio Narration (TTS)** | **Web Speech API** (`window.speechSynthesis`) full-screen cyberpunk audio player, kinetic equalizer visualizer, voice selector, and speed controller (0.75x – 1.5x) |
| **Session & State** | Client state synchronizer, event-driven navbar reactivity, and local session vault fallback |

---

## 🎨 Branding & UI Design System

CODETALES is designed with a **Dark Futuristic** aesthetic:
- **Background**: Deep charcoal and black (`#070712`, `#0b0c1b`, `#04040a`)
- **Primary Accent**: Neon Purple (`#a855f7`, `#9333ea`, glowing shadows)
- **Secondary Accent**: Electric Blue / Neon Cyan (`#00f0ff`, `#06b6d4`, `#3b82f6`)
- **Typography & Details**: Crisp white headings, soft grey supporting text, glowing neon borders, subtle gradients, and smooth kinetic micro-interactions.

---

## 📚 15 Comprehensive Computer Science Topics

CODETALES features deep concept hierarchies for all 15 core computer science domains in a responsive grid:

1. **C Programming**: Variables & Data Types, Operators, Control Flow & Loops, Arrays & Strings, Functions & Stack Scope, Pointers & Direct Memory, Dynamic Memory (`malloc`/`free`), Structures & Unions.
2. **C++ Programming**: Classes & Objects, RAII & Smart Pointers, Operator Overloading, Inheritance & VTables, Templates & Generic Programming, STL Containers, Exception Handling.
3. **Java**: JVM & Bytecode Architecture, Encapsulation & Access Control, Inheritance & Method Overriding, Interfaces & Abstraction, Checked vs Unchecked Exceptions, Collections Framework, Multithreading & Concurrency.
4. **Python**: Variables & Dynamic Typing, Lists/Tuples/Dicts/Sets, Loops & Comprehensions, Functions & Recursion, Generators & Yield, Decorators & Closures, Classes & Dunder Methods.
5. **Data Structures**: Arrays & Dynamic Resizing, Singly & Doubly Linked Lists, Stacks (LIFO) & Queues (FIFO), Hash Tables & Collision Resolution, Trees & Binary Search Trees (BST), Graphs & Adjacency Lists, Heaps & Priority Queues.
6. **Algorithms**: Big-O Asymptotic Complexity, Binary Search, Quick Sort & Merge Sort, Breadth-First (BFS) & Depth-First (DFS) Search, Dijkstra's Shortest Path, Dynamic Programming & Memoization.
7. **Natural Language Processing (NLP)**: Tokenization & Normalization, Stemming & Lemmatization, Bag of Words & TF-IDF, Word Embeddings (Word2Vec), Sentiment Analysis, Transformers & Self-Attention.
8. **Object-Oriented Programming (OOP)**: Classes & Instances, Encapsulation & Data Hiding, Inheritance & Subtyping, Polymorphism (Static/Dynamic), Abstraction & Contracts, SOLID Design Principles.
9. **HTML**: DOM Tree Structure, Semantic Elements & Accessibility, Forms & Input Validation, Tabular Data, Multimedia & Canvas, Meta Tags & SEO.
10. **CSS**: The Box Model & `box-sizing`, Selectors & Specificity Cascade, Flexbox Layout, CSS Grid 2D Layout, Responsive Design & Media Queries, Keyframe Animations & Transitions.
11. **JavaScript**: Scope, `let`/`const` & Hoisting, Closures & Lexical Environments, Event Loop & Call Stack, Promises & Async/Await, DOM Events & Bubbling, Prototype Chain Inheritance.
12. **SQL**: SELECT Projections & WHERE Predicates, Relational JOINs (INNER/LEFT/RIGHT/FULL), Aggregations & GROUP BY, Indexes & Query Optimization, ACID Transactions, CTEs & Subqueries.
13. **Database Management Systems (DBMS)**: Relational Model & Referential Keys, Database Normalization (1NF to BCNF), Entity-Relationship (ER) Modeling, Concurrency Control & 2PL, Deadlocks & Write-Ahead Logging (WAL), Sharding & CAP Theorem.
14. **Operating Systems (OS)**: Processes, Threads & Context Switching, CPU Scheduling (Round Robin/FCFS), Synchronization & Semaphores, Banker's Deadlock Avoidance, Virtual Memory & Paging, File Systems & Inodes.
15. **Computer Networks**: OSI 7-Layer & TCP/IP Protocol Stacks, TCP 3-Way Handshake vs UDP, IP Addressing & Subnetting (CIDR), DNS Resolution & DHCP Lease, Routing Protocols (OSPF/BGP), HTTP/HTTPS & TLS Handshakes.

---

## 🤖 Hugging Face Transformers Integration

CODETALES connects server-side to the Hugging Face Transformers ecosystem using `@huggingface/inference` and the Hugging Face Serverless Inference API / router (`/api/generate-story` and `/api/generate-quiz`).

### Key Highlights:
1. **Server-Side Security**: Hugging Face API keys (`HUGGINGFACE_API_KEY` or `HF_TOKEN`) remain strictly on the backend server and are never leaked to client bundles.
2. **Configurable Models**: Select or customize models supporting text generation and chat completions:
   - `Qwen/Qwen2.5-72B-Instruct` (Default recommended: high-speed, state-of-the-art reasoning)
   - `meta-llama/Llama-3.3-70B-Instruct`
   - `meta-llama/Llama-3.1-8B-Instruct`
   - `mistralai/Mistral-7B-Instruct-v0.3`
   - `google/gemma-2-9b-it`
3. **Structured Pedagogical Prompts**: Enforces strict JSON schemas returning titles, paragraphs with highlighted terms, structured concept mappings, and 5 multiple-choice questions with 4 options and detailed explanations.
4. **Resilient Fallback Handling**: If Hugging Face is temporarily rate-limited or cold-starting, the app provides clean error guidance and supports alternative providers like Google Gemini.

---

## 🗄️ Database Architecture (Supabase)

The complete SQL schema is provided in `supabase/schema.sql`.

### Tables:
1. `public.profiles`:
   - `id uuid primary key references auth.users(id)`
   - `full_name text`
   - `avatar_url text`
   - `preferred_difficulty text`
   - `created_at`, `updated_at`
2. `public.quiz_scores`:
   - `id uuid primary key`
   - `user_id uuid references auth.users(id)`
   - `topic_name text`, `concept_name text`
   - `score integer`, `total_questions integer`, `percentage integer`
   - `completed_at timestamptz`
3. `public.learning_progress`:
   - `id uuid primary key`
   - `user_id uuid references auth.users(id)`
   - `topic_id text`, `concept_id text`
   - `stories_read integer`, `quizzes_completed integer`
   - `last_activity_at timestamptz`

### Security:
- **Row Level Security (RLS)** is enabled on all tables.
- Users can view, update, and manage only their own data.
- Automated PostgreSQL trigger `handle_new_user()` creates a profile record upon user sign-up in `auth.users`.

---

## 🎧 Text-to-Speech (TTS) Narration

The built-in TTS player features:
- **Cyberpunk Holographic Interface**: Full-screen modal with animated audio equalizer waves.
- **Section Scrubber**: Jump to any paragraph in the story with instant progress scrubbing.
- **Controls**: Play, Pause, Stop, Forward, Rewind, Mute.
- **Rate Controller**: 0.75x, 1.0x, 1.25x, 1.5x speed options.
- **Voice Selection**: Automatically queries available browser synthesis voices.
- **Zero Audio Storage**: Synthesizes speech live in the browser using the Web Speech API without saving bulky MP3s.

---

## 🎮 Gamified Quiz & Results Breakdown

- 5 multiple-choice questions dynamically generated based on the story narrative and CS mechanics.
- Neon progress bar and glowing answer cards with instant feedback.
- Detailed results screen showing score, accuracy percentage, missed questions, and comprehensive explanations for every option.
- Interactive canvas confetti celebration on passing scores (60%+).
- Real-time score persistence to the user's profile and Supabase database.

---

## 👤 Navbar Login & Profile Vault

- **Before Login**:
  - Displays Home, Topics, and Journey links.
  - Displays **Sign In** and **Get Started** buttons.
- **After Login**:
  - Replaces auth buttons with a user profile avatar pill and dropdown.
  - Updates immediately throughout the app without requiring a page refresh.
  - Preserves authenticated session across navigation and refreshes.
- **Profile Vault Features**:
  1. Profile avatar / picture with preset selector and custom URL support.
  2. User's full name.
  3. Registered email address.
  4. Edit Profile (name and picture updates saved to DB).
  5. Account Settings (difficulty preferences and AI provider configuration).
  6. Change Password (integrated with Supabase Auth).
  7. Learning Progress (completed topics and accuracy metrics).
  8. Quiz Scores (real saved scores, friendly empty state for new users).
  9. Secure Logout (clears session and resets navbar immediately).

---

## ⚙️ Environment Configuration

Create a `.env.local` file from `.env.example`:

```bash
# 1. Hugging Face Transformers Token (Get free token at https://huggingface.co/settings/tokens)
HUGGINGFACE_API_KEY=hf_your_token_here
HF_TOKEN=hf_your_token_here
HUGGINGFACE_MODEL=Qwen/Qwen2.5-72B-Instruct

# 2. Supabase Configuration (From your Supabase Project Settings -> API)
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-public-key

# 3. Optional Google Gemini Fallback
GEMINI_API_KEY=
```

---

## 🏃 Running Locally

```bash
# 1. Install dependencies
npm install

# 2. Run Next.js development server
npm run dev

# 3. Build optimized production bundle
npm run build

# 4. Start production server
npm start
```

---

## 📦 Source Code Delivery

The complete source code is located in the workspace at:
`C:\Users\mukun\.gemini\antigravity\scratch\codetales`

A complete ZIP archive excluding `node_modules` and `.next` build files is provided as:
`CODETALES_SOURCE_CODE.zip`
